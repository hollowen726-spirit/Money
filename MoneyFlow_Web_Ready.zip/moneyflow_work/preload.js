const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("moneyflow", {

    registerUser: (data) =>
        ipcRenderer.invoke("register-user", data),

    loginUser: (data) =>
        ipcRenderer.invoke("login-user", data),

    getUserData: (userId) =>
        ipcRenderer.invoke("get-user-data", userId),

    addIncome: (data) =>
        ipcRenderer.invoke("add-income", data),

    deleteIncome: (data) =>
        ipcRenderer.invoke("delete-income", data),

    addExpense: (data) =>
        ipcRenderer.invoke("add-expense", data),

    deleteExpense: (data) =>
        ipcRenderer.invoke("delete-expense", data),

    updateUPI: (data) =>
        ipcRenderer.invoke("update-upi", data),

    addBankAccount: (data) =>
        ipcRenderer.invoke("add-bank-account", data),

    updateBankAccount: (data) =>
        ipcRenderer.invoke("update-bank-account", data),

    deleteBankAccount: (data) =>
        ipcRenderer.invoke("delete-bank-account", data),

    addAutoPay: (data) =>
        ipcRenderer.invoke("add-autopay", data),

    deleteAutoPay: (data) =>
        ipcRenderer.invoke("delete-autopay", data),

    addGoal: (data) =>
        ipcRenderer.invoke("add-goal", data),

    addGoalMoney: (data) =>
        ipcRenderer.invoke("add-goal-money", data),

    deleteGoal: (data) =>
        ipcRenderer.invoke("delete-goal", data),

    showMessage: (data) =>
        ipcRenderer.invoke("show-message", data)
});