const express = require("express");
const cors = require("cors");
const axios = require("axios");
const dotenv = require("dotenv");
const crypto = require("crypto");

dotenv.config();

const database = require("./database");

const app = express();

app.use(
    cors({
        origin: "*"
    })
);

app.use(
    express.json({
        limit: "2mb"
    })
);

app.use(express.urlencoded({ extended: true }));

const PORT = process.env.BANK_SERVER_PORT || 5050;

const sessions = new Map();

function generateId(prefix = "id") {
    return (
        prefix +
        "_" +
        Date.now() +
        "_" +
        crypto.randomBytes(5).toString("hex")
    );
}

function cleanPhone(phone) {
    return String(phone || "")
        .replace(/\D/g, "")
        .slice(-10);
}

function validPhone(phone) {
    return /^[6-9]\d{9}$/.test(phone);
}

/*
|--------------------------------------------------------------------------
| HOME
|--------------------------------------------------------------------------
*/

app.get("/", (req, res) => {
    res.json({
        success: true,
        application: "MoneyFlow Bank Integration Server",
        status: "running",
        message:
            "Bank integration server is running."
    });
});

/*
|--------------------------------------------------------------------------
| HEALTH CHECK
|--------------------------------------------------------------------------
*/

app.get("/api/bank/status", (req, res) => {
    res.json({
        success: true,
        status: "online",
        providerConfigured:
            Boolean(
                process.env.AA_BASE_URL &&
                process.env.AA_CLIENT_ID &&
                process.env.AA_CLIENT_SECRET
            ),
        timestamp: new Date().toISOString()
    });
});

/*
|--------------------------------------------------------------------------
| START BANK CONNECTION
|--------------------------------------------------------------------------
|
| This creates a local session.
|
| The actual AA provider must be connected here.
|
*/

app.post("/api/bank/connect", async (req, res) => {
    try {
        const {
            userId,
            mobile
        } = req.body;

        if (!userId) {
            return res.status(400).json({
                success: false,
                message: "MoneyFlow user ID is required."
            });
        }

        const phone = cleanPhone(mobile);

        if (!validPhone(phone)) {
            return res.status(400).json({
                success: false,
                message:
                    "Enter a valid 10-digit Indian mobile number."
            });
        }

        const sessionId =
            generateId("bank_session");

        sessions.set(sessionId, {
            sessionId,
            userId: String(userId),
            mobile: phone,
            status: "created",
            createdAt:
                new Date().toISOString(),
            accounts: [],
            transactions: []
        });

        /*
         * IMPORTANT:
         *
         * This is where your authorized
         * Account Aggregator provider's
         * consent API is called.
         *
         * Do not replace this with bank
         * passwords or OTP collection.
         */

        if (
            !process.env.AA_BASE_URL ||
            !process.env.AA_CLIENT_ID ||
            !process.env.AA_CLIENT_SECRET
        ) {
            return res.json({
                success: true,
                demo: true,
                sessionId,
                status: "provider_not_configured",
                message:
                    "MoneyFlow bank connection is ready, but an authorized Account Aggregator provider has not been configured yet.",
                nextStep:
                    "Configure AA_BASE_URL, AA_CLIENT_ID and AA_CLIENT_SECRET."
            });
        }

        /*
         * Provider-specific integration goes here.
         *
         * Different AA/TSP providers expose
         * different onboarding APIs.
         */

        return res.json({
            success: true,
            demo: false,
            sessionId,
            status: "provider_ready",
            message:
                "Bank connection session created."
        });
    } catch (error) {
        console.error(
            "BANK CONNECT ERROR:",
            error
        );

        return res.status(500).json({
            success: false,
            message:
                "Unable to start bank connection."
        });
    }
});

/*
|--------------------------------------------------------------------------
| GET SESSION
|--------------------------------------------------------------------------
*/

app.get(
    "/api/bank/session/:sessionId",
    (req, res) => {
        try {
            const session =
                sessions.get(
                    req.params.sessionId
                );

            if (!session) {
                return res.status(404).json({
                    success: false,
                    message:
                        "Bank connection session not found."
                });
            }

            res.json({
                success: true,
                session: {
                    sessionId:
                        session.sessionId,
                    status:
                        session.status,
                    createdAt:
                        session.createdAt
                }
            });
        } catch (error) {
            console.error(
                "SESSION ERROR:",
                error
            );

            res.status(500).json({
                success: false,
                message:
                    "Unable to read bank session."
            });
        }
    }
);

/*
|--------------------------------------------------------------------------
| PROVIDER CALLBACK
|--------------------------------------------------------------------------
|
| Your AA/TSP provider should call your
| registered callback/webhook.
|
*/

app.post(
    "/api/bank/callback",
    async (req, res) => {
        try {
            const {
                sessionId,
                status,
                accounts,
                transactions
            } = req.body;

            if (!sessionId) {
                return res.status(400).json({
                    success: false,
                    message:
                        "sessionId is required."
                });
            }

            const session =
                sessions.get(sessionId);

            if (!session) {
                return res.status(404).json({
                    success: false,
                    message:
                        "Session not found."
                });
            }

            session.status =
                status || "completed";

            session.accounts =
                Array.isArray(accounts)
                    ? accounts
                    : [];

            session.transactions =
                Array.isArray(transactions)
                    ? transactions
                    : [];

            sessions.set(
                sessionId,
                session
            );

            res.json({
                success: true,
                message:
                    "Bank data callback received."
            });
        } catch (error) {
            console.error(
                "CALLBACK ERROR:",
                error
            );

            res.status(500).json({
                success: false,
                message:
                    "Unable to process bank callback."
            });
        }
    }
);

/*
|--------------------------------------------------------------------------
| IMPORT BANK ACCOUNTS INTO MONEYFLOW
|--------------------------------------------------------------------------
*/

app.post(
    "/api/bank/import",
    async (req, res) => {
        try {
            const {
                sessionId
            } = req.body;

            if (!sessionId) {
                return res.status(400).json({
                    success: false,
                    message:
                        "sessionId is required."
                });
            }

            const session =
                sessions.get(sessionId);

            if (!session) {
                return res.status(404).json({
                    success: false,
                    message:
                        "Bank session not found."
                });
            }

            const importedAccounts =
                Array.isArray(
                    session.accounts
                )
                    ? session.accounts
                    : [];

            if (
                importedAccounts.length === 0
            ) {
                return res.status(400).json({
                    success: false,
                    message:
                        "No bank accounts were returned by the provider."
                });
            }

            const savedAccounts = [];

            for (
                const account
                of importedAccounts
            ) {
                const result =
                    database.addBankAccount({
                        userId:
                            session.userId,

                        bankName:
                            account.bankName ||
                            account.bank ||
                            "Bank",

                        accountHolder:
                            account.accountHolder ||
                            account.name ||
                            "",

                        accountType:
                            account.accountType ||
                            "Savings",

                        accountNumberLast4:
                            account.accountNumberLast4 ||
                            account.last4 ||
                            "",

                        accountNumberMasked:
                            account.accountNumberMasked ||
                            account.maskedAccountNumber ||
                            "",

                        ifsc:
                            account.ifsc ||
                            "",

                        branch:
                            account.branch ||
                            "",

                        upiId:
                            account.upiId ||
                            "",

                        nickname:
                            account.nickname ||
                            account.bankName ||
                            "Bank Account",

                        balance:
                            Number(
                                account.balance || 0
                            ),

                        isPrimary:
                            savedAccounts.length === 0
                    });

                if (
                    result &&
                    result.success
                ) {
                    savedAccounts.push(
                        result.account ||
                        result
                    );
                }
            }

            /*
             * Import transactions
             */

            let savedTransactions = 0;

            if (
                Array.isArray(
                    session.transactions
                )
            ) {
                for (
                    const transaction
                    of session.transactions
                ) {
                    try {
                        const accountId =
                            transaction.accountId ||
                            savedAccounts[0]?.id;

                        const amount =
                            Number(
                                transaction.amount ||
                                0
                            );

                        if (
                            !accountId ||
                            !amount
                        ) {
                            continue;
                        }

                        const type =
                            String(
                                transaction.type ||
                                transaction.transactionType ||
                                "expense"
                            ).toLowerCase();

                        if (
                            type === "credit" ||
                            type === "income"
                        ) {
                            database.addIncome({
                                userId:
                                    session.userId,

                                amount,

                                source:
                                    transaction.description ||
                                    transaction.narration ||
                                    "Bank transaction",

                                date:
                                    transaction.date ||
                                    new Date().toISOString(),

                                bankAccountId:
                                    accountId,

                                sourceType:
                                    "bank-sync"
                            });
                        } else {
                            database.addExpense({
                                userId:
                                    session.userId,

                                amount,

                                category:
                                    transaction.category ||
                                    "Bank Transaction",

                                description:
                                    transaction.description ||
                                    transaction.narration ||
                                    "Bank transaction",

                                date:
                                    transaction.date ||
                                    new Date().toISOString(),

                                bankAccountId:
                                    accountId,

                                sourceType:
                                    "bank-sync"
                            });
                        }

                        savedTransactions++;
                    } catch (transactionError) {
                        console.error(
                            "TRANSACTION IMPORT ERROR:",
                            transactionError
                        );
                    }
                }
            }

            session.status =
                "imported";

            sessions.set(
                sessionId,
                session
            );

            res.json({
                success: true,
                message:
                    "Bank accounts imported into MoneyFlow.",
                accountsImported:
                    savedAccounts.length,
                transactionsImported:
                    savedTransactions,
                accounts:
                    savedAccounts
            });
        } catch (error) {
            console.error(
                "IMPORT ERROR:",
                error
            );

            res.status(500).json({
                success: false,
                message:
                    "Unable to import bank data."
            });
        }
    }
);

/*
|--------------------------------------------------------------------------
| NORMALIZED DATA
|--------------------------------------------------------------------------
*/

app.get(
    "/api/bank/session/:sessionId/data",
    (req, res) => {
        try {
            const session =
                sessions.get(
                    req.params.sessionId
                );

            if (!session) {
                return res.status(404).json({
                    success: false,
                    message:
                        "Session not found."
                });
            }

            res.json({
                success: true,

                sessionId:
                    session.sessionId,

                userId:
                    session.userId,

                status:
                    session.status,

                accounts:
                    session.accounts || [],

                transactions:
                    session.transactions || []
            });
        } catch (error) {
            console.error(
                "DATA ERROR:",
                error
            );

            res.status(500).json({
                success: false,
                message:
                    "Unable to get bank data."
            });
        }
    }
);

/*
|--------------------------------------------------------------------------
| SECURITY ERROR HANDLER
|--------------------------------------------------------------------------
*/

app.use(
    (error, req, res, next) => {
        console.error(
            "SERVER ERROR:",
            error
        );

        res.status(500).json({
            success: false,
            message:
                "Unexpected server error."
        });
    }
);

/*
|--------------------------------------------------------------------------
| START SERVER
|--------------------------------------------------------------------------
*/

app.listen(PORT, "0.0.0.0", () => {
    console.log("");
    console.log(
        "=========================================="
    );
    console.log(
        "       MONEYFLOW BANK SERVER"
    );
    console.log(
        "=========================================="
    );
    console.log(
        `Server running on port ${PORT}`
    );
    console.log(
        `http://localhost:${PORT}`
    );
    console.log(
        "=========================================="
    );
    console.log("");
});