/* =========================================================
   MONEYFLOW - BANK ACCOUNTS
   COMPLETE FIXED VERSION
   ========================================================= */

let currentUser = null;
let bankAccounts = [];
let bankTransactions = [];


/* =========================================================
   START
========================================================= */

document.addEventListener("DOMContentLoaded", initAccounts);


async function initAccounts() {

    console.log("MoneyFlow Bank Accounts loaded.");

    const storedUser = localStorage.getItem("currentUser");

    if (!storedUser) {
        window.location.href = "login.html";
        return;
    }

    try {
        currentUser = JSON.parse(storedUser);
    } catch (error) {

        console.error("Invalid user data:", error);

        clearLoginData();

        window.location.href = "login.html";
        return;
    }

    if (!currentUser || !currentUser.id) {

        clearLoginData();

        window.location.href = "login.html";
        return;
    }

    /* Admin should not use normal bank accounts page */
    if (currentUser.role === "admin") {

        window.location.href = "admin.html";
        return;
    }

    setupUser();
    setupNavigation();
    setupBankButtons();
    setupForm();

    await loadData();
}


/* =========================================================
   CLEAR LOGIN DATA
========================================================= */

function clearLoginData() {

    localStorage.removeItem("currentUser");
    localStorage.removeItem("moneyflowUserId");
    localStorage.removeItem("moneyflowOpenSection");
}


/* =========================================================
   USER INFORMATION
========================================================= */

function setupUser() {

    const name =
        currentUser.name ||
        currentUser.fullName ||
        currentUser.username ||
        "User";

    const email =
        currentUser.email ||
        "";

    setText("sidebarUserName", name);
    setText("sidebarUserEmail", email);

    setText(
        "sidebarAvatar",
        name.charAt(0).toUpperCase()
    );

    setText(
        "todayChip",
        new Date().toLocaleDateString(
            "en-IN",
            {
                day: "2-digit",
                month: "short",
                year: "numeric"
            }
        )
    );
}


/* =========================================================
   NAVIGATION
========================================================= */

function setupNavigation() {

    /*
        Dashboard / Income / Expenses /
        Auto-Pay / Budget / Goals /
        History / Analysis / Profile
    */

    const dashboardButtons =
        document.querySelectorAll(
            "[data-dashboard]"
        );

    dashboardButtons.forEach(function(button) {

        button.addEventListener(
            "click",
            function(event) {

                event.preventDefault();
                event.stopPropagation();

                const section =
                    this.getAttribute(
                        "data-section-target"
                    ) ||
                    "dashboardSection";

                goDashboard(section);
            }
        );
    });


    /*
        Logout
    */

    const logoutButtons =
        document.querySelectorAll(
            "#logoutButton, [data-logout]"
        );

    logoutButtons.forEach(function(button) {

        button.addEventListener(
            "click",
            function(event) {

                event.preventDefault();
                event.stopPropagation();

                logout();
            }
        );
    });


    /*
        Mobile menu
    */

    const mobileButton =
        document.getElementById(
            "mobileMenuButton"
        );

    const sidebar =
        document.getElementById(
            "sidebar"
        );

    if (mobileButton && sidebar) {

        mobileButton.addEventListener(
            "click",
            function(event) {

                event.preventDefault();

                sidebar.classList.toggle(
                    "open"
                );
            }
        );
    }
}


/* =========================================================
   DASHBOARD NAVIGATION
========================================================= */

function goDashboard(section) {

    let target =
        section ||
        "dashboardSection";


    /*
        Fix old spelling
    */

    if (target === "goalsSection") {

        target =
            "goalSection";
    }


    const allowedSections = [

        "dashboardSection",

        "incomeSection",

        "expenseSection",

        "autopaySection",

        "budgetSection",

        "goalSection",

        "historySection",

        "analysisSection",

        "profileSection"

    ];


    if (
        !allowedSections.includes(target)
    ) {

        target =
            "dashboardSection";
    }


    /*
        Remember which section
        should open.
    */

    localStorage.setItem(
        "moneyflowOpenSection",
        target
    );


    console.log(
        "Opening dashboard section:",
        target
    );


    /*
        Navigate back to dashboard.
    */

    window.location.href =
        "dashboard.html";
}


/*
    Make function available globally.
*/

window.goDashboard =
    goDashboard;


/* =========================================================
   LOGOUT
========================================================= */

function logout() {

    console.log(
        "Logging out user..."
    );


    /*
        Remove login session.
    */

    localStorage.removeItem(
        "currentUser"
    );

    localStorage.removeItem(
        "moneyflowUserId"
    );

    localStorage.removeItem(
        "moneyflowOpenSection"
    );


    /*
        Go directly to login.
    */

    window.location.href =
        "login.html";
}


window.logout =
    logout;


/* =========================================================
   BANK BUTTONS
========================================================= */

function setupBankButtons() {

    /*
        ADD BANK ACCOUNT BUTTON
    */

    const addButton =
        document.getElementById(
            "addBankButton"
        );

    if (addButton) {

        addButton.addEventListener(
            "click",
            function(event) {

                event.preventDefault();

                openBankForm();
            }
        );
    }


    /*
        CANCEL BANK ACCOUNT
    */

    const cancelButton =
        document.getElementById(
            "cancelBankButton"
        );

    if (cancelButton) {

        cancelButton.addEventListener(
            "click",
            function(event) {

                event.preventDefault();

                closeBankForm();
            }
        );
    }


    /*
        IMPORT CSV
    */

    const importButton =
        document.getElementById(
            "importButton"
        );

    const csvFile =
        document.getElementById(
            "csvFile"
        );

    if (importButton && csvFile) {

        importButton.addEventListener(
            "click",
            function(event) {

                event.preventDefault();

                csvFile.click();
            }
        );


        csvFile.addEventListener(
            "change",
            function() {

                if (this.files.length > 0) {

                    importCSVFile(
                        this.files[0]
                    );
                }
            }
        );
    }
}


/* =========================================================
   OPEN BANK FORM
========================================================= */

function openBankForm() {

    const card =
        document.getElementById(
            "bankFormCard"
        );

    const title =
        document.getElementById(
            "bankFormTitle"
        );

    const form =
        document.getElementById(
            "bankAccountForm"
        );

    if (!card) {
        return;
    }


    if (title) {

        title.textContent =
            "Add Bank Account";
    }


    if (form) {

        form.reset();
    }


    setValue(
        "bankAccountId",
        ""
    );

    setValue(
        "balance",
        "0"
    );


    card.style.display =
        "block";


    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
}


/* =========================================================
   CLOSE BANK FORM
========================================================= */

function closeBankForm() {

    const card =
        document.getElementById(
            "bankFormCard"
        );

    const form =
        document.getElementById(
            "bankAccountForm"
        );

    if (form) {

        form.reset();
    }


    setValue(
        "bankAccountId",
        ""
    );


    setValue(
        "balance",
        "0"
    );


    if (card) {

        card.style.display =
            "none";
    }


    const title =
        document.getElementById(
            "bankFormTitle"
        );

    if (title) {

        title.textContent =
            "Add Bank Account";
    }
}


/* =========================================================
   FORM
========================================================= */

function setupForm() {

    const form =
        document.getElementById(
            "bankAccountForm"
        );

    if (!form) {

        console.error(
            "Bank account form not found."
        );

        return;
    }


    form.addEventListener(
        "submit",
        saveAccount
    );
}


/* =========================================================
   SAVE / UPDATE ACCOUNT
========================================================= */

async function saveAccount(event) {

    event.preventDefault();

    console.log(
        "Saving bank account..."
    );


    try {

        const id =
            getValue(
                "bankAccountId"
            );


        const bankName =
            getValue(
                "bankName"
            );


        const accountHolder =
            getValue(
                "accountHolder"
            );


        const accountType =
            getValue(
                "accountType"
            ) ||
            "Savings";


        const accountNumber =
            getValue(
                "accountNumber"
            )
                .replace(/\D/g, "")
                .slice(-4);


        const ifsc =
            getValue(
                "ifsc"
            ).toUpperCase();


        const branch =
            getValue(
                "branch"
            );


        const upiId =
            getValue(
                "upiId"
            );


        const nickname =
            getValue(
                "nickname"
            );


        const balanceText =
            getValue(
                "balance"
            );


        const balance =
            Number(
                balanceText || 0
            );


        /*
            VALIDATION
        */

        if (!bankName) {

            showNotification(
                "Please enter the bank name.",
                false
            );

            return;
        }


        if (!accountHolder) {

            showNotification(
                "Please enter the account holder name.",
                false
            );

            return;
        }


        if (
            accountNumber &&
            accountNumber.length !== 4
        ) {

            showNotification(
                "Account number must contain exactly 4 digits.",
                false
            );

            return;
        }


        if (!Number.isFinite(balance)) {

            showNotification(
                "Please enter a valid balance.",
                false
            );

            return;
        }


        /*
            PREPARE DATA
        */

        const data = {

            userId:
                currentUser.id,

            bankName:
                bankName,

            accountHolder:
                accountHolder,

            accountType:
                accountType,

            accountNumberLast4:
                accountNumber,

            ifsc:
                ifsc,

            branch:
                branch,

            upiId:
                upiId,

            nickname:
                nickname,

            balance:
                balance,

            isPrimary:
                false
        };


        /*
            UPDATE EXISTING ACCOUNT
        */

        if (id) {

            data.id =
                id;


            console.log(
                "Updating account:",
                id
            );


            const result =
                await window.expenseAPI
                    .updateBankAccount(
                        data
                    );


            if (
                result &&
                result.success
            ) {

                showNotification(
                    result.message ||
                    "Bank account updated successfully.",
                    true
                );

                closeBankForm();

                await loadData();

            } else {

                showNotification(
                    result?.message ||
                    "Unable to update bank account.",
                    false
                );
            }


            return;
        }


        /*
            CREATE NEW ACCOUNT
        */

        console.log(
            "Creating new bank account..."
        );


        const result =
            await window.expenseAPI
                .addBankAccount(
                    data
                );


        if (
            result &&
            result.success
        ) {

            showNotification(
                result.message ||
                "Bank account added successfully.",
                true
            );


            closeBankForm();


            await loadData();

        } else {

            showNotification(
                result?.message ||
                "Unable to create bank account.",
                false
            );
        }


    } catch (error) {

        console.error(
            "BANK ACCOUNT SAVE ERROR:",
            error
        );


        showNotification(
            "Unable to save the bank account. Please try again.",
            false
        );
    }
}


/* =========================================================
   LOAD DATA
========================================================= */

async function loadData() {

    console.log(
        "Loading bank account data..."
    );


    try {

        if (
            !window.expenseAPI ||
            !window.expenseAPI.getUserData
        ) {

            showNotification(
                "Application API is not available.",
                false
            );

            return;
        }


        const result =
            await window.expenseAPI
                .getUserData(
                    currentUser.id
                );


        if (
            !result ||
            result.success === false
        ) {

            showNotification(
                result?.message ||
                "Unable to load bank account data.",
                false
            );

            return;
        }


        bankAccounts =
            Array.isArray(
                result.bankAccounts
            )
                ? result.bankAccounts
                : [];


        bankTransactions =
            Array.isArray(
                result.bankTransactions
            )
                ? result.bankTransactions
                : [];


        console.log(
            "Bank accounts:",
            bankAccounts
        );


        renderAccounts();

        renderTransactions();


    } catch (error) {

        console.error(
            "LOAD BANK DATA ERROR:",
            error
        );


        showNotification(
            "Unable to load your bank account data.",
            false
        );
    }
}


/* =========================================================
   RENDER BANK ACCOUNTS
========================================================= */

function renderAccounts() {

    /*
        IMPORTANT:
        Your HTML uses bankAccountsList.
    */

    const container =
        document.getElementById(
            "bankAccountsList"
        );


    if (!container) {

        console.error(
            "bankAccountsList not found."
        );

        return;
    }


    if (!bankAccounts.length) {

        container.innerHTML = `

            <div class="empty">

                🏦 No bank accounts added yet.

                <br><br>

                Click
                <strong>
                    "+ Add Bank Account"
                </strong>
                to create your first account.

            </div>

        `;

        return;
    }


    container.innerHTML =
        bankAccounts.map(
            function(account) {

                const primaryText =
                    account.isPrimary
                        ? "PRIMARY ACCOUNT"
                        : "BANK ACCOUNT";


                return `

                    <div
                        class="list-item"
                        style="
                            display:block;
                            padding:20px;
                        "
                    >

                        <div
                            style="
                                display:flex;
                                justify-content:space-between;
                                align-items:flex-start;
                                gap:15px;
                            "
                        >

                            <div
                                class="list-left"
                            >

                                <div
                                    class="list-icon"
                                    style="
                                        background:#cffafe;
                                        color:#0891b2;
                                    "
                                >
                                    🏦
                                </div>


                                <div>

                                    <div
                                        class="list-title"
                                        style="font-size:16px;"
                                    >
                                        ${escapeHTML(
                                            account.bankName ||
                                            "Bank Account"
                                        )}
                                    </div>


                                    <div
                                        class="list-subtitle"
                                    >
                                        ${primaryText}
                                    </div>

                                </div>

                            </div>


                            <div
                                style="
                                    text-align:right;
                                "
                            >

                                <div
                                    class="amount-income"
                                    style="
                                        font-size:18px;
                                    "
                                >
                                    ${formatMoney(
                                        account.balance
                                    )}
                                </div>

                                <div
                                    class="list-subtitle"
                                >
                                    Current Balance
                                </div>

                            </div>

                        </div>


                        <div
                            style="
                                display:grid;
                                grid-template-columns:
                                    repeat(
                                        auto-fit,
                                        minmax(
                                            160px,
                                            1fr
                                        )
                                    );
                                gap:12px;
                                margin-top:18px;
                                padding-top:15px;
                                border-top:
                                    1px solid #e5e7eb;
                            "
                        >

                            <div>

                                <div
                                    class="list-subtitle"
                                >
                                    Account Holder
                                </div>

                                <strong>
                                    ${escapeHTML(
                                        account.accountHolder ||
                                        "Not provided"
                                    )}
                                </strong>

                            </div>


                            <div>

                                <div
                                    class="list-subtitle"
                                >
                                    Account Number
                                </div>

                                <strong>
                                    ${escapeHTML(
                                        account.accountNumberMasked ||
                                        (
                                            account.accountNumberLast4
                                                ? "****" +
                                                  account.accountNumberLast4
                                                : "Not provided"
                                        )
                                    )}
                                </strong>

                            </div>


                            <div>

                                <div
                                    class="list-subtitle"
                                >
                                    Account Type
                                </div>

                                <strong>
                                    ${escapeHTML(
                                        account.accountType ||
                                        "Savings"
                                    )}
                                </strong>

                            </div>


                            <div>

                                <div
                                    class="list-subtitle"
                                >
                                    IFSC
                                </div>

                                <strong>
                                    ${escapeHTML(
                                        account.ifsc ||
                                        "Not provided"
                                    )}
                                </strong>

                            </div>


                            <div>

                                <div
                                    class="list-subtitle"
                                >
                                    Branch
                                </div>

                                <strong>
                                    ${escapeHTML(
                                        account.branch ||
                                        "Not provided"
                                    )}
                                </strong>

                            </div>


                            <div>

                                <div
                                    class="list-subtitle"
                                >
                                    UPI ID
                                </div>

                                <strong>
                                    ${escapeHTML(
                                        account.upiId ||
                                        "Not provided"
                                    )}
                                </strong>

                            </div>


                            <div>

                                <div
                                    class="list-subtitle"
                                >
                                    Nickname
                                </div>

                                <strong>
                                    ${escapeHTML(
                                        account.nickname ||
                                        account.bankName ||
                                        "Bank Account"
                                    )}
                                </strong>

                            </div>

                        </div>


                        <div
                            style="
                                display:flex;
                                flex-wrap:wrap;
                                gap:8px;
                                margin-top:18px;
                            "
                        >

                            <button
                                type="button"
                                class="btn btn-blue"
                                onclick="editAccount('${escapeJS(
                                    account.id
                                )}')"
                            >
                                ✏️ Edit
                            </button>


                            ${
                                account.isPrimary
                                    ? `
                                        <button
                                            type="button"
                                            class="btn btn-green"
                                            disabled
                                        >
                                            ⭐ Primary
                                        </button>
                                    `
                                    :
                                    `
                                        <button
                                            type="button"
                                            class="btn btn-gray"
                                            onclick="setPrimary('${escapeJS(
                                                account.id
                                            )}')"
                                        >
                                            ⭐ Set Primary
                                        </button>
                                    `
                            }


                            <button
                                type="button"
                                class="btn btn-red"
                                onclick="deleteAccount('${escapeJS(
                                    account.id
                                )}')"
                            >
                                🗑 Delete
                            </button>

                        </div>

                    </div>

                `;
            }
        ).join("");
}


/* =========================================================
   EDIT ACCOUNT
========================================================= */

window.editAccount =
    function(id) {

        const account =
            bankAccounts.find(
                function(item) {

                    return String(item.id) ===
                        String(id);
                }
            );


        if (!account) {

            showNotification(
                "Bank account not found.",
                false
            );

            return;
        }


        setValue(
            "bankAccountId",
            account.id
        );


        setValue(
            "bankName",
            account.bankName || ""
        );


        setValue(
            "accountHolder",
            account.accountHolder || ""
        );


        setValue(
            "accountType",
            account.accountType ||
            "Savings"
        );


        setValue(
            "accountNumber",
            account.accountNumberLast4 ||
            ""
        );


        setValue(
            "ifsc",
            account.ifsc || ""
        );


        setValue(
            "branch",
            account.branch || ""
        );


        setValue(
            "upiId",
            account.upiId || ""
        );


        setValue(
            "nickname",
            account.nickname || ""
        );


        setValue(
            "balance",
            Number(
                account.balance || 0
            ).toFixed(2)
        );


        const title =
            document.getElementById(
                "bankFormTitle"
            );


        if (title) {

            title.textContent =
                "Edit Bank Account";
        }


        const card =
            document.getElementById(
                "bankFormCard"
            );


        if (card) {

            card.style.display =
                "block";
        }


        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });
    };


/* =========================================================
   SET PRIMARY ACCOUNT
========================================================= */

window.setPrimary =
    async function(id) {

        try {

            const result =
                await window.expenseAPI
                    .setPrimaryBankAccount({

                        id:
                            id,

                        userId:
                            currentUser.id
                    });


            if (
                result &&
                result.success
            ) {

                showNotification(
                    result.message ||
                    "Primary bank account updated.",
                    true
                );


                await loadData();

            } else {

                showNotification(
                    result?.message ||
                    "Unable to set primary account.",
                    false
                );
            }


        } catch (error) {

            console.error(
                "SET PRIMARY ERROR:",
                error
            );


            showNotification(
                "Unable to set primary bank account.",
                false
            );
        }
    };


/* =========================================================
   DELETE ACCOUNT
========================================================= */

window.deleteAccount =
    async function(id) {

        const account =
            bankAccounts.find(
                function(item) {

                    return String(item.id) ===
                        String(id);
                }
            );


        if (!account) {

            return;
        }


        const confirmed =
            window.confirm(
                `Are you sure you want to delete ${
                    account.bankName ||
                    "this bank account"
                }?`
            );


        if (!confirmed) {

            return;
        }


        try {

            const result =
                await window.expenseAPI
                    .deleteBankAccount({

                        id:
                            id,

                        userId:
                            currentUser.id
                    });


            if (
                result &&
                result.success
            ) {

                showNotification(
                    result.message ||
                    "Bank account deleted successfully.",
                    true
                );


                await loadData();

            } else {

                showNotification(
                    result?.message ||
                    "Unable to delete bank account.",
                    false
                );
            }


        } catch (error) {

            console.error(
                "DELETE BANK ACCOUNT ERROR:",
                error
            );


            showNotification(
                "Unable to delete bank account.",
                false
            );
        }
    };


/* =========================================================
   RENDER TRANSACTIONS
========================================================= */

function renderTransactions() {

    /*
        Your HTML uses:
        bankTransactionsList
    */

    const container =
        document.getElementById(
            "bankTransactionsList"
        );


    if (!container) {

        return;
    }


    const records =
        [...bankTransactions]
            .sort(
                function(a, b) {

                    return new Date(
                        b.date
                    ) -
                    new Date(
                        a.date
                    );
                }
            )
            .slice(
                0,
                20
            );


    if (!records.length) {

        container.innerHTML = `

            <div class="empty">

                No imported bank transactions found.

            </div>

        `;

        return;
    }


    container.innerHTML =
        records.map(
            function(item) {

                const type =
                    String(
                        item.type ||
                        item.transactionType ||
                        ""
                    )
                        .toLowerCase();


                const isCredit =
                    type.includes(
                        "credit"
                    );


                return `

                    <div
                        class="list-item"
                    >

                        <div
                            class="list-left"
                        >

                            <div
                                class="list-icon"
                                style="
                                    background:${
                                        isCredit
                                            ? "#dcfce7"
                                            : "#fee2e2"
                                    };
                                    color:${
                                        isCredit
                                            ? "#059669"
                                            : "#dc2626"
                                    };
                                "
                            >
                                ${
                                    isCredit
                                        ? "⬆️"
                                        : "⬇️"
                                }
                            </div>


                            <div>

                                <div
                                    class="list-title"
                                >
                                    ${escapeHTML(
                                        item.description ||
                                        item.narration ||
                                        "Bank Transaction"
                                    )}
                                </div>


                                <div
                                    class="list-subtitle"
                                >
                                    ${formatDate(
                                        item.date
                                    )}
                                </div>

                            </div>

                        </div>


                        <div
                            class="${
                                isCredit
                                    ? "amount-income"
                                    : "amount-expense"
                            }"
                        >
                            ${
                                isCredit
                                    ? "+"
                                    : "-"
                            }${formatMoney(
                                item.amount
                            )}
                        </div>

                    </div>

                `;
            }
        ).join("");
}


/* =========================================================
   CSV IMPORT
========================================================= */

async function importCSVFile(file) {

    if (!file) {
        return;
    }


    try {

        showNotification(
            "Reading bank statement...",
            true
        );


        const text =
            await file.text();


        const rows =
            parseCSV(text);


        if (!rows.length) {

            showNotification(
                "No transaction rows found in the CSV file.",
                false
            );

            return;
        }


        const transactions =
            rows
                .map(
                    normalizeCSVRow
                )
                .filter(
                    Boolean
                );


        if (!transactions.length) {

            showNotification(
                "No valid transactions were found.",
                false
            );

            return;
        }


        /*
            Use primary account automatically.
            If there is no primary account,
            use the first account.
        */

        const account =
            bankAccounts.find(
                function(item) {

                    return Boolean(
                        item.isPrimary
                    );
                }
            ) ||
            bankAccounts[0];


        if (!account) {

            showNotification(
                "Please create a bank account before importing transactions.",
                false
            );

            return;
        }


        const result =
            await window.expenseAPI
                .importBankTransactions({

                    userId:
                        currentUser.id,

                    bankAccountId:
                        account.id,

                    transactions:
                        transactions
                });


        if (
            result &&
            result.success
        ) {

            showNotification(
                result.message ||
                "Bank statement imported successfully.",
                true
            );


            const fileInput =
                document.getElementById(
                    "csvFile"
                );


            if (fileInput) {

                fileInput.value =
                    "";
            }


            await loadData();

        } else {

            showNotification(
                result?.message ||
                "Unable to import bank statement.",
                false
            );
        }


    } catch (error) {

        console.error(
            "CSV IMPORT ERROR:",
            error
        );


        showNotification(
            "Unable to import the CSV statement.",
            false
        );
    }
}


/* =========================================================
   CSV PARSER
========================================================= */

function parseCSV(text) {

    const lines =
        String(text || "")
            .split(/\r?\n/)
            .filter(
                function(line) {

                    return line.trim();
                }
            );


    if (lines.length < 2) {

        return [];
    }


    const headers =
        splitCSVLine(
            lines[0]
        )
            .map(
                function(item) {

                    return item
                        .trim()
                        .toLowerCase();
                }
            );


    return lines
        .slice(1)
        .map(
            function(line) {

                const values =
                    splitCSVLine(
                        line
                    );


                const row = {};


                headers.forEach(
                    function(
                        header,
                        index
                    ) {

                        row[header] =
                            values[index] ??
                            "";
                    }
                );


                return row;
            }
        );
}


/* =========================================================
   SPLIT CSV LINE
========================================================= */

function splitCSVLine(line) {

    const result = [];

    let current = "";

    let quoted = false;


    for (
        let i = 0;
        i < line.length;
        i++
    ) {

        const char =
            line[i];


        if (char === '"') {

            if (
                quoted &&
                line[i + 1] === '"'
            ) {

                current += '"';

                i++;

            } else {

                quoted =
                    !quoted;
            }

        } else if (
            char === "," &&
            !quoted
        ) {

            result.push(
                current
            );

            current = "";

        } else {

            current += char;
        }
    }


    result.push(
        current
    );


    return result;
}


/* =========================================================
   NORMALIZE CSV
========================================================= */

function normalizeCSVRow(row) {

    const date =
        row.date ||
        row.transactiondate ||
        row.txndate ||
        "";


    const description =
        row.description ||
        row.narration ||
        row.details ||
        row.remark ||
        row.remarks ||
        "Bank Transaction";


    const type =
        row.type ||
        row.transactiontype ||
        "";


    let amount =
        Number(
            String(
                row.amount ||
                "0"
            )
                .replace(
                    /,/g,
                    ""
                )
        ) || 0;


    const credit =
        Number(
            String(
                row.credit ||
                row.cr ||
                "0"
            )
                .replace(
                    /,/g,
                    ""
                )
        ) || 0;


    const debit =
        Number(
            String(
                row.debit ||
                row.dr ||
                "0"
            )
                .replace(
                    /,/g,
                    ""
                )
        ) || 0;


    let transactionType =
        String(
            type
        )
            .toLowerCase()
            .trim();


    if (!transactionType) {

        if (credit > 0) {

            transactionType =
                "credit";

            amount =
                credit;

        } else if (debit > 0) {

            transactionType =
                "debit";

            amount =
                debit;
        }
    }


    if (
        !date ||
        !amount
    ) {

        return null;
    }


    return {

        date:
            date,

        description:
            description,

        type:
            transactionType ||
            "debit",

        amount:
            Math.abs(
                amount
            )
    };
}


/* =========================================================
   NOTIFICATION
========================================================= */

function showNotification(
    message,
    success
) {

    /*
        Your HTML uses:
        bankNotification
    */

    const element =
        document.getElementById(
            "bankNotification"
        );


    if (!element) {

        /*
            Still log the message
            if notification element
            is unavailable.
        */

        console.log(
            success
                ? "SUCCESS:"
                : "ERROR:",
            message
        );

        return;
    }


    element.textContent =
        message;


    element.style.display =
        "block";


    if (success) {

        element.style.background =
            "#dcfce7";

        element.style.color =
            "#166534";

        element.style.border =
            "1px solid #86efac";

    } else {

        element.style.background =
            "#fee2e2";

        element.style.color =
            "#991b1b";

        element.style.border =
            "1px solid #fca5a5";
    }


    clearTimeout(
        element._moneyflowTimer
    );


    element._moneyflowTimer =
        setTimeout(
            function() {

                element.style.display =
                    "none";

            },
            5000
        );
}


/* =========================================================
   GET VALUE
========================================================= */

function getValue(id) {

    const element =
        document.getElementById(id);


    if (!element) {

        return "";
    }


    return String(
        element.value || ""
    ).trim();
}


/* =========================================================
   SET VALUE
========================================================= */

function setValue(
    id,
    value
) {

    const element =
        document.getElementById(id);


    if (element) {

        element.value =
            value ?? "";
    }
}


/* =========================================================
   SET TEXT
========================================================= */

function setText(
    id,
    value
) {

    const element =
        document.getElementById(id);


    if (element) {

        element.textContent =
            value ?? "";
    }
}


/* =========================================================
   FORMAT MONEY
========================================================= */

function formatMoney(amount) {

    return `₹${Number(
        amount || 0
    ).toLocaleString(
        "en-IN",
        {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }
    )}`;
}


/* =========================================================
   FORMAT DATE
========================================================= */

function formatDate(value) {

    const date =
        new Date(value);


    if (
        Number.isNaN(
            date.getTime()
        )
    ) {

        return "Unknown";
    }


    return date.toLocaleDateString(
        "en-IN",
        {
            day: "2-digit",
            month: "short",
            year: "numeric"
        }
    );
}


/* =========================================================
   ESCAPE HTML
========================================================= */

function escapeHTML(value) {

    return String(
        value ?? ""
    )
        .replace(
            /&/g,
            "&amp;"
        )
        .replace(
            /</g,
            "&lt;"
        )
        .replace(
            />/g,
            "&gt;"
        )
        .replace(
            /"/g,
            "&quot;"
        )
        .replace(
            /'/g,
            "&#039;"
        );
}


/* =========================================================
   ESCAPE JAVASCRIPT STRING
========================================================= */

function escapeJS(value) {

    return String(
        value ?? ""
    )
        .replace(
            /\\/g,
            "\\\\"
        )
        .replace(
            /'/g,
            "\\'"
        );
}