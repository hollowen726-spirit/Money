/* MoneyFlow browser API: replaces the Electron preload bridge. */
(() => {
  async function request(path, body) {
    try {
      const response = await fetch(`/api/${path}`, {
        method: body === undefined ? 'GET' : 'POST',
        credentials: 'same-origin',
        headers: body === undefined ? {} : { 'Content-Type': 'application/json' },
        body: body === undefined ? undefined : JSON.stringify(body)
      });
      const data = await response.json();
      if (!response.ok && data && !data.message) data.message = 'Request failed.';
      return data;
    } catch (error) {
      console.error('MoneyFlow API:', error);
      return { success: false, message: 'Cannot connect to MoneyFlow server. Check your internet connection.' };
    }
  }
  window.moneyflow = {
    registerUser: data => request('register', data),
    loginUser: data => request('login', data),
    getUserData: () => request('data'),
    addIncome: data => request('income/add', data),
    deleteIncome: data => request('income/delete', data),
    addExpense: data => request('expense/add', data),
    deleteExpense: data => request('expense/delete', data),
    updateUPI: data => request('upi/update', data),
    addBankAccount: data => request('bank/add', data),
    updateBankAccount: data => request('bank/update', data),
    deleteBankAccount: data => request('bank/delete', data),
    addAutoPay: data => request('autopay/add', data),
    deleteAutoPay: data => request('autopay/delete', data),
    addGoal: data => request('goal/add', data),
    addGoalMoney: data => request('goal/contribute', data),
    deleteGoal: data => request('goal/delete', data),
    logout: () => request('logout', {})
  };
})();
