document.addEventListener("DOMContentLoaded", () => {

    const form = document.getElementById("loginForm");
    const message = document.getElementById("loginMessage");
    const signupButton = document.getElementById("signupButton");

    function showMessage(text, type) {
        message.textContent = text;
        message.className = "message " + type;
    }

    signupButton.addEventListener("click", () => {
        window.location.href = "signup.html";
    });

    form.addEventListener("submit", async (event) => {

        event.preventDefault();

        const email =
            document.getElementById("email").value.trim();

        const password =
            document.getElementById("password").value;

        if (!email || !password) {
            showMessage(
                "Please enter your email and password.",
                "error"
            );
            return;
        }

        try {

            const result = await window.moneyflow.loginUser({
                email,
                password
            });

            if (!result.success) {
                showMessage(result.message, "error");
                return;
            }

            localStorage.setItem(
                "moneyflowUser",
                JSON.stringify(result.user)
            );

            localStorage.setItem(
                "moneyflowUserId",
                result.user.id
            );

            window.location.href = "dashboard.html";

        } catch (error) {

            console.error(error);

            showMessage(
                "Unable to login. Please try again.",
                "error"
            );
        }

    });

});