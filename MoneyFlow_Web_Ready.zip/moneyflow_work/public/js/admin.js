"use strict";

const role =
    localStorage.getItem(
        "moneyflowUserRole"
    );

if (
    role !== "admin"
) {
    window.location.href =
        "login.html";
}

const usersList =
    document.getElementById(
        "usersList"
    );

function escapeHtml(value) {

    return String(
        value ?? ""
    )
        .replace(
            /&/g,
            "&amp;"
        )
        .replace(
            /</g,
            "&lt;"
        )
        .replace(
            />/g,
            "&gt;"
        )
        .replace(
            /"/g,
            "&quot;"
        )
        .replace(
            /'/g,
            "&#039;"
        );
}

function formatDate(
    value
) {

    if (!value) {
        return "-";
    }

    const d =
        new Date(value);

    if (
        Number.isNaN(
            d.getTime()
        )
    ) {
        return "-";
    }

    return d.toLocaleDateString(
        "en-IN"
    );
}

async function loadAdmin() {

    try {

        const data =
            await window.expenseAPI
                .getAllData();

        document.getElementById(
            "userCount"
        ).textContent =
            data.users.length;

        document.getElementById(
            "expenseCount"
        ).textContent =
            data.expenses.length;

        document.getElementById(
            "incomeCount"
        ).textContent =
            data.income.length;

        document.getElementById(
            "bankCount"
        ).textContent =
            data.bankAccounts.length;

        if (!data.users.length) {

            usersList.innerHTML =
                `<div
                    style="
                        padding:30px;
                        text-align:center;
                        color:#94a3b8;
                    "
                >
                    No registered users.
                </div>`;

            return;
        }

        usersList.innerHTML =
            data.users
                .map(
                    user => `
                        <div class="user-row">

                            <strong>
                                ${escapeHtml(
                                    user.name
                                )}
                            </strong>

                            <span>
                                ${escapeHtml(
                                    user.email
                                )}
                            </span>

                            <span>
                                Joined:
                                ${formatDate(
                                    user.createdAt
                                )}
                            </span>

                            <span>
                                Last used:
                                ${formatDate(
                                    user.lastUsedAt
                                )}
                            </span>

                        </div>
                    `
                )
                .join("");

    } catch (error) {

        console.error(
            "Admin error:",
            error
        );

        usersList.innerHTML =
            `<div
                style="
                    padding:20px;
                    color:#991b1b;
                "
            >
                Unable to load admin data.
            </div>`;
    }
}

document.getElementById(
    "refreshAdmin"
).addEventListener(
    "click",
    loadAdmin
);

document.getElementById(
    "logoutAdmin"
).addEventListener(
    "click",
    () => {

        localStorage.clear();

        window.location.href =
            "login.html";
    }
);

loadAdmin();