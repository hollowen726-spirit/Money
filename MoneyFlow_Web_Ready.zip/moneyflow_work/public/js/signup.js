document.addEventListener("DOMContentLoaded", () => {

    const form = document.getElementById("signupForm");
    const message = document.getElementById("signupMessage");

    document.getElementById("loginButton").addEventListener("click", () => {
        window.location.href = "login.html";
    });

    function showMessage(text, type) {
        message.textContent = text;
        message.className = "message " + type;
    }

    form.addEventListener("submit", async (event) => {

        event.preventDefault();

        const name =
            document.getElementById("name").value.trim();

        const phone =
            document.getElementById("phone").value.trim();

        const email =
            document.getElementById("email").value.trim();

        const password =
            document.getElementById("password").value;

        const confirmPassword =
            document.getElementById("confirmPassword").value;

        if (!name || !email || !password) {

            showMessage(
                "Please fill all required fields.",
                "error"
            );

            return;
        }

        if (password.length < 6) {

            showMessage(
                "Password must contain at least 6 characters.",
                "error"
            );

            return;
        }

        if (password !== confirmPassword) {

            showMessage(
                "Passwords do not match.",
                "error"
            );

            return;
        }

        try {

            const result = await window.moneyflow.registerUser({
                name,
                phone,
                email,
                password
            });

            if (!result.success) {

                showMessage(
                    result.message,
                    "error"
                );

                return;
            }

            showMessage(
                "Account created successfully! Redirecting to login...",
                "success"
            );

            form.reset();

            setTimeout(() => {
                window.location.href = "login.html";
            }, 1200);

        } catch (error) {

            console.error(error);

            showMessage(
                "Unable to create account.",
                "error"
            );
        }

    });

});