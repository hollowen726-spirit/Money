const path = require("path");
const fs = require("fs");
const notifier = require("node-notifier");

const databaseFile =
    path.join(
        __dirname,
        "expense-database.json"
    );


const TWO_DAYS =
    2 * 24 * 60 * 60 * 1000;

const THREE_DAYS =
    3 * 24 * 60 * 60 * 1000;


/* =========================================================
   LOAD DATABASE
   ========================================================= */

function loadDatabase() {

    try {

        if (
            !fs.existsSync(
                databaseFile
            )
        ) {
            return null;
        }

        const raw =
            fs.readFileSync(
                databaseFile,
                "utf8"
            );

        if (!raw.trim()) {
            return null;
        }

        const data =
            JSON.parse(raw);

        if (
            !Array.isArray(
                data.users
            )
        ) {
            data.users = [];
        }

        return data;

    } catch (error) {

        console.error(
            "Reminder database error:",
            error
        );

        return null;
    }
}


/* =========================================================
   SAVE DATABASE
   ========================================================= */

function saveDatabase(data) {

    try {

        fs.writeFileSync(
            databaseFile,
            JSON.stringify(
                data,
                null,
                2
            ),
            "utf8"
        );

        return true;

    } catch (error) {

        console.error(
            "Reminder save error:",
            error
        );

        return false;
    }
}


/* =========================================================
   SEND NOTIFICATION
   ========================================================= */

function sendNotification(
    title,
    message
) {

    try {

        notifier.notify({

            title,

            message,

            icon:
                path.join(
                    __dirname,
                    "src",
                    "moneyflow-icon.png"
                ),

            sound: true,

            wait: false,

            timeout: 10
        });

    } catch (error) {

        console.error(
            "Notification error:",
            error
        );
    }
}


/* =========================================================
   CHECK INACTIVITY
   ========================================================= */

function checkInactiveUsers() {

    const db =
        loadDatabase();

    if (!db) {
        return;
    }

    const now =
        Date.now();

    let changed = false;

    db.users.forEach(user => {

        if (!user.id) {
            return;
        }

        if (!user.lastActiveAt) {

            user.lastActiveAt =
                new Date().toISOString();

            changed = true;

            return;
        }

        const lastActive =
            new Date(
                user.lastActiveAt
            ).getTime();

        if (
            Number.isNaN(
                lastActive
            )
        ) {
            return;
        }

        const inactiveTime =
            now - lastActive;

        let notificationLevel =
            0;

        if (
            inactiveTime >=
            THREE_DAYS
        ) {

            notificationLevel = 3;

        } else if (
            inactiveTime >=
            TWO_DAYS
        ) {

            notificationLevel = 2;
        }

        if (
            notificationLevel === 0
        ) {
            return;
        }

        let alreadySent = false;

        if (
            user.lastReminderAt
        ) {

            const reminderTime =
                new Date(
                    user.lastReminderAt
                ).getTime();

            if (
                !Number.isNaN(
                    reminderTime
                ) &&
                reminderTime >
                    lastActive
            ) {

                alreadySent = true;
            }
        }

        if (alreadySent) {
            return;
        }


        if (
            notificationLevel === 3
        ) {

            sendNotification(

                "MoneyFlow - 3 Day Reminder",

                `Hi ${
                    user.name ||
                    "there"
                }, you haven't checked MoneyFlow for 3 days. Review your income, expenses and savings goals.`
            );

        } else {

            sendNotification(

                "MoneyFlow - 2 Day Reminder",

                `Hi ${
                    user.name ||
                    "there"
                }, you haven't checked MoneyFlow for 2 days. Open the app to review your finances.`
            );
        }


        user.lastReminderAt =
            new Date().toISOString();

        changed = true;
    });


    if (changed) {
        saveDatabase(db);
    }
}


/* =========================================================
   INITIAL CHECK
   ========================================================= */

checkInactiveUsers();


/* =========================================================
   CHECK EVERY 30 MINUTES
   ========================================================= */

setInterval(
    checkInactiveUsers,
    30 * 60 * 1000
);