'use strict';
const express = require('express');
const cookieSession = require('cookie-session');
const path = require('path');
const fs = require('fs');
const db = require('./database');

const app = express();
const PORT = process.env.PORT || 3000;
const isProduction = process.env.NODE_ENV === 'production';

app.set('trust proxy', 1);
app.use(express.json({ limit: '100kb' }));
app.use(cookieSession({
  name: 'moneyflow',
  keys: [process.env.SESSION_SECRET || 'replace-this-before-deploying-moneyflow'],
  httpOnly: true,
  sameSite: 'lax',
  secure: isProduction,
  maxAge: 7 * 24 * 60 * 60 * 1000
}));
app.use(express.static(path.join(__dirname, 'public')));

const wrap = fn => (req, res) => {
  try {
    const result = fn(req);
    res.json(result);
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: 'Something went wrong. Please try again.' });
  }
};
const requireAuth = (req, res, next) => {
  if (!req.session.userId) return res.status(401).json({ success: false, message: 'Please log in again.' });
  next();
};
const withUser = req => ({ ...(req.body || {}), userId: req.session.userId });

app.post('/api/register', wrap(req => db.registerUser(req.body || {})));
app.post('/api/login', (req, res) => {
  try {
    const result = db.loginUser(req.body || {});
    if (result.success) req.session.userId = result.user.id;
    res.json(result);
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: 'Unable to log in right now.' });
  }
});
app.post('/api/logout', (req, res) => { req.session = null; res.json({ success: true }); });
app.get('/api/data', requireAuth, wrap(req => db.getUserData(req.session.userId)));

const routes = {
  'income/add': data => db.addIncome(data),
  'income/delete': data => db.deleteIncome(data),
  'expense/add': data => db.addExpense(data),
  'expense/delete': data => db.deleteExpense(data),
  'upi/update': data => db.updateUPI(data),
  'bank/add': data => db.addBankAccount(data),
  'bank/update': data => db.updateBankAccount(data),
  'bank/delete': data => db.deleteBankAccount(data),
  'autopay/add': data => db.addAutoPay(data),
  'autopay/delete': data => db.deleteAutoPay(data),
  'goal/add': data => db.addGoal(data),
  'goal/contribute': data => db.addGoalMoney(data),
  'goal/delete': data => db.deleteGoal(data)
};
for (const [route, action] of Object.entries(routes)) {
  app.post(`/api/${route}`, requireAuth, wrap(req => action(withUser(req))));
}

app.get('/health', (_req, res) => res.json({ ok: true, app: 'MoneyFlow' }));
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api/')) return res.status(404).json({ success: false, message: 'API route not found.' });
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

app.listen(PORT, '0.0.0.0', () => console.log(`MoneyFlow web server listening on ${PORT}`));
