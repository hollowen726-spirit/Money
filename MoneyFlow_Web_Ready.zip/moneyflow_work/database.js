const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const databaseFile = process.env.MONEYFLOW_DB_FILE || path.join(__dirname, "expense-database.json");
fs.mkdirSync(path.dirname(databaseFile), { recursive: true });

const defaultDatabase = {
    users: [],
    incomes: [],
    expenses: [],
    bankAccounts: [],
    autopay: [],
    goals: []
};

function loadDatabase() {
    if (!fs.existsSync(databaseFile)) {
        saveDatabase(defaultDatabase);
    }

    try {
        const data = JSON.parse(fs.readFileSync(databaseFile, "utf8"));

        return {
            users: Array.isArray(data.users) ? data.users : [],
            incomes: Array.isArray(data.incomes)
                ? data.incomes
                : Array.isArray(data.income)
                    ? data.income
                    : [],
            expenses: Array.isArray(data.expenses) ? data.expenses : [],
            bankAccounts: Array.isArray(data.bankAccounts)
                ? data.bankAccounts
                : [],
            autopay: Array.isArray(data.autopay) ? data.autopay : [],
            goals: Array.isArray(data.goals) ? data.goals : []
        };
    } catch (error) {
        console.error("Database error:", error);
        return JSON.parse(JSON.stringify(defaultDatabase));
    }
}

function saveDatabase(data) {
    fs.writeFileSync(
        databaseFile,
        JSON.stringify(data, null, 2),
        "utf8"
    );
}

function createId() {
    return crypto.randomUUID();
}

function hashPassword(password, salt) {
    return crypto
        .pbkdf2Sync(password, salt, 120000, 64, "sha512")
        .toString("hex");
}

function createPasswordHash(password) {
    const salt = crypto.randomBytes(16).toString("hex");

    return {
        salt,
        hash: hashPassword(password, salt)
    };
}

function checkPassword(password, hash, salt) {
    return hashPassword(password, salt) === hash;
}

function cleanUser(user) {
    return {
        id: user.id,
        name: user.name,
        email: user.email,
        phone: user.phone || "",
        upiId: user.upiId || "",
        createdAt: user.createdAt
    };
}

/* ================= USERS ================= */

function registerUser(data) {
    const db = loadDatabase();

    const name = String(data.name || "").trim();
    const email = String(data.email || "").trim().toLowerCase();
    const phone = String(data.phone || "").trim();
    const password = String(data.password || "");

    if (!name || !email || !password) {
        return {
            success: false,
            message: "Please fill all required fields."
        };
    }

    if (password.length < 6) {
        return {
            success: false,
            message: "Password must contain at least 6 characters."
        };
    }

    if (db.users.some(user => user.email === email)) {
        return {
            success: false,
            message: "An account with this email already exists."
        };
    }

    const passwordData = createPasswordHash(password);

    const user = {
        id: createId(),
        name,
        email,
        phone,
        upiId: "",
        passwordHash: passwordData.hash,
        passwordSalt: passwordData.salt,
        createdAt: new Date().toISOString()
    };

    db.users.push(user);
    saveDatabase(db);

    return {
        success: true,
        message: "Account created successfully.",
        user: cleanUser(user)
    };
}

function loginUser(data) {
    const db = loadDatabase();

    const email = String(data.email || "").trim().toLowerCase();
    const password = String(data.password || "");

    const user = db.users.find(item => item.email === email);

    if (!user) {
        return {
            success: false,
            message: "Account not found."
        };
    }

    let valid = false;

    if (user.passwordHash && user.passwordSalt) {
        valid = checkPassword(
            password,
            user.passwordHash,
            user.passwordSalt
        );
    }

    if (!valid) {
        return {
            success: false,
            message: "Incorrect password."
        };
    }

    return {
        success: true,
        message: "Login successful.",
        user: cleanUser(user)
    };
}

/* ================= USER DATA ================= */

function getUserData(userId) {
    const db = loadDatabase();

    const user = db.users.find(
        item => String(item.id) === String(userId)
    );

    if (!user) {
        return {
            success: false,
            message: "User not found."
        };
    }

    return {
        success: true,

        user: cleanUser(user),

        incomes: db.incomes.filter(
            item => String(item.userId) === String(userId)
        ),

        expenses: db.expenses.filter(
            item => String(item.userId) === String(userId)
        ),

        bankAccounts: db.bankAccounts.filter(
            item => String(item.userId) === String(userId)
        ),

        autopay: db.autopay.filter(
            item => String(item.userId) === String(userId)
        ),

        goals: db.goals.filter(
            item => String(item.userId) === String(userId)
        )
    };
}

/* ================= UPI ================= */

function updateUPI(data) {
    const db = loadDatabase();

    const user = db.users.find(
        item => String(item.id) === String(data.userId)
    );

    if (!user) {
        return {
            success: false,
            message: "User not found."
        };
    }

    user.upiId = String(data.upiId || "").trim();

    saveDatabase(db);

    return {
        success: true,
        message: "UPI ID updated successfully."
    };
}

/* ================= INCOME ================= */

function addIncome(data) {
    const db = loadDatabase();

    const user = db.users.find(
        item => String(item.id) === String(data.userId)
    );

    if (!user) {
        return {
            success: false,
            message: "User not found."
        };
    }

    const amount = Number(data.amount);

    if (!amount || amount <= 0) {
        return {
            success: false,
            message: "Enter a valid income amount."
        };
    }

    const income = {
        id: createId(),
        userId: user.id,
        amount,
        source: String(data.source || "Other"),
        description: String(data.description || ""),
        date: data.date || new Date().toISOString()
    };

    db.incomes.push(income);
    saveDatabase(db);

    return {
        success: true,
        message: "Income added successfully.",
        income
    };
}

function deleteIncome(data) {
    const db = loadDatabase();

    const index = db.incomes.findIndex(
        item =>
            String(item.id) === String(data.id) &&
            String(item.userId) === String(data.userId)
    );

    if (index === -1) {
        return {
            success: false,
            message: "Income not found."
        };
    }

    db.incomes.splice(index, 1);
    saveDatabase(db);

    return {
        success: true,
        message: "Income deleted."
    };
}

/* ================= EXPENSE ================= */

function addExpense(data) {
    const db = loadDatabase();

    const user = db.users.find(
        item => String(item.id) === String(data.userId)
    );

    if (!user) {
        return {
            success: false,
            message: "User not found."
        };
    }

    const amount = Number(data.amount);

    if (!amount || amount <= 0) {
        return {
            success: false,
            message: "Enter a valid expense amount."
        };
    }

    const expense = {
        id: createId(),
        userId: user.id,
        amount,
        category: String(data.category || "Other"),
        description: String(data.description || ""),
        paymentMethod: String(data.paymentMethod || "Cash"),
        date: data.date || new Date().toISOString()
    };

    db.expenses.push(expense);
    saveDatabase(db);

    return {
        success: true,
        message: "Expense added successfully.",
        expense
    };
}

function deleteExpense(data) {
    const db = loadDatabase();

    const index = db.expenses.findIndex(
        item =>
            String(item.id) === String(data.id) &&
            String(item.userId) === String(data.userId)
    );

    if (index === -1) {
        return {
            success: false,
            message: "Expense not found."
        };
    }

    db.expenses.splice(index, 1);
    saveDatabase(db);

    return {
        success: true,
        message: "Expense deleted."
    };
}

/* ================= BANK ACCOUNTS ================= */

function addBankAccount(data) {
    const db = loadDatabase();

    const user = db.users.find(
        item => String(item.id) === String(data.userId)
    );

    if (!user) {
        return {
            success: false,
            message: "User not found."
        };
    }

    const account = {
        id: createId(),
        userId: user.id,
        bankName: String(data.bankName || "").trim(),
        accountHolder: String(data.accountHolder || "").trim(),
        accountType: String(data.accountType || "Savings"),
        accountNumber: String(data.accountNumber || "").trim(),
        ifsc: String(data.ifsc || "").trim().toUpperCase(),
        branch: String(data.branch || "").trim(),
        nickname: String(data.nickname || "").trim(),
        balance: Number(data.balance) || 0,
        createdAt: new Date().toISOString()
    };

    if (!account.bankName || !account.accountNumber) {
        return {
            success: false,
            message: "Bank name and account number are required."
        };
    }

    db.bankAccounts.push(account);
    saveDatabase(db);

    return {
        success: true,
        message: "Bank account added successfully.",
        account
    };
}

function updateBankAccount(data) {
    const db = loadDatabase();

    const account = db.bankAccounts.find(
        item =>
            String(item.id) === String(data.id) &&
            String(item.userId) === String(data.userId)
    );

    if (!account) {
        return {
            success: false,
            message: "Bank account not found."
        };
    }

    account.bankName = String(data.bankName || "");
    account.accountHolder = String(data.accountHolder || "");
    account.accountType = String(data.accountType || "Savings");
    account.accountNumber = String(data.accountNumber || "");
    account.ifsc = String(data.ifsc || "").toUpperCase();
    account.branch = String(data.branch || "");
    account.nickname = String(data.nickname || "");
    account.balance = Number(data.balance) || 0;

    saveDatabase(db);

    return {
        success: true,
        message: "Bank account updated successfully."
    };
}

function deleteBankAccount(data) {
    const db = loadDatabase();

    const index = db.bankAccounts.findIndex(
        item =>
            String(item.id) === String(data.id) &&
            String(item.userId) === String(data.userId)
    );

    if (index === -1) {
        return {
            success: false,
            message: "Bank account not found."
        };
    }

    db.bankAccounts.splice(index, 1);
    saveDatabase(db);

    return {
        success: true,
        message: "Bank account deleted."
    };
}

/* ================= AUTOPAY ================= */

function addAutoPay(data) {
    const db = loadDatabase();

    const user = db.users.find(
        item => String(item.id) === String(data.userId)
    );

    if (!user) {
        return {
            success: false,
            message: "User not found."
        };
    }

    const amount = Number(data.amount);

    if (!amount || amount <= 0) {
        return {
            success: false,
            message: "Enter a valid AutoPay amount."
        };
    }

    const payment = {
        id: createId(),
        userId: user.id,
        name: String(data.name || "Subscription"),
        amount,
        frequency: String(data.frequency || "Monthly"),
        dueDate: String(data.dueDate || "1"),
        paymentMethod: String(data.paymentMethod || "UPI"),
        active: true,
        createdAt: new Date().toISOString()
    };

    db.autopay.push(payment);
    saveDatabase(db);

    return {
        success: true,
        message: "AutoPay added successfully.",
        payment
    };
}

function deleteAutoPay(data) {
    const db = loadDatabase();

    const index = db.autopay.findIndex(
        item =>
            String(item.id) === String(data.id) &&
            String(item.userId) === String(data.userId)
    );

    if (index === -1) {
        return {
            success: false,
            message: "AutoPay not found."
        };
    }

    db.autopay.splice(index, 1);
    saveDatabase(db);

    return {
        success: true,
        message: "AutoPay deleted."
    };
}

/* ================= SAVINGS GOALS ================= */

function addGoal(data) {
    const db = loadDatabase();

    const user = db.users.find(
        item => String(item.id) === String(data.userId)
    );

    if (!user) {
        return {
            success: false,
            message: "User not found."
        };
    }

    const target = Number(data.targetAmount);

    if (!target || target <= 0) {
        return {
            success: false,
            message: "Enter a valid target amount."
        };
    }

    const goal = {
        id: createId(),
        userId: user.id,
        name: String(data.name || "Savings Goal"),
        targetAmount: target,
        savedAmount: 0,
        targetDate: String(data.targetDate || ""),
        createdAt: new Date().toISOString()
    };

    db.goals.push(goal);
    saveDatabase(db);

    return {
        success: true,
        message: "Savings goal created.",
        goal
    };
}

function addGoalMoney(data) {
    const db = loadDatabase();

    const goal = db.goals.find(
        item =>
            String(item.id) === String(data.id) &&
            String(item.userId) === String(data.userId)
    );

    if (!goal) {
        return {
            success: false,
            message: "Goal not found."
        };
    }

    const amount = Number(data.amount);

    if (!amount || amount <= 0) {
        return {
            success: false,
            message: "Enter a valid amount."
        };
    }

    goal.savedAmount += amount;

    if (goal.savedAmount > goal.targetAmount) {
        goal.savedAmount = goal.targetAmount;
    }

    saveDatabase(db);

    return {
        success: true,
        message: "Savings updated successfully."
    };
}

function deleteGoal(data) {
    const db = loadDatabase();

    const index = db.goals.findIndex(
        item =>
            String(item.id) === String(data.id) &&
            String(item.userId) === String(data.userId)
    );

    if (index === -1) {
        return {
            success: false,
            message: "Goal not found."
        };
    }

    db.goals.splice(index, 1);
    saveDatabase(db);

    return {
        success: true,
        message: "Savings goal deleted."
    };
}

module.exports = {
    registerUser,
    loginUser,
    getUserData,
    updateUPI,

    addIncome,
    deleteIncome,

    addExpense,
    deleteExpense,

    addBankAccount,
    updateBankAccount,
    deleteBankAccount,

    addAutoPay,
    deleteAutoPay,

    addGoal,
    addGoalMoney,
    deleteGoal
};