require("dotenv").config();

const database = require("./database");

const SETU_BASE_URL =
    process.env.SETU_BASE_URL ||
    "https://fiu-sandbox.setu.co";

const CLIENT_ID =
    process.env.SETU_CLIENT_ID;

const CLIENT_SECRET =
    process.env.SETU_CLIENT_SECRET;

const PRODUCT_INSTANCE_ID =
    process.env.SETU_PRODUCT_INSTANCE_ID;

let cachedToken = null;
let tokenExpiry = 0;

/* =========================================================
   CONFIGURATION
   ========================================================= */

function isConfigured() {
    return Boolean(
        CLIENT_ID &&
        CLIENT_SECRET &&
        PRODUCT_INSTANCE_ID
    );
}

/* =========================================================
   SETU TOKEN
   ========================================================= */

async function getAccessToken() {
    if (!isConfigured()) {
        throw new Error(
            "Setu credentials are not configured. Fill SETU_CLIENT_ID, SETU_CLIENT_SECRET and SETU_PRODUCT_INSTANCE_ID in .env."
        );
    }

    const now =
        Date.now();

    if (
        cachedToken &&
        now < tokenExpiry
    ) {
        return cachedToken;
    }

    /*
     * Setu's current OAuth token endpoint.
     */
    const response =
        await fetch(
            "https://uat.setu.co/api/v2/auth/token",
            {
                method: "POST",

                headers: {
                    "Content-Type":
                        "application/json"
                },

                body:
                    JSON.stringify({
                        clientID:
                            CLIENT_ID,
                        secret:
                            CLIENT_SECRET
                    })
            }
        );

    const data =
        await response.json();

    if (
        !response.ok ||
        !data ||
        !data.data ||
        !data.data.token
    ) {
        console.error(
            "SETU TOKEN ERROR:",
            data
        );

        throw new Error(
            data?.error?.detail ||
            "Unable to authenticate with Account Aggregator."
        );
    }

    cachedToken =
        data.data.token;

    const expiresIn =
        Number(
            data.data.expiresIn ||
            1800
        );

    /*
     * Refresh one minute before expiry.
     */
    tokenExpiry =
        Date.now() +
        Math.max(
            60,
            expiresIn - 60
        ) *
            1000;

    return cachedToken;
}

/* =========================================================
   COMMON REQUEST
   ========================================================= */

async function setuRequest(
    method,
    endpoint,
    body = null
) {
    const token =
        await getAccessToken();

    const options = {
        method,

        headers: {
            "Content-Type":
                "application/json",

            Authorization:
                `Bearer ${token}`,

            "x-product-instance-id":
                PRODUCT_INSTANCE_ID
        }
    };

    if (body !== null) {
        options.body =
            JSON.stringify(body);
    }

    let response =
        await fetch(
            `${SETU_BASE_URL}${endpoint}`,
            options
        );

    /*
     * Retry once if access token expired.
     */
    if (
        response.status === 401
    ) {
        cachedToken = null;
        tokenExpiry = 0;

        const retryToken =
            await getAccessToken();

        options.headers.Authorization =
            `Bearer ${retryToken}`;

        response =
            await fetch(
                `${SETU_BASE_URL}${endpoint}`,
                options
            );
    }

    const text =
        await response.text();

    let data = {};

    try {
        data =
            text
                ? JSON.parse(text)
                : {};
    } catch {
        data = {
            raw: text
        };
    }

    if (!response.ok) {
        console.error(
            "SETU REQUEST ERROR:",
            response.status,
            data
        );

        throw new Error(
            data?.errorMsg ||
            data?.error?.detail ||
            `Setu request failed with status ${response.status}`
        );
    }

    return data;
}

/* =========================================================
   ACCOUNT AVAILABILITY
   ========================================================= */

async function checkAccountAvailability(
    mobileNumber
) {
    const cleaned =
        String(
            mobileNumber || ""
        ).replace(
            /\D/g,
            ""
        );

    if (
        cleaned.length !== 10
    ) {
        return {
            success: false,
            message:
                "Enter a valid 10-digit Indian mobile number."
        };
    }

    try {
        const result =
            await setuRequest(
                "POST",
                "/v2/account-availability",
                {
                    mobileNumber:
                        cleaned
                }
            );

        return {
            success: true,
            data: result
        };
    } catch (error) {
        return {
            success: false,
            message:
                error.message
        };
    }
}

/* =========================================================
   CREATE BANK CONSENT
   ========================================================= */

async function createBankConsent(
    data
) {
    const mobile =
        String(
            data.mobileNumber ||
            ""
        ).replace(
            /\D/g,
            ""
        );

    if (
        mobile.length !== 10
    ) {
        return {
            success: false,
            message:
                "Valid mobile number is required."
        };
    }

    const now =
        new Date();

    const expiry =
        new Date(now);

    expiry.setMonth(
        expiry.getMonth() + 6
    );

    const from =
        new Date(now);

    from.setMonth(
        from.getMonth() -
            Number(
                process.env.BANK_SYNC_MONTHS ||
                3
            )
    );

    try {
        const consentBody = {
            consentDuration: {
                unit: "MONTH",
                value: 6
            },

            vua:
                mobile,

            consentTypes: [
                "TRANSACTIONS",
                "PROFILE",
                "SUMMARY"
            ],

            fiTypes: [
                "DEPOSIT"
            ],

            dataRange: {
                from:
                    from.toISOString(),
                to:
                    now.toISOString()
            },

            frequency: {
                unit: "MONTH",
                value: 1
            },

            fetchType:
                "PERIODIC"
        };

        const result =
            await setuRequest(
                "POST",
                "/v2/consents",
                consentBody
            );

        const consentId =
            result.id;

        const consentUrl =
            result.url;

        if (!consentId) {
            throw new Error(
                "Account Aggregator did not return a consent ID."
            );
        }

        database.saveBankConsent({
            userId:
                String(data.userId),

            mobileNumber:
                mobile,

            consentId,

            status:
                result.status ||
                "PENDING",

            consentUrl:
                consentUrl ||
                "",

            createdAt:
                new Date().toISOString(),

            updatedAt:
                new Date().toISOString()
        });

        return {
            success: true,

            consentId,

            status:
                result.status ||
                "PENDING",

            consentUrl:
                consentUrl ||
                ""
        };
    } catch (error) {
        return {
            success: false,
            message:
                error.message
        };
    }
}

/* =========================================================
   CONSENT STATUS
   ========================================================= */

async function getConsentStatus(
    userId,
    consentId
) {
    try {
        const result =
            await setuRequest(
                "GET",
                `/v2/consents/${encodeURIComponent(
                    consentId
                )}`
            );

        database.saveBankConsent({
            userId:
                String(userId),

            consentId,

            status:
                result.status ||
                "UNKNOWN",

            consentUrl:
                result.url ||
                ""
        });

        return {
            success: true,
            data: result
        };
    } catch (error) {
        return {
            success: false,
            message:
                error.message
        };
    }
}

/* =========================================================
   CREATE DATA SESSION
   ========================================================= */

async function createDataSession(
    userId,
    consentId
) {
    try {
        const now =
            new Date();

        const from =
            new Date(now);

        from.setMonth(
            from.getMonth() -
                Number(
                    process.env.BANK_SYNC_MONTHS ||
                    3
                )
        );

        const result =
            await setuRequest(
                "POST",
                "/v2/sessions",
                {
                    consentId,

                    dataRange: {
                        from:
                            from.toISOString(),
                        to:
                            now.toISOString()
                    },

                    format:
                        "json"
                }
            );

        return {
            success: true,
            data: result
        };
    } catch (error) {
        return {
            success: false,
            message:
                error.message
        };
    }
}

/* =========================================================
   GET DATA SESSION
   ========================================================= */

async function getDataSession(
    sessionId
) {
    try {
        const result =
            await setuRequest(
                "GET",
                `/v2/sessions/${encodeURIComponent(
                    sessionId
                )}`
            );

        return {
            success: true,
            data: result
        };
    } catch (error) {
        return {
            success: false,
            message:
                error.message
        };
    }
}

/* =========================================================
   NORMALIZE BANK ACCOUNT
   ========================================================= */

function extractAccountInformation(
    accountData
) {
    const account =
        accountData?.account ||
        accountData ||
        {};

    const profile =
        account.profile ||
        {};

    const summary =
        account.summary ||
        {};

    let holder = "";

    try {
        const holders =
            profile.holders;

        if (
            holders &&
            Array.isArray(
                holders.holder
            ) &&
            holders.holder.length
        ) {
            holder =
                holders.holder[0]
                    .name ||
                "";
        }
    } catch {
        holder = "";
    }

    const masked =
        account.maskedAccNumber ||
        account.maskedAccountNumber ||
        "";

    const last4 =
        String(masked)
            .replace(
                /\D/g,
                ""
            )
            .slice(-4);

    return {
        bankName:
            account.fipName ||
            account.bankName ||
            "Connected Bank",

        accountHolder:
            holder,

        accountType:
            account.type ||
            "Savings",

        accountNumberMasked:
            masked,

        accountNumberLast4:
            last4,

        ifsc:
            account.ifsc ||
            "",

        branch:
            account.branch ||
            "",

        balance:
            Number(
                summary.currentBalance ||
                summary.balance ||
                account.currentBalance ||
                0
            )
    };
}

/* =========================================================
   NORMALIZE TRANSACTIONS
   ========================================================= */

function extractTransactions(
    sessionData
) {
    const output = [];

    const fips =
        sessionData?.fips ||
        [];

    for (
        const fip
        of fips
    ) {
        const accounts =
            fip.accounts ||
            [];

        for (
            const account
            of accounts
        ) {
            const data =
                account.data ||
                {};

            const transactions =
                data.account?.transactions ||
                data.transactions ||
                [];

            for (
                const tx
                of transactions
            ) {
                const amount =
                    Number(
                        tx.amount ||
                        tx.value ||
                        0
                    );

                if (
                    amount <= 0
                ) {
                    continue;
                }

                const type =
                    String(
                        tx.type ||
                        tx.transactionType ||
                        tx.creditDebitType ||
                        "DEBIT"
                    ).toUpperCase();

                let normalizedType =
                    "DEBIT";

                if (
                    type.includes(
                        "CREDIT"
                    ) ||
                    type === "CR"
                ) {
                    normalizedType =
                        "CREDIT";
                }

                output.push({
                    transactionId:
                        tx.txnId ||
                        tx.transactionId ||
                        tx.id ||
                        tx.reference ||
                        `${account.linkRefNumber}_${tx.valueDate}_${amount}_${tx.narration}`,

                    amount,

                    type:
                        normalizedType,

                    mode:
                        tx.mode ||
                        "BANK",

                    narration:
                        tx.narration ||
                        tx.description ||
                        "Bank transaction",

                    merchant:
                        tx.narration ||
                        tx.description ||
                        "Bank transaction",

                    transactionDate:
                        tx.valueDate ||
                        tx.transactionTimestamp ||
                        tx.date ||
                        new Date().toISOString(),

                    reference:
                        tx.reference ||
                        tx.refNo ||
                        "",

                    linkRefNumber:
                        account.linkRefNumber,

                    maskedAccNumber:
                        account.maskedAccNumber
                });
            }
        }
    }

    return output;
}

/* =========================================================
   IMPORT SESSION DATA INTO MONEYFLOW
   ========================================================= */

async function importSessionData(
    userId,
    sessionData
) {
    const accounts = [];

    const fips =
        sessionData?.fips ||
        [];

    for (
        const fip
        of fips
    ) {
        const fipAccounts =
            fip.accounts ||
            [];

        for (
            const account
            of fipAccounts
        ) {
            const info =
                extractAccountInformation(
                    account.data
                );

            const existing =
                database
                    .getUserData(
                        userId
                    )
                    .bankAccounts
                    .find(
                        item =>
                            item.accountNumberMasked ===
                                info.accountNumberMasked &&
                            item.bankName ===
                                info.bankName
                    );

            let bankAccount;

            if (
                existing
            ) {
                database.updateBankAccount({
                    id:
                        existing.id,

                    ...info,

                    connected:
                        true,

                    consentId:
                        null,

                    isPrimary:
                        existing.isPrimary
                });

                bankAccount =
                    existing;
            } else {
                const added =
                    database.addBankAccount({
                        userId,

                        ...info,

                        connected:
                            true,

                        source:
                            "Account Aggregator",

                        isPrimary:
                            database
                                .getUserData(
                                    userId
                                )
                                .bankAccounts
                                .length ===
                            0
                    });

                bankAccount =
                    added.account;
            }

            accounts.push(
                bankAccount
            );

            /*
             * Import transactions belonging
             * to this account.
             */
            const transactions =
                account.data
                    ?.account
                    ?.transactions ||
                account.data
                    ?.transactions ||
                [];

            for (
                const tx
                of transactions
            ) {
                const amount =
                    Number(
                        tx.amount ||
                        tx.value ||
                        0
                    );

                if (
                    amount <= 0
                ) {
                    continue;
                }

                const rawType =
                    String(
                        tx.type ||
                        tx.transactionType ||
                        tx.creditDebitType ||
                        "DEBIT"
                    ).toUpperCase();

                const type =
                    rawType.includes(
                        "CREDIT"
                    ) ||
                    rawType === "CR"
                        ? "CREDIT"
                        : "DEBIT";

                database.importBankTransaction({
                    userId,

                    bankAccountId:
                        bankAccount.id,

                    transactionId:
                        tx.txnId ||
                        tx.transactionId ||
                        tx.id ||
                        tx.reference ||
                        `${account.linkRefNumber}_${tx.valueDate}_${amount}_${tx.narration}`,

                    amount,

                    type,

                    mode:
                        tx.mode ||
                        "BANK",

                    narration:
                        tx.narration ||
                        tx.description ||
                        "Bank transaction",

                    merchant:
                        tx.narration ||
                        tx.description ||
                        "Bank transaction",

                    transactionDate:
                        tx.valueDate ||
                        tx.transactionTimestamp ||
                        tx.date ||
                        new Date().toISOString(),

                    reference:
                        tx.reference ||
                        tx.refNo ||
                        ""
                });
            }
        }
    }

    return {
        success: true,
        accountsImported:
            accounts.length
    };
}

/* =========================================================
   COMPLETE SYNC
   ========================================================= */

async function syncBankAccount(
    userId,
    consentId
) {
    try {
        const consent =
            await getConsentStatus(
                userId,
                consentId
            );

        if (
            !consent.success
        ) {
            return consent;
        }

        const status =
            String(
                consent.data?.status ||
                ""
            ).toUpperCase();

        if (
            status !==
                "ACTIVE" &&
            status !==
                "APPROVED" &&
            status !==
                "READY"
        ) {
            return {
                success: false,
                pending: true,
                status,
                message:
                    `Consent is currently ${status || "PENDING"}. Approve the bank access request first.`
            };
        }

        const session =
            await createDataSession(
                userId,
                consentId
            );

        if (
            !session.success
        ) {
            return session;
        }

        const sessionId =
            session.data?.id;

        if (!sessionId) {
            return {
                success: false,
                message:
                    "No data session was returned."
            };
        }

        /*
         * Wait briefly for sandbox/FIP.
         */
        await new Promise(
            resolve =>
                setTimeout(
                    resolve,
                    3000
                )
        );

        const data =
            await getDataSession(
                sessionId
            );

        if (
            !data.success
        ) {
            return data;
        }

        const sessionStatus =
            String(
                data.data?.status ||
                ""
            ).toUpperCase();

        if (
            sessionStatus !==
                "COMPLETED" &&
            sessionStatus !==
                "PARTIAL"
        ) {
            return {
                success: false,
                pending: true,
                sessionId,
                status:
                    sessionStatus,
                message:
                    `Bank data is currently ${sessionStatus || "processing"}. Please sync again shortly.`
            };
        }

        const imported =
            await importSessionData(
                userId,
                data.data
            );

        return {
            success: true,
            sessionId,
            status:
                sessionStatus,
            ...imported
        };
    } catch (error) {
        console.error(
            "BANK SYNC ERROR:",
            error
        );

        return {
            success: false,
            message:
                error.message
        };
    }
}

module.exports = {
    isConfigured,
    checkAccountAvailability,
    createBankConsent,
    getConsentStatus,
    createDataSession,
    getDataSession,
    syncBankAccount
};