const { app, BrowserWindow, ipcMain, dialog } = require("electron");
const path = require("path");

const db = require("./database");

let mainWindow;

function createWindow() {
    mainWindow = new BrowserWindow({
        width: 1450,
        height: 900,
        minWidth: 1100,
        minHeight: 700,
        backgroundColor: "#07111f",
        webPreferences: {
            preload: path.join(__dirname, "preload.js"),
            contextIsolation: true,
            nodeIntegration: false
        },
        show: false
    });

    mainWindow.loadFile(path.join(__dirname, "src", "login.html"));

    mainWindow.once("ready-to-show", () => {
        mainWindow.show();
    });

    mainWindow.on("closed", () => {
        mainWindow = null;
    });
}

/* ---------------- USERS ---------------- */

ipcMain.handle("register-user", async (event, data) => {
    try {
        return db.registerUser(data);
    } catch (error) {
        return {
            success: false,
            message: error.message
        };
    }
});

ipcMain.handle("login-user", async (event, data) => {
    try {
        return db.loginUser(data);
    } catch (error) {
        return {
            success: false,
            message: error.message
        };
    }
});

/* ---------------- USER DATA ---------------- */

ipcMain.handle("get-user-data", async (event, userId) => {
    try {
        return db.getUserData(userId);
    } catch (error) {
        return {
            success: false,
            message: error.message
        };
    }
});

/* ---------------- INCOME ---------------- */

ipcMain.handle("add-income", async (event, data) => {
    try {
        return db.addIncome(data);
    } catch (error) {
        return {
            success: false,
            message: error.message
        };
    }
});

ipcMain.handle("delete-income", async (event, data) => {
    try {
        return db.deleteIncome(data);
    } catch (error) {
        return {
            success: false,
            message: error.message
        };
    }
});

/* ---------------- EXPENSE ---------------- */

ipcMain.handle("add-expense", async (event, data) => {
    try {
        return db.addExpense(data);
    } catch (error) {
        return {
            success: false,
            message: error.message
        };
    }
});

ipcMain.handle("delete-expense", async (event, data) => {
    try {
        return db.deleteExpense(data);
    } catch (error) {
        return {
            success: false,
            message: error.message
        };
    }
});

/* ---------------- UPI ---------------- */

ipcMain.handle("update-upi", async (event, data) => {
    try {
        return db.updateUPI(data);
    } catch (error) {
        return {
            success: false,
            message: error.message
        };
    }
});

/* ---------------- BANK ACCOUNTS ---------------- */

ipcMain.handle("add-bank-account", async (event, data) => {
    try {
        return db.addBankAccount(data);
    } catch (error) {
        return {
            success: false,
            message: error.message
        };
    }
});

ipcMain.handle("update-bank-account", async (event, data) => {
    try {
        return db.updateBankAccount(data);
    } catch (error) {
        return {
            success: false,
            message: error.message
        };
    }
});

ipcMain.handle("delete-bank-account", async (event, data) => {
    try {
        return db.deleteBankAccount(data);
    } catch (error) {
        return {
            success: false,
            message: error.message
        };
    }
});

/* ---------------- AUTOPAY ---------------- */

ipcMain.handle("add-autopay", async (event, data) => {
    try {
        return db.addAutoPay(data);
    } catch (error) {
        return {
            success: false,
            message: error.message
        };
    }
});

ipcMain.handle("delete-autopay", async (event, data) => {
    try {
        return db.deleteAutoPay(data);
    } catch (error) {
        return {
            success: false,
            message: error.message
        };
    }
});

/* ---------------- SAVINGS GOALS ---------------- */

ipcMain.handle("add-goal", async (event, data) => {
    try {
        return db.addGoal(data);
    } catch (error) {
        return {
            success: false,
            message: error.message
        };
    }
});

ipcMain.handle("add-goal-money", async (event, data) => {
    try {
        return db.addGoalMoney(data);
    } catch (error) {
        return {
            success: false,
            message: error.message
        };
    }
});

ipcMain.handle("delete-goal", async (event, data) => {
    try {
        return db.deleteGoal(data);
    } catch (error) {
        return {
            success: false,
            message: error.message
        };
    }
});

/* ---------------- DIALOG ---------------- */

ipcMain.handle("show-message", async (event, data) => {
    await dialog.showMessageBox(mainWindow, {
        type: data.type || "info",
        title: data.title || "MoneyFlow",
        message: data.message || ""
    });

    return { success: true };
});

app.whenReady().then(() => {
    createWindow();

    app.on("activate", () => {
        if (BrowserWindow.getAllWindows().length === 0) {
            createWindow();
        }
    });
});

app.on("window-all-closed", () => {
    if (process.platform !== "darwin") {
        app.quit();
    }
});