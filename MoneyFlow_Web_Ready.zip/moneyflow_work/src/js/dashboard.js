let currentUser = null;
let userData = {
    incomes: [],
    expenses: [],
    bankAccounts: [],
    autopay: [],
    goals: []
};

document.addEventListener("DOMContentLoaded", async () => {

    loadCurrentUser();

    if (!currentUser) {
        window.location.href = "login.html";
        return;
    }

    setupNavigation();
    setupForms();
    setupDate();

    await loadData();

    showSection("dashboardSection");
});


/* =====================================================
   USER
===================================================== */

function loadCurrentUser() {

    try {

        const stored =
            localStorage.getItem("moneyflowUser");

        if (!stored) {
            return;
        }

        currentUser = JSON.parse(stored);

    } catch (error) {

        console.error(error);

        localStorage.removeItem("moneyflowUser");
    }
}


/* =====================================================
   DATA
===================================================== */

async function loadData() {

    try {

        const result =
            await window.moneyflow.getUserData(
                currentUser.id
            );

        if (!result.success) {

            alert(result.message);

            logout();
            return;
        }

        currentUser = result.user;

        localStorage.setItem(
            "moneyflowUser",
            JSON.stringify(currentUser)
        );

        userData = {
            incomes: result.incomes || [],
            expenses: result.expenses || [],
            bankAccounts: result.bankAccounts || [],
            autopay: result.autopay || [],
            goals: result.goals || []
        };

        renderUser();
        renderDashboard();
        renderIncome();
        renderExpenses();
        renderBanks();
        renderAutoPay();
        renderGoals();
        renderHistory();

    } catch (error) {

        console.error(error);

        alert(
            "Unable to load your financial data."
        );
    }
}


/* =====================================================
   USER DISPLAY
===================================================== */

function renderUser() {

    const name =
        currentUser.name || "User";

    const email =
        currentUser.email || "";

    document.getElementById("welcomeName").textContent =
        name.split(" ")[0];

    document.getElementById("sidebarUserName").textContent =
        name;

    document.getElementById("sidebarUserEmail").textContent =
        email;

    document.getElementById("profileName").textContent =
        name;

    document.getElementById("profileEmail").textContent =
        email;

    document.getElementById("profilePhone").textContent =
        currentUser.phone || "Phone number not added";

    const letter =
        name.charAt(0).toUpperCase();

    document.getElementById("userAvatar").textContent =
        letter;

    document.getElementById("profileAvatar").textContent =
        letter;

    document.getElementById("upiId").value =
        currentUser.upiId || "";
}


/* =====================================================
   DASHBOARD
===================================================== */

function renderDashboard() {

    const totalIncome =
        userData.incomes.reduce(
            (sum, item) => sum + Number(item.amount || 0),
            0
        );

    const totalExpense =
        userData.expenses.reduce(
            (sum, item) => sum + Number(item.amount || 0),
            0
        );

    const bankBalance =
        userData.bankAccounts.reduce(
            (sum, item) => sum + Number(item.balance || 0),
            0
        );

    const goalSavings =
        userData.goals.reduce(
            (sum, item) => sum + Number(item.savedAmount || 0),
            0
        );

    const balance =
        totalIncome - totalExpense;

    document.getElementById("totalIncome").textContent =
        money(totalIncome);

    document.getElementById("totalExpense").textContent =
        money(totalExpense);

    document.getElementById("totalBalance").textContent =
        money(balance);

    document.getElementById("goalSavings").textContent =
        money(goalSavings);

    renderRecentTransactions();
}


/* =====================================================
   NAVIGATION
===================================================== */

function setupNavigation() {

    document.querySelectorAll(".nav-item").forEach(button => {

        button.addEventListener("click", () => {

            const section =
                button.dataset.section;

            showSection(section);

            document
                .getElementById("sidebar")
                .classList.remove("open");

        });

    });


    document.querySelectorAll("[data-go-section]").forEach(button => {

        button.addEventListener("click", () => {

            showSection(
                button.dataset.goSection
            );

        });

    });


    document
        .getElementById("logoutButton")
        .addEventListener("click", logout);


    document
        .getElementById("mobileMenuButton")
        .addEventListener("click", () => {

            document
                .getElementById("sidebar")
                .classList.toggle("open");

        });

}


function showSection(sectionId) {

    document
        .querySelectorAll(".page-section")
        .forEach(section => {

            section.classList.remove(
                "active-section"
            );

        });


    const selected =
        document.getElementById(sectionId);

    if (!selected) {
        return;
    }

    selected.classList.add("active-section");


    document
        .querySelectorAll(".nav-item")
        .forEach(button => {

            button.classList.toggle(
                "active",
                button.dataset.section === sectionId
            );

        });


    const titles = {

        dashboardSection:
            ["Dashboard", "Your complete financial overview"],

        incomeSection:
            ["Income", "Track money coming into your life"],

        expenseSection:
            ["Expenses", "Understand where your money goes"],

        bankSection:
            ["Bank Accounts", "Manage your connected accounts"],

        autopaySection:
            ["AutoPay", "Track recurring payments"],

        goalSection:
            ["Savings Goals", "Build your financial future"],

        historySection:
            ["History", "Your complete transaction timeline"],

        profileSection:
            ["Profile", "Manage your personal information"]

    };


    if (titles[sectionId]) {

        document.getElementById("pageTitle").textContent =
            titles[sectionId][0];

        document.getElementById("pageSubtitle").textContent =
            titles[sectionId][1];

    }

}


/* =====================================================
   FORMS
===================================================== */

function setupForms() {

    document
        .getElementById("incomeDate")
        .value = todayISO();

    document
        .getElementById("expenseDate")
        .value = todayISO();


    document
        .getElementById("incomeForm")
        .addEventListener("submit", addIncome);


    document
        .getElementById("expenseForm")
        .addEventListener("submit", addExpense);


    document
        .getElementById("bankForm")
        .addEventListener("submit", addBank);


    document
        .getElementById("autopayForm")
        .addEventListener("submit", addAutoPay);


    document
        .getElementById("goalForm")
        .addEventListener("submit", addGoal);


    document
        .getElementById("upiForm")
        .addEventListener("submit", saveUPI);

}


/* =====================================================
   INCOME
===================================================== */

async function addIncome(event) {

    event.preventDefault();

    const amount =
        Number(
            document.getElementById("incomeAmount").value
        );

    const source =
        document.getElementById("incomeSource").value;

    const description =
        document.getElementById("incomeDescription").value.trim();

    const date =
        document.getElementById("incomeDate").value;


    const result =
        await window.moneyflow.addIncome({

            userId: currentUser.id,
            amount,
            source,
            description,
            date: new Date(date).toISOString()

        });


    if (!result.success) {

        alert(result.message);
        return;
    }

    document
        .getElementById("incomeForm")
        .reset();

    document
        .getElementById("incomeDate")
        .value = todayISO();

    await loadData();

    showSection("incomeSection");
}


/* =====================================================
   EXPENSE
===================================================== */

async function addExpense(event) {

    event.preventDefault();

    const amount =
        Number(
            document.getElementById("expenseAmount").value
        );

    const category =
        document.getElementById("expenseCategory").value;

    const paymentMethod =
        document.getElementById("paymentMethod").value;

    const description =
        document.getElementById("expenseDescription").value.trim();

    const date =
        document.getElementById("expenseDate").value;


    const result =
        await window.moneyflow.addExpense({

            userId: currentUser.id,
            amount,
            category,
            paymentMethod,
            description,
            date: new Date(date).toISOString()

        });


    if (!result.success) {

        alert(result.message);
        return;
    }

    document
        .getElementById("expenseForm")
        .reset();

    document
        .getElementById("expenseDate")
        .value = todayISO();

    await loadData();

    showSection("expenseSection");
}


/* =====================================================
   UPI
===================================================== */

async function saveUPI(event) {

    event.preventDefault();

    const upiId =
        document.getElementById("upiId").value.trim();

    const result =
        await window.moneyflow.updateUPI({

            userId: currentUser.id,
            upiId

        });


    if (!result.success) {

        alert(result.message);
        return;
    }

    currentUser.upiId = upiId;

    localStorage.setItem(
        "moneyflowUser",
        JSON.stringify(currentUser)
    );

    alert("UPI ID saved successfully.");

}


/* =====================================================
   BANK
===================================================== */

async function addBank(event) {

    event.preventDefault();

    const data = {

        userId: currentUser.id,

        bankName:
            document.getElementById("bankName").value.trim(),

        accountHolder:
            document.getElementById("accountHolder").value.trim(),

        accountType:
            document.getElementById("accountType").value,

        accountNumber:
            document.getElementById("accountNumber").value.trim(),

        ifsc:
            document.getElementById("ifsc").value.trim(),

        branch:
            document.getElementById("branch").value.trim(),

        nickname:
            document.getElementById("bankNickname").value.trim(),

        balance:
            Number(
                document.getElementById("bankBalance").value
            )

    };


    const result =
        await window.moneyflow.addBankAccount(data);


    if (!result.success) {

        alert(result.message);
        return;
    }

    document
        .getElementById("bankForm")
        .reset();

    document
        .getElementById("bankBalance")
        .value = "0";

    await loadData();

    showSection("bankSection");
}


/* =====================================================
   AUTOPAY
===================================================== */

async function addAutoPay(event) {

    event.preventDefault();

    const data = {

        userId: currentUser.id,

        name:
            document.getElementById("autopayName").value.trim(),

        amount:
            Number(
                document.getElementById("autopayAmount").value
            ),

        frequency:
            document.getElementById("autopayFrequency").value,

        dueDate:
            document.getElementById("autopayDay").value,

        paymentMethod:
            document.getElementById("autopayMethod").value

    };


    const result =
        await window.moneyflow.addAutoPay(data);


    if (!result.success) {

        alert(result.message);
        return;
    }

    document
        .getElementById("autopayForm")
        .reset();

    document
        .getElementById("autopayDay")
        .value = "1";

    await loadData();

    showSection("autopaySection");
}


/* =====================================================
   GOALS
===================================================== */

async function addGoal(event) {

    event.preventDefault();

    const data = {

        userId: currentUser.id,

        name:
            document.getElementById("goalName").value.trim(),

        targetAmount:
            Number(
                document.getElementById("goalTarget").value
            ),

        targetDate:
            document.getElementById("goalDate").value

    };


    const result =
        await window.moneyflow.addGoal(data);


    if (!result.success) {

        alert(result.message);
        return;
    }

    document
        .getElementById("goalForm")
        .reset();

    await loadData();

    showSection("goalSection");
}


/* =====================================================
   RENDER INCOME
===================================================== */

function renderIncome() {

    const container =
        document.getElementById("incomeList");

    if (!userData.incomes.length) {

        container.innerHTML =
            empty("No income recorded yet.");

        return;
    }


    const items =
        [...userData.incomes]
            .sort((a, b) =>
                new Date(b.date) -
                new Date(a.date)
            );


    container.innerHTML =
        items.map(item => `

            <div class="transaction-item">

                <div class="transaction-left">

                    <div class="transaction-icon income-icon">
                        💰
                    </div>

                    <div>

                        <strong>
                            ${escapeHTML(item.source)}
                        </strong>

                        <small>
                            ${escapeHTML(item.description || "Income")}
                            • ${formatDate(item.date)}
                        </small>

                    </div>

                </div>

                <div>

                    <span class="money-positive">
                        +${money(item.amount)}
                    </span>

                    <button
                        class="delete-button"
                        onclick="deleteIncome('${item.id}')"
                    >
                        Delete
                    </button>

                </div>

            </div>

        `).join("");
}


/* =====================================================
   RENDER EXPENSE
===================================================== */

function renderExpenses() {

    const container =
        document.getElementById("expenseList");

    if (!userData.expenses.length) {

        container.innerHTML =
            empty("No expenses recorded yet.");

        return;
    }


    const items =
        [...userData.expenses]
            .sort((a, b) =>
                new Date(b.date) -
                new Date(a.date)
            );


    container.innerHTML =
        items.map(item => `

            <div class="transaction-item">

                <div class="transaction-left">

                    <div class="transaction-icon expense-icon">
                        💸
                    </div>

                    <div>

                        <strong>
                            ${escapeHTML(item.category)}
                        </strong>

                        <small>
                            ${escapeHTML(item.description || "Expense")}
                            • ${escapeHTML(item.paymentMethod)}
                            • ${formatDate(item.date)}
                        </small>

                    </div>

                </div>

                <div>

                    <span class="money-negative">
                        -${money(item.amount)}
                    </span>

                    <button
                        class="delete-button"
                        onclick="deleteExpense('${item.id}')"
                    >
                        Delete
                    </button>

                </div>

            </div>

        `).join("");
}


/* =====================================================
   BANK RENDER
===================================================== */

function renderBanks() {

    const container =
        document.getElementById("bankList");

    if (!userData.bankAccounts.length) {

        container.innerHTML =
            empty("No bank accounts added yet.");

        return;
    }


    container.innerHTML =
        userData.bankAccounts.map(account => `

            <div class="bank-account">

                <h3>
                    ${escapeHTML(
                        account.nickname ||
                        account.bankName
                    )}
                </h3>

                <small>
                    ${escapeHTML(account.bankName)}
                </small>

                <div class="account-number">
                    ${maskAccountNumber(account.accountNumber)}
                </div>

                <small>
                    ${escapeHTML(account.accountType)}
                    • ${escapeHTML(account.ifsc || "IFSC not added")}
                </small>

                <div class="bank-balance">
                    ${money(account.balance)}
                </div>

                <div class="bank-actions">

                    <button
                        class="remove-bank"
                        onclick="deleteBank('${account.id}')"
                    >
                        Delete
                    </button>

                </div>

            </div>

        `).join("");
}


/* =====================================================
   AUTOPAY RENDER
===================================================== */

function renderAutoPay() {

    const container =
        document.getElementById("autopayList");

    if (!userData.autopay.length) {

        container.innerHTML =
            empty("No AutoPay payments added yet.");

        return;
    }


    container.innerHTML =
        userData.autopay.map(item => `

            <div class="autopay-item">

                <div class="autopay-top">

                    <div>

                        <h3>
                            ${escapeHTML(item.name)}
                        </h3>

                        <div class="autopay-details">

                            ${escapeHTML(item.frequency)}
                            • Day ${escapeHTML(item.dueDate)}
                            • ${escapeHTML(item.paymentMethod)}

                        </div>

                    </div>

                    <div class="autopay-amount">
                        ${money(item.amount)}
                    </div>

                </div>

                <div class="bank-actions">

                    <button
                        class="remove-bank"
                        onclick="deleteAutoPay('${item.id}')"
                    >
                        Remove
                    </button>

                </div>

            </div>

        `).join("");
}


/* =====================================================
   GOALS RENDER
===================================================== */

function renderGoals() {

    const container =
        document.getElementById("goalList");

    if (!userData.goals.length) {

        container.innerHTML =
            empty("No savings goals created yet.");

        return;
    }


    container.innerHTML =
        userData.goals.map(goal => {

            const target =
                Number(goal.targetAmount) || 0;

            const saved =
                Number(goal.savedAmount) || 0;

            const percentage =
                target > 0
                    ? Math.min(
                        100,
                        Math.round(
                            (saved / target) * 100
                        )
                    )
                    : 0;

            return `

                <div class="goal-item">

                    <div class="goal-top">

                        <h3>
                            🎯 ${escapeHTML(goal.name)}
                        </h3>

                        <span class="goal-percent">
                            ${percentage}%
                        </span>

                    </div>

                    <div class="progress-bar">

                        <div
                            class="progress-fill"
                            style="width:${percentage}%"
                        ></div>

                    </div>

                    <div class="goal-info">

                        <span>
                            Saved ${money(saved)}
                        </span>

                        <span>
                            Target ${money(target)}
                        </span>

                    </div>

                    <div class="goal-actions">

                        <input
                            id="goalMoney-${goal.id}"
                            type="number"
                            min="1"
                            placeholder="Add savings"
                        >

                        <button
                            onclick="addGoalMoney('${goal.id}')"
                        >
                            Add
                        </button>

                        <button
                            onclick="deleteGoal('${goal.id}')"
                            style="background:#fee2e2;color:#991b1b;"
                        >
                            Delete
                        </button>

                    </div>

                </div>

            `;

        }).join("");
}


/* =====================================================
   HISTORY
===================================================== */

function renderHistory() {

    const container =
        document.getElementById("historyList");

    const all = [

        ...userData.incomes.map(item => ({
            ...item,
            type: "income"
        })),

        ...userData.expenses.map(item => ({
            ...item,
            type: "expense"
        }))

    ].sort(
        (a, b) =>
            new Date(b.date) -
            new Date(a.date)
    );


    if (!all.length) {

        container.innerHTML =
            empty("No transactions yet.");

        return;
    }


    container.innerHTML =
        all.map(item => {

            const isIncome =
                item.type === "income";

            return `

                <div class="history-row">

                    <div class="history-type ${
                        isIncome
                            ? "history-income"
                            : "history-expense"
                    }">

                        ${
                            isIncome
                                ? "INCOME"
                                : "EXPENSE"
                        }

                    </div>

                    <div>

                        <strong>
                            ${
                                escapeHTML(
                                    isIncome
                                        ? item.source
                                        : item.category
                                )
                            }
                        </strong>

                        <small>
                            ${
                                escapeHTML(
                                    item.description || ""
                                )
                            }
                            • ${formatDate(item.date)}
                        </small>

                    </div>

                    <strong class="${
                        isIncome
                            ? "money-positive"
                            : "money-negative"
                    }">

                        ${
                            isIncome ? "+" : "-"
                        }${money(item.amount)}

                    </strong>

                </div>

            `;

        }).join("");
}


/* =====================================================
   RECENT
===================================================== */

function renderRecentTransactions() {

    const container =
        document.getElementById("recentTransactions");

    const all = [

        ...userData.incomes.map(item => ({
            ...item,
            type: "income"
        })),

        ...userData.expenses.map(item => ({
            ...item,
            type: "expense"
        }))

    ].sort(
        (a, b) =>
            new Date(b.date) -
            new Date(a.date)
    ).slice(0, 6);


    if (!all.length) {

        container.innerHTML =
            empty("Your latest transactions will appear here.");

        return;
    }


    container.innerHTML =
        all.map(item => {

            const isIncome =
                item.type === "income";

            return `

                <div class="transaction-item">

                    <div class="transaction-left">

                        <div class="transaction-icon ${
                            isIncome
                                ? "income-icon"
                                : "expense-icon"
                        }">

                            ${
                                isIncome
                                    ? "💰"
                                    : "💸"
                            }

                        </div>

                        <div>

                            <strong>
                                ${
                                    escapeHTML(
                                        isIncome
                                            ? item.source
                                            : item.category
                                    )
                                }
                            </strong>

                            <small>
                                ${formatDate(item.date)}
                            </small>

                        </div>

                    </div>

                    <span class="${
                        isIncome
                            ? "money-positive"
                            : "money-negative"
                    }">

                        ${
                            isIncome ? "+" : "-"
                        }${money(item.amount)}

                    </span>

                </div>

            `;

        }).join("");
}


/* =====================================================
   DELETE FUNCTIONS
===================================================== */

async function deleteIncome(id) {

    if (!confirm("Delete this income?")) {
        return;
    }

    const result =
        await window.moneyflow.deleteIncome({

            id,
            userId: currentUser.id

        });

    if (result.success) {
        await loadData();
        showSection("incomeSection");
    } else {
        alert(result.message);
    }
}


async function deleteExpense(id) {

    if (!confirm("Delete this expense?")) {
        return;
    }

    const result =
        await window.moneyflow.deleteExpense({

            id,
            userId: currentUser.id

        });

    if (result.success) {
        await loadData();
        showSection("expenseSection");
    } else {
        alert(result.message);
    }
}


async function deleteBank(id) {

    if (!confirm("Delete this bank account?")) {
        return;
    }

    const result =
        await window.moneyflow.deleteBankAccount({

            id,
            userId: currentUser.id

        });

    if (result.success) {
        await loadData();
        showSection("bankSection");
    } else {
        alert(result.message);
    }
}


async function deleteAutoPay(id) {

    if (!confirm("Remove this AutoPay?")) {
        return;
    }

    const result =
        await window.moneyflow.deleteAutoPay({

            id,
            userId: currentUser.id

        });

    if (result.success) {
        await loadData();
        showSection("autopaySection");
    } else {
        alert(result.message);
    }
}


async function addGoalMoney(id) {

    const input =
        document.getElementById(
            `goalMoney-${id}`
        );

    const amount =
        Number(input.value);

    if (!amount || amount <= 0) {

        alert("Enter a valid savings amount.");
        return;
    }

    const result =
        await window.moneyflow.addGoalMoney({

            id,
            userId: currentUser.id,
            amount

        });

    if (result.success) {

        await loadData();

        showSection("goalSection");

    } else {

        alert(result.message);

    }
}


async function deleteGoal(id) {

    if (!confirm("Delete this savings goal?")) {
        return;
    }

    const result =
        await window.moneyflow.deleteGoal({

            id,
            userId: currentUser.id

        });

    if (result.success) {

        await loadData();

        showSection("goalSection");

    } else {

        alert(result.message);

    }
}


/* =====================================================
   LOGOUT
===================================================== */

function logout() {

    localStorage.removeItem("moneyflowUser");
    localStorage.removeItem("moneyflowUserId");

    window.location.href = "login.html";
}


/* =====================================================
   HELPERS
===================================================== */

function money(value) {

    return new Intl.NumberFormat(
        "en-IN",
        {
            style: "currency",
            currency: "INR",
            maximumFractionDigits: 2
        }
    ).format(Number(value) || 0);
}


function formatDate(date) {

    if (!date) {
        return "-";
    }

    const d =
        new Date(date);

    if (isNaN(d.getTime())) {
        return "-";
    }

    return d.toLocaleDateString(
        "en-IN",
        {
            day: "2-digit",
            month: "short",
            year: "numeric"
        }
    );
}


function todayISO() {

    const d =
        new Date();

    const month =
        String(d.getMonth() + 1)
            .padStart(2, "0");

    const day =
        String(d.getDate())
            .padStart(2, "0");

    return `${d.getFullYear()}-${month}-${day}`;
}


function setupDate() {

    document.getElementById(
        "todayDate"
    ).textContent =
        new Date().toLocaleDateString(
            "en-IN",
            {
                weekday: "long",
                day: "numeric",
                month: "long",
                year: "numeric"
            }
        );
}


function maskAccountNumber(number) {

    const value =
        String(number || "");

    if (value.length <= 4) {
        return "•••• " + value;
    }

    return "•••• •••• " +
        value.slice(-4);
}


function escapeHTML(value) {

    return String(value || "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}


function empty(text) {

    return `
        <div class="empty-state">
            🌱
            <br><br>
            ${escapeHTML(text)}
        </div>
    `;
}


/* Make functions available to HTML onclick */

window.deleteIncome = deleteIncome;
window.deleteExpense = deleteExpense;
window.deleteBank = deleteBank;
window.deleteAutoPay = deleteAutoPay;
window.addGoalMoney = addGoalMoney;
window.deleteGoal = deleteGoal;
window.logout = logout;