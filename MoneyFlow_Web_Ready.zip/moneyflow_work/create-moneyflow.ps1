$ErrorActionPreference = "Stop"

$root = Join-Path (Get-Location) "expense-tracker"

New-Item -ItemType Directory -Force -Path $root | Out-Null
New-Item -ItemType Directory -Force -Path "$root\src" | Out-Null
New-Item -ItemType Directory -Force -Path "$root\src\css" | Out-Null
New-Item -ItemType Directory -Force -Path "$root\src\js" | Out-Null

function Write-ProjectFile {
    param(
        [string]$Path,
        [string]$Content
    )

    $full = Join-Path $root $Path

    $parent = Split-Path $full -Parent

    if (!(Test-Path $parent)) {
        New-Item -ItemType Directory -Force -Path $parent | Out-Null
    }

    [System.IO.File]::WriteAllText(
        $full,
        $Content,
        [System.Text.UTF8Encoding]::new($false)
    )

    Write-Host "Created: $Path"
}

Write-ProjectFile "package.json" @'
{
  "name": "moneyflow-expense-tracker",
  "version": "1.0.0",
  "description": "MoneyFlow personal finance management desktop application",
  "main": "main.js",
  "author": "MoneyFlow",
  "license": "MIT",
  "scripts": {
    "start": "electron .",
    "check": "node --check database.js && node --check main.js && node --check preload.js && node --check src/js/login.js && node --check src/js/signup.js && node --check src/js/dashboard.js && node --check src/js/accounts.js && node --check src/js/admin.js"
  },
  "dependencies": {
    "bcryptjs": "^3.0.2"
  },
  "devDependencies": {
    "electron": "^38.0.0"
  }
}
'@

Write-ProjectFile "expense-database.json" @'
{
  "users": [],
  "expenses": [],
  "income": [],
  "autopay": [],
  "budgets": [],
  "goals": [],
  "bankAccounts": [],
  "bankTransactions": []
}
'@

Write-ProjectFile "main.js" @'
const {
    app,
    BrowserWindow,
    ipcMain,
    Notification
} = require("electron");

const path = require("path");

const db = require("./database");

let mainWindow = null;

function createWindow() {
    mainWindow = new BrowserWindow({
        width: 1450,
        height: 920,
        minWidth: 1100,
        minHeight: 700,
        backgroundColor: "#071f18",
        show: false,

        webPreferences: {
            preload: path.join(__dirname, "preload.js"),
            contextIsolation: true,
            nodeIntegration: false,
            sandbox: false
        }
    });

    mainWindow.loadFile(
        path.join(__dirname, "src", "login.html")
    );

    mainWindow.once("ready-to-show", () => {
        mainWindow.show();
    });
}

app.whenReady().then(() => {
    createWindow();

    app.on("activate", () => {
        if (BrowserWindow.getAllWindows().length === 0) {
            createWindow();
        }
    });
});

ipcMain.handle("register-user", (event, data) =>
    db.registerUser(data.name, data.email, data.password)
);

ipcMain.handle("login-user", (event, data) =>
    db.loginUser(data.email, data.password)
);

ipcMain.handle("add-expense", (event, data) =>
    db.addExpense(data)
);

ipcMain.handle("add-income", (event, data) =>
    db.addIncome(data)
);

ipcMain.handle("add-autopay", (event, data) =>
    db.addAutoPay(data)
);

ipcMain.handle("delete-autopay", (event, id) =>
    db.deleteAutoPay(id)
);

ipcMain.handle("process-autopay", (event, userId) =>
    db.processDueAutoPayments(userId)
);

ipcMain.handle("add-budget", (event, data) =>
    db.addBudget(data)
);

ipcMain.handle("delete-budget", (event, id) =>
    db.deleteBudget(id)
);

ipcMain.handle("add-goal", (event, data) =>
    db.addGoal(data)
);

ipcMain.handle("update-goal", (event, data) =>
    db.updateGoal(data.id, data.saved)
);

ipcMain.handle("delete-goal", (event, id) =>
    db.deleteGoal(id)
);

ipcMain.handle("add-bank-account", (event, data) =>
    db.addBankAccount(data)
);

ipcMain.handle("update-bank-account", (event, data) =>
    db.updateBankAccount(data)
);

ipcMain.handle("delete-bank-account", (event, id) =>
    db.deleteBankAccount(id)
);

ipcMain.handle("set-primary-bank-account", (event, data) =>
    db.setPrimaryBankAccount(data)
);

ipcMain.handle("import-bank-transactions", (event, data) =>
    db.importBankTransactions(data)
);

ipcMain.handle("get-user-data", (event, userId) => {
    try {
        return db.getUserData(userId);
    } catch (error) {
        console.error(error);

        return {
            success: false,
            message: "Unable to load financial data.",
            expenses: [],
            income: [],
            autopay: [],
            budgets: [],
            goals: [],
            bankAccounts: [],
            bankTransactions: []
        };
    }
});

ipcMain.handle("get-all-data", () =>
    db.getAllData()
);

ipcMain.handle("show-notification", (event, data) => {
    try {
        if (!Notification.isSupported()) {
            return { success: false };
        }

        new Notification({
            title: data.title || "MoneyFlow",
            body: data.body || "MoneyFlow reminder"
        }).show();

        return { success: true };
    } catch (error) {
        console.error(error);
        return { success: false };
    }
});

app.on("window-all-closed", () => {
    if (process.platform !== "darwin") {
        app.quit();
    }
});
'@

Write-ProjectFile "preload.js" @'
const {
    contextBridge,
    ipcRenderer
} = require("electron");

contextBridge.exposeInMainWorld("expenseAPI", {

    registerUser(data) {
        return ipcRenderer.invoke("register-user", data);
    },

    loginUser(data) {
        return ipcRenderer.invoke("login-user", data);
    },

    addExpense(data) {
        return ipcRenderer.invoke("add-expense", data);
    },

    addIncome(data) {
        return ipcRenderer.invoke("add-income", data);
    },

    addAutoPay(data) {
        return ipcRenderer.invoke("add-autopay", data);
    },

    deleteAutoPay(id) {
        return ipcRenderer.invoke("delete-autopay", id);
    },

    processAutoPay(userId) {
        return ipcRenderer.invoke("process-autopay", userId);
    },

    addBudget(data) {
        return ipcRenderer.invoke("add-budget", data);
    },

    deleteBudget(id) {
        return ipcRenderer.invoke("delete-budget", id);
    },

    addGoal(data) {
        return ipcRenderer.invoke("add-goal", data);
    },

    updateGoal(data) {
        return ipcRenderer.invoke("update-goal", data);
    },

    deleteGoal(id) {
        return ipcRenderer.invoke("delete-goal", id);
    },

    addBankAccount(data) {
        return ipcRenderer.invoke("add-bank-account", data);
    },

    updateBankAccount(data) {
        return ipcRenderer.invoke("update-bank-account", data);
    },

    deleteBankAccount(id) {
        return ipcRenderer.invoke("delete-bank-account", id);
    },

    setPrimaryBankAccount(data) {
        return ipcRenderer.invoke("set-primary-bank-account", data);
    },

    importBankTransactions(data) {
        return ipcRenderer.invoke("import-bank-transactions", data);
    },

    getUserData(userId) {
        return ipcRenderer.invoke("get-user-data", userId);
    },

    getAllData() {
        return ipcRenderer.invoke("get-all-data");
    },

    showNotification(data) {
        return ipcRenderer.invoke("show-notification", data);
    }
});
'@

Write-ProjectFile "database.js" @'
const fs = require("fs");
const path = require("path");
const bcrypt = require("bcryptjs");

const DATABASE_FILE = path.join(
    __dirname,
    "expense-database.json"
);

function emptyDatabase() {
    return {
        users: [],
        expenses: [],
        income: [],
        autopay: [],
        budgets: [],
        goals: [],
        bankAccounts: [],
        bankTransactions: []
    };
}

function loadDatabase() {
    try {
        if (!fs.existsSync(DATABASE_FILE)) {
            const data = emptyDatabase();
            saveDatabase(data);
            return data;
        }

        const raw = fs.readFileSync(
            DATABASE_FILE,
            "utf8"
        );

        if (!raw.trim()) {
            const data = emptyDatabase();
            saveDatabase(data);
            return data;
        }

        const data = JSON.parse(raw);

        for (const key of Object.keys(emptyDatabase())) {
            if (!Array.isArray(data[key])) {
                data[key] = [];
            }
        }

        return data;
    } catch (error) {
        console.error("DATABASE LOAD ERROR:", error);
        return emptyDatabase();
    }
}

function saveDatabase(data) {
    try {
        const temp =
            DATABASE_FILE + ".tmp";

        fs.writeFileSync(
            temp,
            JSON.stringify(data, null, 4),
            "utf8"
        );

        fs.renameSync(
            temp,
            DATABASE_FILE
        );

        return true;
    } catch (error) {
        console.error("DATABASE SAVE ERROR:", error);
        return false;
    }
}

function id(prefix) {
    return (
        prefix +
        "_" +
        Date.now().toString(36) +
        "_" +
        Math.random()
            .toString(36)
            .substring(2, 9)
    );
}

function iso() {
    return new Date().toISOString();
}

function email(value) {
    return String(value || "")
        .trim()
        .toLowerCase();
}

function registerUser(name, userEmail, password) {
    const data = loadDatabase();

    name = String(name || "").trim();
    userEmail = email(userEmail);
    password = String(password || "");

    if (!name || !userEmail || !password) {
        return {
            success: false,
            message: "Please fill all fields."
        };
    }

    if (password.length < 6) {
        return {
            success: false,
            message: "Password must contain at least 6 characters."
        };
    }

    if (
        data.users.some(
            user => email(user.email) === userEmail
        )
    ) {
        return {
            success: false,
            message: "Email is already registered."
        };
    }

    const user = {
        id: id("user"),
        name,
        email: userEmail,
        password: bcrypt.hashSync(password, 12),
        createdAt: iso(),
        lastUsedAt: iso()
    };

    data.users.push(user);

    if (!saveDatabase(data)) {
        return {
            success: false,
            message: "Unable to save account."
        };
    }

    return {
        success: true,
        message: "Account created successfully.",
        user: {
            id: user.id,
            name: user.name,
            email: user.email
        }
    };
}

function loginUser(userEmail, password) {
    const data = loadDatabase();

    userEmail = email(userEmail);
    password = String(password || "");

    if (
        userEmail === "admin@expense.com" &&
        password === "admin123"
    ) {
        return {
            success: true,
            admin: true,
            user: {
                id: "admin",
                name: "Administrator",
                email: "admin@expense.com"
            }
        };
    }

    const user = data.users.find(
        item => email(item.email) === userEmail
    );

    if (!user) {
        return {
            success: false,
            message: "Invalid email or password."
        };
    }

    let valid = false;

    try {
        if (
            user.password &&
            user.password.startsWith("$2")
        ) {
            valid = bcrypt.compareSync(
                password,
                user.password
            );
        } else {
            valid = user.password === password;

            if (valid) {
                user.password =
                    bcrypt.hashSync(password, 12);
            }
        }
    } catch {
        valid = false;
    }

    if (!valid) {
        return {
            success: false,
            message: "Invalid email or password."
        };
    }

    user.lastUsedAt = iso();
    saveDatabase(data);

    return {
        success: true,
        user: {
            id: user.id,
            name: user.name,
            email: user.email
        }
    };
}

function addExpense(item) {
    const data = loadDatabase();

    const expense = {
        id: id("expense"),
        userId: String(item.userId),
        amount: Number(item.amount),
        category: String(item.category || "Other"),
        description: String(item.description || ""),
        date:
            item.date ||
            new Date().toISOString().slice(0, 10),
        paymentMethod:
            String(item.paymentMethod || "Cash"),
        bankAccountId:
            item.bankAccountId
                ? String(item.bankAccountId)
                : null,
        classification:
            item.classification || "Need",
        source: item.source || "manual",
        isAutoPay: Boolean(item.isAutoPay),
        createdAt: iso()
    };

    if (
        !expense.userId ||
        !Number.isFinite(expense.amount) ||
        expense.amount <= 0
    ) {
        return {
            success: false,
            message: "Enter a valid expense amount."
        };
    }

    if (expense.bankAccountId) {
        changeBalance(
            data,
            expense.bankAccountId,
            -expense.amount
        );
    }

    data.expenses.push(expense);

    saveDatabase(data);

    return {
        success: true,
        message: "Expense added successfully.",
        expense
    };
}

function addIncome(item) {
    const data = loadDatabase();

    const income = {
        id: id("income"),
        userId: String(item.userId),
        amount: Number(item.amount),
        source:
            String(item.source || "Other"),
        description:
            String(item.description || ""),
        date:
            item.date ||
            new Date().toISOString().slice(0, 10),
        bankAccountId:
            item.bankAccountId
                ? String(item.bankAccountId)
                : null,
        sourceType:
            item.sourceType || "manual",
        transactionId:
            item.transactionId || null,
        createdAt: iso()
    };

    if (
        !income.userId ||
        !Number.isFinite(income.amount) ||
        income.amount <= 0
    ) {
        return {
            success: false,
            message: "Enter a valid income amount."
        };
    }

    if (income.bankAccountId) {
        changeBalance(
            data,
            income.bankAccountId,
            income.amount
        );
    }

    data.income.push(income);

    saveDatabase(data);

    return {
        success: true,
        message: "Income added successfully.",
        income
    };
}

function addAutoPay(item) {
    const data = loadDatabase();

    const record = {
        id: id("autopay"),
        userId: String(item.userId),
        name:
            String(item.name || "Automatic Payment"),
        amount: Number(item.amount),
        category:
            String(item.category || "Bills"),
        frequency:
            item.frequency || "Monthly",
        nextDate:
            item.nextDate ||
            new Date().toISOString().slice(0, 10),
        bankAccountId:
            item.bankAccountId
                ? String(item.bankAccountId)
                : null,
        active: true,
        createdAt: iso()
    };

    if (
        !record.userId ||
        !Number.isFinite(record.amount) ||
        record.amount <= 0
    ) {
        return {
            success: false,
            message: "Enter valid Auto-Pay information."
        };
    }

    data.autopay.push(record);
    saveDatabase(data);

    return {
        success: true,
        message: "Auto-Pay added successfully.",
        autopay: record
    };
}

function deleteAutoPay(recordId) {
    const data = loadDatabase();

    const before = data.autopay.length;

    data.autopay = data.autopay.filter(
        item =>
            String(item.id) !== String(recordId)
    );

    if (before === data.autopay.length) {
        return {
            success: false,
            message: "Auto-Pay was not found."
        };
    }

    saveDatabase(data);

    return {
        success: true,
        message: "Auto-Pay deleted."
    };
}

function processDueAutoPayments(userId) {
    const data = loadDatabase();

    const today =
        new Date().toISOString().slice(0, 10);

    let processed = 0;

    for (const item of data.autopay) {
        if (
            String(item.userId) !==
            String(userId)
        ) {
            continue;
        }

        if (!item.active) {
            continue;
        }

        if (String(item.nextDate) > today) {
            continue;
        }

        const duplicate = data.expenses.some(
            expense =>
                expense.autoPayId === item.id &&
                expense.date === item.nextDate
        );

        if (duplicate) {
            continue;
        }

        data.expenses.push({
            id: id("expense"),
            userId: String(userId),
            amount: item.amount,
            category: item.category,
            description:
                item.name + " - Auto-Pay",
            date: item.nextDate,
            paymentMethod: "Auto-Pay",
            bankAccountId:
                item.bankAccountId || null,
            classification: "Need",
            isAutoPay: true,
            autoPayId: item.id,
            source: "autopay",
            createdAt: iso()
        });

        if (item.bankAccountId) {
            changeBalance(
                data,
                item.bankAccountId,
                -item.amount
            );
        }

        const next = new Date(item.nextDate);

        if (item.frequency === "Weekly") {
            next.setDate(next.getDate() + 7);
        } else if (item.frequency === "Yearly") {
            next.setFullYear(next.getFullYear() + 1);
        } else {
            next.setMonth(next.getMonth() + 1);
        }

        item.nextDate =
            next.toISOString().slice(0, 10);

        processed++;
    }

    saveDatabase(data);

    return {
        success: true,
        processed,
        message:
            processed
                ? `${processed} Auto-Pay transaction(s) processed.`
                : "No Auto-Pay transactions are due."
    };
}

function addBudget(item) {
    const data = loadDatabase();

    const userId = String(item.userId);
    const category =
        String(item.category || "Other");

    const month =
        item.month ||
        new Date().toISOString().slice(0, 7);

    const amount = Number(item.amount);

    if (!userId || !Number.isFinite(amount) || amount <= 0) {
        return {
            success: false,
            message: "Enter a valid budget."
        };
    }

    const existing = data.budgets.find(
        budget =>
            String(budget.userId) === userId &&
            budget.category === category &&
            budget.month === month
    );

    if (existing) {
        existing.amount = amount;
        existing.updatedAt = iso();
    } else {
        data.budgets.push({
            id: id("budget"),
            userId,
            category,
            amount,
            month,
            createdAt: iso(),
            updatedAt: iso()
        });
    }

    saveDatabase(data);

    return {
        success: true,
        message: "Budget saved successfully."
    };
}

function deleteBudget(recordId) {
    const data = loadDatabase();

    data.budgets = data.budgets.filter(
        item =>
            String(item.id) !== String(recordId)
    );

    saveDatabase(data);

    return {
        success: true,
        message: "Budget deleted."
    };
}

function addGoal(item) {
    const data = loadDatabase();

    const goal = {
        id: id("goal"),
        userId: String(item.userId),
        name: String(item.name || "Savings Goal"),
        target: Number(item.target),
        saved: Number(item.saved || 0),
        deadline: item.deadline || "",
        createdAt: iso()
    };

    if (
        !goal.userId ||
        !Number.isFinite(goal.target) ||
        goal.target <= 0
    ) {
        return {
            success: false,
            message: "Enter a valid savings goal."
        };
    }

    data.goals.push(goal);
    saveDatabase(data);

    return {
        success: true,
        message: "Savings goal created.",
        goal
    };
}

function updateGoal(recordId, saved) {
    const data = loadDatabase();

    const goal = data.goals.find(
        item =>
            String(item.id) === String(recordId)
    );

    if (!goal) {
        return {
            success: false,
            message: "Savings goal not found."
        };
    }

    goal.saved = Math.max(0, Number(saved) || 0);

    saveDatabase(data);

    return {
        success: true,
        message: "Savings goal updated.",
        goal
    };
}

function deleteGoal(recordId) {
    const data = loadDatabase();

    data.goals = data.goals.filter(
        item =>
            String(item.id) !== String(recordId)
    );

    saveDatabase(data);

    return {
        success: true,
        message: "Savings goal deleted."
    };
}

/* BANK ACCOUNTS */

function maskAccount(last4) {
    const value =
        String(last4 || "")
            .replace(/\D/g, "")
            .slice(-4);

    return value
        ? `XXXX XXXX ${value}`
        : "XXXX XXXX XXXX";
}

function addBankAccount(item) {
    const data = loadDatabase();

    const account = {
        id: id("bank"),
        userId: String(item.userId),
        bankName:
            String(item.bankName || "").trim(),
        accountHolder:
            String(item.accountHolder || "").trim(),
        accountType:
            String(item.accountType || "Savings"),
        accountNumberLast4:
            String(item.accountNumberLast4 || "")
                .replace(/\D/g, "")
                .slice(-4),
        accountNumberMasked:
            maskAccount(item.accountNumberLast4),
        ifsc:
            String(item.ifsc || "")
                .trim()
                .toUpperCase(),
        branch:
            String(item.branch || "").trim(),
        upiId:
            String(item.upiId || "").trim(),
        nickname:
            String(
                item.nickname ||
                item.bankName ||
                "Bank Account"
            ).trim(),
        balance: Number(item.balance || 0),
        isPrimary: Boolean(item.isPrimary),
        createdAt: iso(),
        updatedAt: iso()
    };

    if (
        !account.userId ||
        !account.bankName ||
        !account.accountHolder
    ) {
        return {
            success: false,
            message:
                "Bank name and account holder are required."
        };
    }

    if (account.isPrimary) {
        data.bankAccounts
            .filter(
                a =>
                    String(a.userId) ===
                    account.userId
            )
            .forEach(
                a => (a.isPrimary = false)
            );
    }

    data.bankAccounts.push(account);
    saveDatabase(data);

    return {
        success: true,
        message: "Bank account added successfully.",
        account
    };
}

function updateBankAccount(item) {
    const data = loadDatabase();

    const account = data.bankAccounts.find(
        a =>
            String(a.id) === String(item.id) &&
            String(a.userId) === String(item.userId)
    );

    if (!account) {
        return {
            success: false,
            message: "Bank account not found."
        };
    }

    account.bankName =
        String(item.bankName || account.bankName).trim();

    account.accountHolder =
        String(
            item.accountHolder ||
            account.accountHolder
        ).trim();

    account.accountType =
        item.accountType || account.accountType;

    account.accountNumberLast4 =
        String(
            item.accountNumberLast4 ||
            account.accountNumberLast4 ||
            ""
        )
            .replace(/\D/g, "")
            .slice(-4);

    account.accountNumberMasked =
        maskAccount(account.accountNumberLast4);

    account.ifsc =
        String(item.ifsc || account.ifsc || "")
            .trim()
            .toUpperCase();

    account.branch =
        String(item.branch || account.branch || "").trim();

    account.upiId =
        String(item.upiId || account.upiId || "").trim();

    account.nickname =
        String(
            item.nickname ||
            account.nickname ||
            account.bankName
        ).trim();

    if (item.balance !== undefined) {
        account.balance = Number(item.balance);
    }

    if (item.isPrimary) {
        data.bankAccounts
            .filter(
                a =>
                    String(a.userId) ===
                    String(account.userId)
            )
            .forEach(
                a => (a.isPrimary = false)
            );

        account.isPrimary = true;
    }

    account.updatedAt = iso();

    saveDatabase(data);

    return {
        success: true,
        message: "Bank account updated.",
        account
    };
}

function deleteBankAccount(recordId) {
    const data = loadDatabase();

    data.bankAccounts =
        data.bankAccounts.filter(
            account =>
                String(account.id) !==
                String(recordId)
        );

    data.bankTransactions =
        data.bankTransactions.filter(
            transaction =>
                String(transaction.bankAccountId) !==
                String(recordId)
        );

    saveDatabase(data);

    return {
        success: true,
        message: "Bank account deleted."
    };
}

function setPrimaryBankAccount(item) {
    const data = loadDatabase();

    const account = data.bankAccounts.find(
        a =>
            String(a.id) === String(item.id) &&
            String(a.userId) === String(item.userId)
    );

    if (!account) {
        return {
            success: false,
            message: "Bank account not found."
        };
    }

    data.bankAccounts
        .filter(
            a =>
                String(a.userId) ===
                String(item.userId)
        )
        .forEach(
            a => (a.isPrimary = false)
        );

    account.isPrimary = true;
    account.updatedAt = iso();

    saveDatabase(data);

    return {
        success: true,
        message: "Primary bank account changed."
    };
}

function changeBalance(data, accountId, amount) {
    const account = data.bankAccounts.find(
        a =>
            String(a.id) ===
            String(accountId)
    );

    if (!account) {
        return;
    }

    account.balance =
        Number(account.balance || 0) +
        Number(amount || 0);

    account.updatedAt = iso();
}

/* CSV BANK STATEMENT */

function csvLine(line) {
    const result = [];
    let value = "";
    let quotes = false;

    for (let i = 0; i < line.length; i++) {
        const ch = line[i];

        if (ch === '"') {
            if (quotes && line[i + 1] === '"') {
                value += '"';
                i++;
            } else {
                quotes = !quotes;
            }
        } else if (ch === "," && !quotes) {
            result.push(value.trim());
            value = "";
        } else {
            value += ch;
        }
    }

    result.push(value.trim());

    return result;
}

function money(value) {
    const clean =
        String(value || "")
            .replace(/₹/g, "")
            .replace(/INR/gi, "")
            .replace(/Rs\.?/gi, "")
            .replace(/,/g, "")
            .trim();

    const n = Number(clean);

    return Number.isFinite(n) ? n : 0;
}

function transactionType(value) {
    const text =
        String(value || "").toLowerCase();

    if (
        /credit|credited|received|salary|deposit|refund|cashback/.test(
            text
        )
    ) {
        return "credit";
    }

    if (
        /debit|debited|paid|payment|withdraw|purchase|sent|transfer/.test(
            text
        )
    ) {
        return "debit";
    }

    return null;
}

function importBankTransactions(item) {
    const data = loadDatabase();

    const userId = String(item.userId || "");
    const accountId =
        String(item.bankAccountId || "");

    const csv = String(item.csvText || "");

    const account = data.bankAccounts.find(
        a =>
            String(a.id) === accountId &&
            String(a.userId) === userId
    );

    if (!account) {
        return {
            success: false,
            message: "Bank account not found."
        };
    }

    const lines = csv
        .split(/\r?\n/)
        .map(x => x.trim())
        .filter(Boolean);

    if (lines.length < 2) {
        return {
            success: false,
            message: "CSV file has no transactions."
        };
    }

    const headers = csvLine(lines[0]).map(
        x =>
            x
                .toLowerCase()
                .replace(/\s+/g, "")
    );

    const find = names =>
        headers.findIndex(
            h => names.includes(h)
        );

    const dateIndex = find([
        "date",
        "transactiondate",
        "valuedate",
        "postingdate"
    ]);

    const descriptionIndex = find([
        "description",
        "narration",
        "details",
        "particulars",
        "remarks",
        "merchant"
    ]);

    const amountIndex = find([
        "amount",
        "transactionamount"
    ]);

    const typeIndex = find([
        "type",
        "transactiontype",
        "drcr",
        "creditdebit"
    ]);

    const debitIndex = find([
        "debit",
        "withdrawal",
        "withdrawals"
    ]);

    const creditIndex = find([
        "credit",
        "deposit",
        "deposits"
    ]);

    let imported = 0;
    let skipped = 0;
    let incomeTotal = 0;
    let expenseTotal = 0;

    for (let i = 1; i < lines.length; i++) {
        const row = csvLine(lines[i]);

        const date =
            dateIndex >= 0
                ? row[dateIndex]
                : new Date().toISOString().slice(0, 10);

        const description =
            descriptionIndex >= 0
                ? row[descriptionIndex]
                : "Bank Transaction";

        let amount = 0;
        let type = null;

        if (amountIndex >= 0) {
            amount = money(row[amountIndex]);
        }

        if (typeIndex >= 0) {
            type = transactionType(row[typeIndex]);
        }

        if (!type) {
            type = transactionType(lines[i]);
        }

        if (!type && debitIndex >= 0 && row[debitIndex]) {
            amount = money(row[debitIndex]);
            type = "debit";
        }

        if (!type && creditIndex >= 0 && row[creditIndex]) {
            amount = money(row[creditIndex]);
            type = "credit";
        }

        if (!amount || !type) {
            skipped++;
            continue;
        }

        const key =
            [
                accountId,
                date,
                description,
                amount,
                type
            ].join("|");

        const duplicate =
            data.bankTransactions.some(
                t => t.transactionKey === key
            );

        if (duplicate) {
            skipped++;
            continue;
        }

        const transaction = {
            id: id("transaction"),
            userId,
            bankAccountId: accountId,
            transactionKey: key,
            date,
            description,
            amount,
            type,
            createdAt: iso()
        };

        data.bankTransactions.push(transaction);

        if (type === "credit") {
            data.income.push({
                id: id("income"),
                userId,
                amount,
                source: description,
                description:
                    "Imported from bank statement",
                date,
                bankAccountId: accountId,
                transactionId: transaction.id,
                sourceType: "bank-import",
                createdAt: iso()
            });

            changeBalance(
                data,
                accountId,
                amount
            );

            incomeTotal += amount;
        } else {
            data.expenses.push({
                id: id("expense"),
                userId,
                amount,
                category: "Bank Transaction",
                description,
                date,
                paymentMethod: "Bank",
                bankAccountId: accountId,
                classification: "Need",
                source: "bank-import",
                transactionId: transaction.id,
                createdAt: iso()
            });

            changeBalance(
                data,
                accountId,
                -amount
            );

            expenseTotal += amount;
        }

        imported++;
    }

    saveDatabase(data);

    return {
        success: true,
        message:
            `${imported} transaction(s) imported successfully.`,
        imported,
        skipped,
        incomeTotal,
        expenseTotal
    };
}

function getUserData(userId) {
    const data = loadDatabase();

    const idValue = String(userId);

    const user = data.users.find(
        u =>
            String(u.id) ===
            idValue
    );

    if (!user) {
        return {
            success: false,
            message: "User not found.",
            expenses: [],
            income: [],
            autopay: [],
            budgets: [],
            goals: [],
            bankAccounts: [],
            bankTransactions: []
        };
    }

    user.lastUsedAt = iso();
    saveDatabase(data);

    return {
        success: true,

        user: {
            id: user.id,
            name: user.name,
            email: user.email,
            lastUsedAt: user.lastUsedAt
        },

        expenses:
            data.expenses.filter(
                x =>
                    String(x.userId) ===
                    idValue
            ),

        income:
            data.income.filter(
                x =>
                    String(x.userId) ===
                    idValue
            ),

        autopay:
            data.autopay.filter(
                x =>
                    String(x.userId) ===
                    idValue
            ),

        budgets:
            data.budgets.filter(
                x =>
                    String(x.userId) ===
                    idValue
            ),

        goals:
            data.goals.filter(
                x =>
                    String(x.userId) ===
                    idValue
            ),

        bankAccounts:
            data.bankAccounts.filter(
                x =>
                    String(x.userId) ===
                    idValue
            ),

        bankTransactions:
            data.bankTransactions.filter(
                x =>
                    String(x.userId) ===
                    idValue
            )
    };
}

function getAllData() {
    const data = loadDatabase();

    return {
        success: true,

        users: data.users.map(
            user => ({
                id: user.id,
                name: user.name,
                email: user.email,
                createdAt: user.createdAt,
                lastUsedAt: user.lastUsedAt
            })
        ),

        expenses: data.expenses,
        income: data.income,
        autopay: data.autopay,
        budgets: data.budgets,
        goals: data.goals,
        bankAccounts: data.bankAccounts,
        bankTransactions:
            data.bankTransactions
    };
}

module.exports = {
    registerUser,
    loginUser,
    addExpense,
    addIncome,
    addAutoPay,
    deleteAutoPay,
    processDueAutoPayments,
    addBudget,
    deleteBudget,
    addGoal,
    updateGoal,
    deleteGoal,
    addBankAccount,
    updateBankAccount,
    deleteBankAccount,
    setPrimaryBankAccount,
    importBankTransactions,
    getUserData,
    getAllData
};
'@

Write-ProjectFile "src\login.html" @'
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>MoneyFlow - Login</title>
<link rel="stylesheet" href="css/style.css">
</head>

<body class="login-page">

<div class="auth-shell">

    <section class="auth-showcase">
        <div class="brand">
            <div class="brand-symbol">💰</div>
            <div>
                <h1>MoneyFlow</h1>
                <p>Smart Personal Finance</p>
            </div>
        </div>

        <div class="showcase-content">
            <span class="eyebrow">YOUR MONEY. YOUR CONTROL.</span>

            <h2>
                Take control of
                <span>your finances.</span>
            </h2>

            <p>
                Track income, expenses, budgets,
                savings goals, Auto-Pay and bank
                transactions from one powerful desktop
                application.
            </p>

            <div class="showcase-grid">
                <div>📊 <b>Analysis</b></div>
                <div>🏦 <b>Bank Accounts</b></div>
                <div>🎯 <b>Savings Goals</b></div>
                <div>🔔 <b>Smart Reminders</b></div>
            </div>
        </div>
    </section>

    <section class="auth-form-area">
        <div class="auth-card">

            <div class="auth-circle">💰</div>

            <h2>Welcome Back</h2>
            <p class="muted">
                Sign in to continue to MoneyFlow.
            </p>

            <form id="loginForm">

                <label>Email Address</label>

                <div class="input-wrap">
                    <span>✉️</span>
                    <input
                        id="email"
                        type="email"
                        placeholder="Enter your email"
                        required
                    >
                </div>

                <label>Password</label>

                <div class="input-wrap">
                    <span>🔒</span>
                    <input
                        id="password"
                        type="password"
                        placeholder="Enter your password"
                        required
                    >
                    <button
                        type="button"
                        id="togglePassword"
                        class="eye-btn"
                    >👁️</button>
                </div>

                <button
                    class="primary-auth-btn"
                    type="submit"
                >
                    Login to MoneyFlow
                </button>

            </form>

            <div
                id="loginMessage"
                class="form-message"
            ></div>

            <div class="auth-separator">
                <span>OR</span>
            </div>

            <p class="switch-text">
                Don't have an account?
                <a href="signup.html">
                    Create Account
                </a>
            </p>

            <div class="admin-hint">
                <b>Prototype Admin</b>
                <br>
                admin@expense.com / admin123
            </div>

        </div>
    </section>

</div>

<script src="js/login.js"></script>
</body>
</html>
'@

Write-ProjectFile "src\signup.html" @'
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>MoneyFlow - Signup</title>
<link rel="stylesheet" href="css/style.css">
</head>

<body class="signup-page">

<div class="auth-shell">

    <section class="auth-showcase signup-showcase">

        <div class="brand">
            <div class="brand-symbol">💰</div>

            <div>
                <h1>MoneyFlow</h1>
                <p>Build Better Money Habits</p>
            </div>
        </div>

        <div class="showcase-content">
            <span class="eyebrow">
                START YOUR FINANCIAL JOURNEY
            </span>

            <h2>
                Plan today.
                <span>Grow tomorrow.</span>
            </h2>

            <p>
                Create your personal MoneyFlow
                account and manage your complete
                financial life in one place.
            </p>

            <div class="showcase-grid">
                <div>💵 <b>Income</b></div>
                <div>💳 <b>Expenses</b></div>
                <div>📅 <b>Budgets</b></div>
                <div>🚀 <b>Goals</b></div>
            </div>
        </div>

    </section>

    <section class="auth-form-area">

        <div class="auth-card">

            <div class="auth-circle">✨</div>

            <h2>Create Account</h2>

            <p class="muted">
                Start managing your money today.
            </p>

            <form id="signupForm">

                <label>Full Name</label>

                <div class="input-wrap">
                    <span>👤</span>

                    <input
                        id="name"
                        type="text"
                        placeholder="Enter your full name"
                        required
                    >
                </div>

                <label>Email Address</label>

                <div class="input-wrap">
                    <span>✉️</span>

                    <input
                        id="email"
                        type="email"
                        placeholder="Enter your email"
                        required
                    >
                </div>

                <label>Password</label>

                <div class="input-wrap">
                    <span>🔒</span>

                    <input
                        id="password"
                        type="password"
                        placeholder="Minimum 6 characters"
                        required
                    >

                    <button
                        type="button"
                        id="togglePassword"
                        class="eye-btn"
                    >👁️</button>
                </div>

                <label>Confirm Password</label>

                <div class="input-wrap">
                    <span>🔐</span>

                    <input
                        id="confirmPassword"
                        type="password"
                        placeholder="Confirm password"
                        required
                    >
                </div>

                <button
                    class="primary-auth-btn signup-btn"
                    type="submit"
                >
                    Create My Account
                </button>

            </form>

            <div
                id="signupMessage"
                class="form-message"
            ></div>

            <p class="switch-text">
                Already have an account?
                <a href="login.html">
                    Login
                </a>
            </p>

        </div>

    </section>

</div>

<script src="js/signup.js"></script>
</body>
</html>
'@

Write-ProjectFile "src\js\login.js" @'
document.addEventListener("DOMContentLoaded", () => {

    const form = document.getElementById("loginForm");
    const message = document.getElementById("loginMessage");
    const password = document.getElementById("password");
    const toggle = document.getElementById("togglePassword");

    toggle.addEventListener("click", () => {
        if (password.type === "password") {
            password.type = "text";
            toggle.textContent = "🙈";
        } else {
            password.type = "password";
            toggle.textContent = "👁️";
        }
    });

    form.addEventListener("submit", async event => {

        event.preventDefault();

        const email =
            document.getElementById("email").value.trim();

        const passwordValue = password.value;

        if (!email || !passwordValue) {
            show("Please enter email and password.", "error");
            return;
        }

        const button =
            form.querySelector("button[type='submit']");

        button.disabled = true;
        button.textContent = "Signing in...";

        try {

            const result =
                await window.expenseAPI.loginUser({
                    email,
                    password: passwordValue
                });

            if (!result || !result.success) {
                show(
                    result?.message ||
                    "Invalid email or password.",
                    "error"
                );

                return;
            }

            if (result.admin) {
                localStorage.setItem(
                    "moneyflowAdmin",
                    "true"
                );

                window.location.href =
                    "admin.html";

                return;
            }

            localStorage.setItem(
                "moneyflowUserId",
                result.user.id
            );

            localStorage.setItem(
                "moneyflowUserName",
                result.user.name
            );

            localStorage.setItem(
                "moneyflowUserEmail",
                result.user.email
            );

            show(
                "Login successful. Opening dashboard...",
                "success"
            );

            setTimeout(() => {
                window.location.href =
                    "dashboard.html";
            }, 500);

        } catch (error) {

            console.error(error);

            show(
                "Unable to connect to MoneyFlow.",
                "error"
            );

        } finally {

            button.disabled = false;
            button.textContent =
                "Login to MoneyFlow";
        }
    });

    function show(text, type) {
        message.textContent = text;
        message.className =
            "form-message " + type;
    }
});
'@

Write-ProjectFile "src\js\signup.js" @'
document.addEventListener("DOMContentLoaded", () => {

    const form =
        document.getElementById("signupForm");

    const message =
        document.getElementById("signupMessage");

    const password =
        document.getElementById("password");

    const confirmPassword =
        document.getElementById("confirmPassword");

    const toggle =
        document.getElementById("togglePassword");

    toggle.addEventListener("click", () => {

        if (password.type === "password") {
            password.type = "text";
            toggle.textContent = "🙈";
        } else {
            password.type = "password";
            toggle.textContent = "👁️";
        }
    });

    form.addEventListener("submit", async event => {

        event.preventDefault();

        const name =
            document.getElementById("name")
                .value.trim();

        const email =
            document.getElementById("email")
                .value.trim();

        const passwordValue =
            password.value;

        const confirmValue =
            confirmPassword.value;

        if (
            !name ||
            !email ||
            !passwordValue ||
            !confirmValue
        ) {
            show(
                "Please fill all fields.",
                "error"
            );
            return;
        }

        if (passwordValue.length < 6) {
            show(
                "Password must contain at least 6 characters.",
                "error"
            );
            return;
        }

        if (passwordValue !== confirmValue) {
            show(
                "Passwords do not match.",
                "error"
            );
            return;
        }

        const button =
            form.querySelector(
                "button[type='submit']"
            );

        button.disabled = true;
        button.textContent =
            "Creating Account...";

        try {

            const result =
                await window.expenseAPI.registerUser({
                    name,
                    email,
                    password: passwordValue
                });

            if (!result || !result.success) {
                show(
                    result?.message ||
                    "Unable to create account.",
                    "error"
                );

                return;
            }

            show(
                "Account created successfully. Opening login...",
                "success"
            );

            form.reset();

            setTimeout(() => {
                window.location.href =
                    "login.html";
            }, 800);

        } catch (error) {

            console.error(error);

            show(
                "Unable to create account.",
                "error"
            );

        } finally {

            button.disabled = false;
            button.textContent =
                "Create My Account";
        }
    });

    function show(text, type) {
        message.textContent = text;
        message.className =
            "form-message " + type;
    }
});
'@

Write-ProjectFile "src\dashboard.html" @'
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>MoneyFlow Dashboard</title>
<link rel="stylesheet" href="css/style.css">
</head>

<body class="dashboard-page">

<div class="app-layout">

<aside class="sidebar">

    <div class="sidebar-brand">
        <div class="brand-symbol">💰</div>

        <div>
            <strong>MoneyFlow</strong>
            <small>Personal Finance</small>
        </div>
    </div>

    <div class="profile-mini">
        <div class="profile-avatar" id="sidebarAvatar">
            U
        </div>

        <div>
            <strong id="sidebarName">
                User
            </strong>

            <small id="sidebarEmail">
                user@email.com
            </small>
        </div>
    </div>

    <nav class="sidebar-nav">

        <button class="nav-item active" data-section="dashboard">
            <span>🏠</span>
            Dashboard
        </button>

        <button class="nav-item" data-section="income">
            <span>💵</span>
            Income
        </button>

        <button class="nav-item" data-section="expenses">
            <span>💳</span>
            Expenses
        </button>

        <button class="nav-item" data-section="autopay">
            <span>🔄</span>
            Auto-Pay
        </button>

        <button class="nav-item" data-section="budget">
            <span>📊</span>
            Budget
        </button>

        <button class="nav-item" data-section="goals">
            <span>🎯</span>
            Savings Goals
        </button>

        <button class="nav-item" data-section="history">
            <span>📅</span>
            History
        </button>

        <button class="nav-item" data-section="analysis">
            <span>📈</span>
            Analysis
        </button>

        <button
            class="nav-item"
            onclick="window.location.href='accounts.html'"
        >
            <span>🏦</span>
            Bank Accounts
        </button>

        <button class="nav-item" data-section="profile">
            <span>👤</span>
            Profile
        </button>

    </nav>

    <button id="logoutBtn" class="logout-btn">
        🚪 Logout
    </button>

</aside>

<main class="main-area">

<header class="topbar">

    <div>
        <span class="eyebrow">
            PERSONAL FINANCE CENTER
        </span>

        <h1 id="pageTitle">
            Dashboard
        </h1>
    </div>

    <div class="topbar-right">
        <div class="today-box">
            <span>📅</span>
            <span id="todayText"></span>
        </div>

        <div class="notification-dot">
            🔔
        </div>
    </div>

</header>

<div id="inactivityNotice" class="notice-card hidden">
    <strong>👋 Welcome back!</strong>
    <span>
        You have not used MoneyFlow for a few days.
        Your financial dashboard is ready.
    </span>
</div>

<!-- DASHBOARD -->

<section id="section-dashboard" class="page-section active">

    <div class="hero-card">

        <div>
            <span class="hero-label">
                AVAILABLE FINANCIAL POSITION
            </span>

            <h2>
                ₹<span id="remainingBalance">
                    0.00
                </span>
            </h2>

            <p>
                Your current income minus expenses.
            </p>
        </div>

        <div class="hero-icon">
            💰
        </div>

    </div>

    <div class="stat-grid">

        <div class="stat-card income-theme">
            <div class="stat-icon">💵</div>
            <div>
                <small>Total Income</small>
                <strong>
                    ₹<span id="totalIncome">0.00</span>
                </strong>
            </div>
        </div>

        <div class="stat-card expense-theme">
            <div class="stat-icon">💳</div>
            <div>
                <small>Total Expenses</small>
                <strong>
                    ₹<span id="totalExpenses">0.00</span>
                </strong>
            </div>
        </div>

        <div class="stat-card bank-theme">
            <div class="stat-icon">🏦</div>
            <div>
                <small>Bank Balance</small>
                <strong>
                    ₹<span id="bankBalance">0.00</span>
                </strong>
            </div>
        </div>

        <div class="stat-card goal-theme">
            <div class="stat-icon">🎯</div>
            <div>
                <small>Savings</small>
                <strong>
                    ₹<span id="totalSavings">0.00</span>
                </strong>
            </div>
        </div>

    </div>

    <div class="dashboard-grid">

        <div class="panel large-panel">

            <div class="panel-heading">
                <div>
                    <span class="eyebrow">RECENT ACTIVITY</span>
                    <h3>Latest Transactions</h3>
                </div>

                <button
                    class="small-btn"
                    data-section="history"
                >
                    View All
                </button>
            </div>

            <div id="recentTransactions"
                 class="transaction-list">
            </div>

        </div>

        <div class="panel">

            <div class="panel-heading">
                <div>
                    <span class="eyebrow">QUICK VIEW</span>
                    <h3>Spending</h3>
                </div>
            </div>

            <div class="analysis-box">
                <div class="analysis-ring">
                    <span id="expensePercent">
                        0%
                    </span>
                </div>

                <p>
                    of your income has been used.
                </p>
            </div>

            <div class="mini-analysis">
                <span>Income</span>
                <b id="miniIncome">
                    ₹0.00
                </b>
            </div>

            <div class="mini-analysis">
                <span>Expenses</span>
                <b id="miniExpense">
                    ₹0.00
                </b>
            </div>

        </div>

    </div>

</section>

<!-- INCOME -->

<section id="section-income"
         class="page-section income-section">

    <div class="section-banner income-banner">
        <span>💵</span>
        <div>
            <h2>Income Management</h2>
            <p>
                Record salary, freelance income,
                transfers and other credits.
            </p>
        </div>
    </div>

    <div class="content-grid">

        <div class="panel">

            <div class="panel-heading">
                <h3>Add Income</h3>
            </div>

            <form id="incomeForm">

                <label>Amount</label>
                <input
                    id="incomeAmount"
                    type="number"
                    min="0"
                    step="0.01"
                    placeholder="₹ 0.00"
                    required
                >

                <label>Income Source</label>
                <input
                    id="incomeSource"
                    type="text"
                    placeholder="Salary / Freelance / Gift"
                    required
                >

                <label>Description</label>
                <input
                    id="incomeDescription"
                    type="text"
                    placeholder="Optional description"
                >

                <label>Date</label>
                <input
                    id="incomeDate"
                    type="date"
                    required
                >

                <label>Bank Account</label>
                <select id="incomeBankAccount">
                    <option value="">
                        Cash / Other
                    </option>
                </select>

                <button class="green-btn" type="submit">
                    + Add Income
                </button>

            </form>

            <div id="incomeMessage"
                 class="form-message">
            </div>

        </div>

        <div class="panel">

            <div class="panel-heading">
                <h3>Income History</h3>
            </div>

            <div id="incomeList"
                 class="transaction-list">
            </div>

        </div>

    </div>

</section>

<!-- EXPENSES -->

<section id="section-expenses"
         class="page-section expense-section">

    <div class="section-banner expense-banner">
        <span>💳</span>
        <div>
            <h2>Expense Management</h2>
            <p>
                Track daily spending and understand
                your money habits.
            </p>
        </div>
    </div>

    <div class="content-grid">

        <div class="panel">

            <div class="panel-heading">
                <h3>Add Expense</h3>
            </div>

            <form id="expenseForm">

                <label>Amount</label>
                <input
                    id="expenseAmount"
                    type="number"
                    min="0"
                    step="0.01"
                    placeholder="₹ 0.00"
                    required
                >

                <label>Category</label>
                <select id="expenseCategory">
                    <option>Food</option>
                    <option>Transport</option>
                    <option>Shopping</option>
                    <option>Bills</option>
                    <option>Education</option>
                    <option>Entertainment</option>
                    <option>Health</option>
                    <option>Rent</option>
                    <option>Bank Transaction</option>
                    <option>Other</option>
                </select>

                <label>Description</label>
                <input
                    id="expenseDescription"
                    type="text"
                    placeholder="What did you spend on?"
                    required
                >

                <label>Date</label>
                <input
                    id="expenseDate"
                    type="date"
                    required
                >

                <label>Payment Method</label>
                <select id="expensePayment">
                    <option>Cash</option>
                    <option>UPI</option>
                    <option>Debit Card</option>
                    <option>Credit Card</option>
                    <option>Bank</option>
                </select>

                <label>Bank Account</label>
                <select id="expenseBankAccount">
                    <option value="">
                        Cash / Other
                    </option>
                </select>

                <label>Classification</label>
                <select id="expenseClassification">
                    <option>Need</option>
                    <option>Want</option>
                    <option>Investment</option>
                </select>

                <button class="red-btn" type="submit">
                    + Add Expense
                </button>

            </form>

            <div id="expenseMessage"
                 class="form-message">
            </div>

        </div>

        <div class="panel">

            <div class="panel-heading">
                <h3>Expense History</h3>
            </div>

            <div id="expenseList"
                 class="transaction-list">
            </div>

        </div>

    </div>

</section>

<!-- AUTOPAY -->

<section id="section-autopay"
         class="page-section autopay-section">

    <div class="section-banner autopay-banner">
        <span>🔄</span>
        <div>
            <h2>Auto-Pay</h2>
            <p>
                Track recurring monthly and scheduled payments.
            </p>
        </div>
    </div>

    <div class="content-grid">

        <div class="panel">

            <div class="panel-heading">
                <h3>Add Auto-Pay</h3>
            </div>

            <form id="autopayForm">

                <label>Payment Name</label>
                <input
                    id="autopayName"
                    type="text"
                    placeholder="Netflix / Rent / EMI"
                    required
                >

                <label>Amount</label>
                <input
                    id="autopayAmount"
                    type="number"
                    min="0"
                    step="0.01"
                    required
                >

                <label>Category</label>
                <select id="autopayCategory">
                    <option>Bills</option>
                    <option>Rent</option>
                    <option>Subscription</option>
                    <option>Education</option>
                    <option>Loan</option>
                    <option>Other</option>
                </select>

                <label>Frequency</label>
                <select id="autopayFrequency">
                    <option>Monthly</option>
                    <option>Weekly</option>
                    <option>Yearly</option>
                </select>

                <label>Next Payment Date</label>
                <input
                    id="autopayDate"
                    type="date"
                    required
                >

                <label>Bank Account</label>
                <select id="autopayBankAccount">
                    <option value="">
                        Select account
                    </option>
                </select>

                <button class="purple-btn" type="submit">
                    + Add Auto-Pay
                </button>

            </form>

            <div id="autopayMessage"
                 class="form-message">
            </div>

        </div>

        <div class="panel">

            <div class="panel-heading">
                <h3>Scheduled Payments</h3>
            </div>

            <div id="autopayList"></div>

        </div>

    </div>

</section>

<!-- BUDGET -->

<section id="section-budget"
         class="page-section budget-section">

    <div class="section-banner budget-banner">
        <span>📊</span>

        <div>
            <h2>Budget Management</h2>
            <p>
                Set monthly spending limits by category.
            </p>
        </div>
    </div>

    <div class="content-grid">

        <div class="panel">

            <div class="panel-heading">
                <h3>Create Budget</h3>
            </div>

            <form id="budgetForm">

                <label>Category</label>

                <select id="budgetCategory">
                    <option>Food</option>
                    <option>Transport</option>
                    <option>Shopping</option>
                    <option>Bills</option>
                    <option>Education</option>
                    <option>Entertainment</option>
                    <option>Health</option>
                    <option>Other</option>
                </select>

                <label>Monthly Limit</label>

                <input
                    id="budgetAmount"
                    type="number"
                    min="0"
                    step="0.01"
                    required
                >

                <label>Month</label>

                <input
                    id="budgetMonth"
                    type="month"
                    required
                >

                <button class="orange-btn" type="submit">
                    Save Budget
                </button>

            </form>

            <div id="budgetMessage"
                 class="form-message">
            </div>

        </div>

        <div class="panel">

            <div class="panel-heading">
                <h3>Your Budgets</h3>
            </div>

            <div id="budgetList"></div>

        </div>

    </div>

</section>

<!-- GOALS -->

<section id="section-goals"
         class="page-section goals-section">

    <div class="section-banner goals-banner">

        <span>🎯</span>

        <div>
            <h2>Savings Goals</h2>
            <p>
                Set targets and monitor your progress.
            </p>
        </div>

    </div>

    <div class="content-grid">

        <div class="panel">

            <div class="panel-heading">
                <h3>Create Savings Goal</h3>
            </div>

            <form id="goalForm">

                <label>Goal Name</label>

                <input
                    id="goalName"
                    type="text"
                    placeholder="New Laptop / Bike / Emergency Fund"
                    required
                >

                <label>Target Amount</label>

                <input
                    id="goalTarget"
                    type="number"
                    min="1"
                    step="0.01"
                    required
                >

                <label>Already Saved</label>

                <input
                    id="goalSaved"
                    type="number"
                    min="0"
                    step="0.01"
                    value="0"
                >

                <label>Deadline</label>

                <input
                    id="goalDeadline"
                    type="date"
                >

                <button class="pink-btn" type="submit">
                    Create Goal
                </button>

            </form>

            <div id="goalMessage"
                 class="form-message">
            </div>

        </div>

        <div class="panel">

            <div class="panel-heading">
                <h3>Your Goals</h3>
            </div>

            <div id="goalList"></div>

        </div>

    </div>

</section>

<!-- HISTORY -->

<section id="section-history"
         class="page-section history-section">

    <div class="section-banner history-banner">

        <span>📅</span>

        <div>
            <h2>Monthly History</h2>
            <p>
                Search and review your previous transactions.
            </p>
        </div>

    </div>

    <div class="panel">

        <div class="filter-row">

            <input
                id="historySearch"
                type="text"
                placeholder="Search transaction..."
            >

            <input
                id="historyMonth"
                type="month"
            >

            <button
                id="clearHistoryFilter"
                class="small-btn"
            >
                Clear
            </button>

        </div>

        <div id="historyList"
             class="transaction-list">
        </div>

    </div>

</section>

<!-- ANALYSIS -->

<section id="section-analysis"
         class="page-section analysis-section">

    <div class="section-banner analysis-banner">

        <span>📈</span>

        <div>
            <h2>Financial Analysis</h2>
            <p>
                Understand your income and spending pattern.
            </p>
        </div>

    </div>

    <div class="analysis-grid">

        <div class="analysis-card">
            <span>💵</span>
            <small>Total Income</small>
            <strong id="analysisIncome">
                ₹0.00
            </strong>
        </div>

        <div class="analysis-card">
            <span>💳</span>
            <small>Total Expenses</small>
            <strong id="analysisExpense">
                ₹0.00
            </strong>
        </div>

        <div class="analysis-card">
            <span>💰</span>
            <small>Remaining</small>
            <strong id="analysisRemaining">
                ₹0.00
            </strong>
        </div>

        <div class="analysis-card">
            <span>📊</span>
            <small>Expense Rate</small>
            <strong id="analysisRate">
                0%
            </strong>
        </div>

    </div>

    <div class="panel">

        <div class="panel-heading">
            <h3>Expense By Category</h3>
        </div>

        <div id="categoryAnalysis"
             class="category-bars">
        </div>

    </div>

</section>

<!-- PROFILE -->

<section id="section-profile"
         class="page-section profile-section">

    <div class="profile-cover">

        <div class="big-avatar"
             id="profileAvatar">
            U
        </div>

        <div>
            <h2 id="profileName">
                User
            </h2>

            <p id="profileEmail">
                user@email.com
            </p>
        </div>

    </div>

    <div class="profile-grid">

        <div class="profile-info-card">
            <span>👤</span>
            <small>Full Name</small>
            <strong id="profileName2">
                -
            </strong>
        </div>

        <div class="profile-info-card">
            <span>✉️</span>
            <small>Email</small>
            <strong id="profileEmail2">
                -
            </strong>
        </div>

        <div class="profile-info-card">
            <span>🏦</span>
            <small>Bank Accounts</small>
            <strong id="profileBankCount">
                0
            </strong>
        </div>

        <div class="profile-info-card">
            <span>💳</span>
            <small>Total Transactions</small>
            <strong id="profileTransactions">
                0
            </strong>
        </div>

    </div>

    <div class="profile-action-card">

        <h3>Bank Account Center</h3>

        <p>
            Add your bank account information
            and import a bank statement to automatically
            create income and expense records.
        </p>

        <button
            class="blue-btn"
            onclick="window.location.href='accounts.html'"
        >
            🏦 Manage Bank Accounts
        </button>

    </div>

</section>

</main>

</div>

<script src="js/dashboard.js"></script>
</body>
</html>
'@

Write-ProjectFile "src\accounts.html" @'
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>MoneyFlow - Bank Accounts</title>
<link rel="stylesheet" href="css/style.css">
</head>

<body class="accounts-page">

<div class="bank-page">

<header class="bank-header">

    <div>
        <span class="eyebrow">BANK CENTER</span>

        <h1>
            🏦 Bank Accounts
        </h1>

        <p>
            Manage your bank account information
            and import statement transactions.
        </p>
    </div>

    <div class="header-actions">

        <button
            class="dark-btn"
            onclick="window.location.href='dashboard.html'"
        >
            ← Dashboard
        </button>

        <button
            class="logout-small"
            id="bankLogout"
        >
            Logout
        </button>

    </div>

</header>

<div class="security-warning">

    <strong>🔐 Security Notice</strong>

    <span>
        Never enter your ATM PIN, CVV, OTP,
        UPI PIN or internet-banking password.
        MoneyFlow only stores basic account
        information and masked account numbers.
    </span>

</div>

<div class="bank-grid">

<section class="bank-form-card">

    <div class="card-heading">

        <div>
            <span>ACCOUNT SETUP</span>
            <h2 id="accountFormTitle">
                Add Bank Account
            </h2>
        </div>

        <span class="bank-card-icon">
            🏦
        </span>

    </div>

    <form id="bankAccountForm">

        <input
            type="hidden"
            id="bankAccountId"
        >

        <label>Bank Name</label>

        <input
            id="bankName"
            type="text"
            placeholder="Example: HDFC Bank"
            required
        >

        <label>Account Holder</label>

        <input
            id="accountHolder"
            type="text"
            placeholder="Account holder name"
            required
        >

        <label>Account Type</label>

        <select id="accountType">
            <option>Savings</option>
            <option>Current</option>
            <option>Salary</option>
            <option>Joint</option>
            <option>Other</option>
        </select>

        <label>Last 4 Digits</label>

        <input
            id="accountNumberLast4"
            type="text"
            maxlength="4"
            placeholder="1234"
        >

        <label>IFSC Code</label>

        <input
            id="ifsc"
            type="text"
            placeholder="ABCD0123456"
        >

        <label>Branch</label>

        <input
            id="branch"
            type="text"
            placeholder="Branch name"
        >

        <label>UPI ID</label>

        <input
            id="upiId"
            type="text"
            placeholder="name@upi"
        >

        <label>Account Nickname</label>

        <input
            id="nickname"
            type="text"
            placeholder="My Main Account"
        >

        <label>Current Balance</label>

        <input
            id="bankBalanceInput"
            type="number"
            step="0.01"
            value="0"
        >

        <label class="checkbox-line">

            <input
                id="isPrimary"
                type="checkbox"
            >

            <span>
                Make this my primary account
            </span>

        </label>

        <div class="form-buttons">

            <button
                type="submit"
                class="blue-btn"
                id="saveBankButton"
            >
                + Add Account
            </button>

            <button
                type="button"
                class="gray-btn hidden"
                id="cancelBankEdit"
            >
                Cancel
            </button>

        </div>

    </form>

    <div
        id="bankMessage"
        class="form-message"
    ></div>

</section>

<section>

<div class="bank-section-title">

    <div>
        <span>SAVED ACCOUNTS</span>
        <h2>Your Bank Accounts</h2>
    </div>

    <div class="total-bank-box">
        Total:
        ₹<span id="allBankBalance">
            0.00
        </span>
    </div>

</div>

<div
    id="bankAccountsList"
    class="bank-accounts-list"
></div>

</section>

</div>

<section class="statement-card">

    <div class="statement-heading">

        <div>
            <span>BANK STATEMENT IMPORT</span>

            <h2>
                Import Income & Expenses
            </h2>

            <p>
                Select a bank account and import
                a CSV statement. Credits are added
                as income and debits are added as
                expenses.
            </p>
        </div>

        <div class="statement-icon">
            📥
        </div>

    </div>

    <div class="statement-controls">

        <select id="importBankAccount">
            <option value="">
                Select bank account
            </option>
        </select>

        <input
            id="csvFile"
            type="file"
            accept=".csv"
        >

        <button
            id="importButton"
            class="blue-btn"
        >
            Import Statement
        </button>

        <button
            id="templateButton"
            class="gray-btn"
        >
            Download CSV Template
        </button>

    </div>

    <div
        id="importMessage"
        class="form-message"
    ></div>

</section>

<section class="statement-card">

    <div class="bank-section-title">

        <div>
            <span>RECENT IMPORTS</span>
            <h2>Bank Transactions</h2>
        </div>

    </div>

    <div
        id="bankTransactionsList"
        class="bank-transactions"
    ></div>

</section>

</div>

<script src="js/accounts.js"></script>
</body>
</html>
'@

Write-ProjectFile "src\admin.html" @'
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>MoneyFlow - Admin</title>
<link rel="stylesheet" href="css/style.css">
</head>

<body class="admin-page">

<div class="admin-wrapper">

<header class="admin-header">

    <div>
        <span class="eyebrow">
            MONEYFLOW ADMINISTRATION
        </span>

        <h1>
            🛡️ Admin Dashboard
        </h1>

        <p>
            Application overview and registered users.
        </p>
    </div>

    <button
        id="adminLogout"
        class="logout-small"
    >
        Logout
    </button>

</header>

<div class="admin-stats">

    <div class="admin-stat">
        <span>👥</span>
        <small>Users</small>
        <strong id="userCount">0</strong>
    </div>

    <div class="admin-stat">
        <span>💵</span>
        <small>Income Records</small>
        <strong id="incomeCount">0</strong>
    </div>

    <div class="admin-stat">
        <span>💳</span>
        <small>Expense Records</small>
        <strong id="expenseCount">0</strong>
    </div>

    <div class="admin-stat">
        <span>🏦</span>
        <small>Bank Accounts</small>
        <strong id="bankCount">0</strong>
    </div>

</div>

<section class="admin-panel">

    <div class="panel-heading">
        <div>
            <span class="eyebrow">REGISTERED USERS</span>
            <h2>Users</h2>
        </div>
    </div>

    <div id="adminUsers"></div>

</section>

</div>

<script src="js/admin.js"></script>
</body>
</html>
'@

Write-ProjectFile "src\js\admin.js" @'
document.addEventListener("DOMContentLoaded", async () => {

    if (
        localStorage.getItem("moneyflowAdmin") !==
        "true"
    ) {
        window.location.href = "login.html";
        return;
    }

    const logout =
        document.getElementById("adminLogout");

    logout.addEventListener("click", () => {
        localStorage.removeItem("moneyflowAdmin");
        window.location.href = "login.html";
    });

    try {

        const data =
            await window.expenseAPI.getAllData();

        if (!data || !data.success) {
            return;
        }

        document.getElementById("userCount")
            .textContent =
            data.users.length;

        document.getElementById("incomeCount")
            .textContent =
            data.income.length;

        document.getElementById("expenseCount")
            .textContent =
            data.expenses.length;

        document.getElementById("bankCount")
            .textContent =
            data.bankAccounts.length;

        const container =
            document.getElementById("adminUsers");

        if (!data.users.length) {
            container.innerHTML =
                `<div class="empty-state">
                    No registered users yet.
                </div>`;
            return;
        }

        container.innerHTML =
            data.users.map(user => `
                <div class="admin-user-row">
                    <div class="admin-user-avatar">
                        ${escapeHtml(
                            user.name
                                .charAt(0)
                                .toUpperCase()
                        )}
                    </div>

                    <div>
                        <strong>
                            ${escapeHtml(user.name)}
                        </strong>

                        <small>
                            ${escapeHtml(user.email)}
                        </small>
                    </div>

                    <div class="admin-date">
                        ${formatDate(user.createdAt)}
                    </div>
                </div>
            `).join("");

    } catch (error) {
        console.error(error);
    }

    function formatDate(value) {
        if (!value) return "-";

        const date = new Date(value);

        if (Number.isNaN(date.getTime())) {
            return "-";
        }

        return date.toLocaleDateString(
            "en-IN"
        );
    }

    function escapeHtml(value) {
        return String(value || "")
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }
});
'@

Write-ProjectFile "src\js\accounts.js" @'
document.addEventListener("DOMContentLoaded", () => {

    const userId =
        localStorage.getItem("moneyflowUserId");

    if (!userId) {
        window.location.href = "login.html";
        return;
    }

    let accounts = [];
    let transactions = [];

    const form =
        document.getElementById("bankAccountForm");

    const message =
        document.getElementById("bankMessage");

    const accountId =
        document.getElementById("bankAccountId");

    const saveButton =
        document.getElementById("saveBankButton");

    const cancelButton =
        document.getElementById("cancelBankEdit");

    const importAccount =
        document.getElementById("importBankAccount");

    const csvFile =
        document.getElementById("csvFile");

    const importButton =
        document.getElementById("importButton");

    const importMessage =
        document.getElementById("importMessage");

    document
        .getElementById("bankLogout")
        .addEventListener("click", () => {

            localStorage.removeItem(
                "moneyflowUserId"
            );

            localStorage.removeItem(
                "moneyflowUserName"
            );

            localStorage.removeItem(
                "moneyflowUserEmail"
            );

            window.location.href =
                "login.html";
        });

    form.addEventListener(
        "submit",
        async event => {

            event.preventDefault();

            const data = {
                id: accountId.value,
                userId,

                bankName:
                    document.getElementById(
                        "bankName"
                    ).value.trim(),

                accountHolder:
                    document.getElementById(
                        "accountHolder"
                    ).value.trim(),

                accountType:
                    document.getElementById(
                        "accountType"
                    ).value,

                accountNumberLast4:
                    document.getElementById(
                        "accountNumberLast4"
                    ).value.trim(),

                ifsc:
                    document.getElementById(
                        "ifsc"
                    ).value.trim(),

                branch:
                    document.getElementById(
                        "branch"
                    ).value.trim(),

                upiId:
                    document.getElementById(
                        "upiId"
                    ).value.trim(),

                nickname:
                    document.getElementById(
                        "nickname"
                    ).value.trim(),

                balance:
                    Number(
                        document.getElementById(
                            "bankBalanceInput"
                        ).value || 0
                    ),

                isPrimary:
                    document.getElementById(
                        "isPrimary"
                    ).checked
            };

            let result;

            try {

                if (data.id) {
                    result =
                        await window.expenseAPI
                            .updateBankAccount(data);
                } else {
                    result =
                        await window.expenseAPI
                            .addBankAccount(data);
                }

                if (!result || !result.success) {
                    show(
                        message,
                        result?.message ||
                        "Unable to save account.",
                        "error"
                    );

                    return;
                }

                show(
                    message,
                    result.message ||
                    "Bank account saved.",
                    "success"
                );

                clearForm();

                await load();

            } catch (error) {

                console.error(error);

                show(
                    message,
                    "Unable to save bank account.",
                    "error"
                );
            }
        }
    );

    cancelButton.addEventListener(
        "click",
        clearForm
    );

    importButton.addEventListener(
        "click",
        importCSV
    );

    document
        .getElementById("templateButton")
        .addEventListener(
            "click",
            downloadTemplate
        );

    async function load() {

        try {

            const result =
                await window.expenseAPI
                    .getUserData(userId);

            if (!result || !result.success) {
                show(
                    message,
                    result?.message ||
                    "Unable to load accounts.",
                    "error"
                );

                return;
            }

            accounts =
                result.bankAccounts || [];

            transactions =
                result.bankTransactions || [];

            renderAccounts();
            renderSelectors();
            renderTransactions();

        } catch (error) {

            console.error(error);

            show(
                message,
                "Unable to load bank information.",
                "error"
            );
        }
    }

    function renderAccounts() {

        const container =
            document.getElementById(
                "bankAccountsList"
            );

        const total =
            accounts.reduce(
                (sum, account) =>
                    sum +
                    Number(account.balance || 0),
                0
            );

        document.getElementById(
            "allBankBalance"
        ).textContent =
            money(total);

        if (!accounts.length) {

            container.innerHTML =
                `<div class="empty-state bank-empty">
                    <div>🏦</div>
                    <h3>No bank accounts added</h3>
                    <p>
                        Add your first bank account
                        using the form.
                    </p>
                </div>`;

            return;
        }

        container.innerHTML =
            accounts.map(account => `

                <div class="bank-account-card">

                    <div class="bank-card-top">

                        <div class="bank-logo">
                            🏦
                        </div>

                        <div>
                            <span class="bank-label">
                                ${escapeHtml(
                                    account.nickname ||
                                    account.bankName
                                )}
                            </span>

                            <h3>
                                ${escapeHtml(
                                    account.bankName
                                )}
                            </h3>
                        </div>

                        ${
                            account.isPrimary
                            ? `
                                <span class="primary-badge">
                                    PRIMARY
                                </span>
                            `
                            : ""
                        }

                    </div>

                    <div class="bank-balance">
                        <small>Available Balance</small>

                        <strong>
                            ₹${money(account.balance)}
                        </strong>
                    </div>

                    <div class="bank-details">

                        <div>
                            <span>Account Holder</span>
                            <b>
                                ${escapeHtml(
                                    account.accountHolder
                                )}
                            </b>
                        </div>

                        <div>
                            <span>Account</span>
                            <b>
                                ${escapeHtml(
                                    account.accountNumberMasked
                                )}
                            </b>
                        </div>

                        <div>
                            <span>Type</span>
                            <b>
                                ${escapeHtml(
                                    account.accountType
                                )}
                            </b>
                        </div>

                        <div>
                            <span>IFSC</span>
                            <b>
                                ${escapeHtml(
                                    account.ifsc || "-"
                                )}
                            </b>
                        </div>

                        <div>
                            <span>Branch</span>
                            <b>
                                ${escapeHtml(
                                    account.branch || "-"
                                )}
                            </b>
                        </div>

                        <div>
                            <span>UPI</span>
                            <b>
                                ${escapeHtml(
                                    account.upiId || "-"
                                )}
                            </b>
                        </div>

                    </div>

                    <div class="bank-actions">

                        <button
                            class="edit-bank"
                            data-id="${account.id}"
                        >
                            ✏️ Edit
                        </button>

                        <button
                            class="primary-bank"
                            data-id="${account.id}"
                        >
                            ⭐ Primary
                        </button>

                        <button
                            class="delete-bank danger-btn"
                            data-id="${account.id}"
                        >
                            🗑️ Delete
                        </button>

                    </div>

                </div>

            `).join("");

        container
            .querySelectorAll(".edit-bank")
            .forEach(button => {

                button.addEventListener(
                    "click",
                    () =>
                        editAccount(
                            button.dataset.id
                        )
                );
            });

        container
            .querySelectorAll(".primary-bank")
            .forEach(button => {

                button.addEventListener(
                    "click",
                    () =>
                        setPrimary(
                            button.dataset.id
                        )
                );
            });

        container
            .querySelectorAll(".delete-bank")
            .forEach(button => {

                button.addEventListener(
                    "click",
                    () =>
                        deleteAccount(
                            button.dataset.id
                        )
                );
            });
    }

    function renderSelectors() {

        const selects = [
            document.getElementById(
                "incomeBankAccount"
            ),
            document.getElementById(
                "expenseBankAccount"
            ),
            document.getElementById(
                "autopayBankAccount"
            ),
            importAccount
        ];

        selects.forEach(select => {

            if (!select) return;

            const current = select.value;

            select.innerHTML =
                `<option value="">
                    Select bank account
                </option>` +
                accounts.map(
                    account =>
                        `<option value="${account.id}">
                            ${escapeHtml(
                                account.nickname ||
                                account.bankName
                            )}
                            -
                            ${escapeHtml(
                                account.accountNumberMasked
                            )}
                        </option>`
                ).join("");

            if (current) {
                select.value = current;
            }
        });
    }

    function renderTransactions() {

        const container =
            document.getElementById(
                "bankTransactionsList"
            );

        if (!transactions.length) {

            container.innerHTML =
                `<div class="empty-state">
                    No imported bank transactions yet.
                </div>`;

            return;
        }

        const sorted =
            [...transactions]
                .sort(
                    (a, b) =>
                        new Date(b.date) -
                        new Date(a.date)
                )
                .slice(0, 30);

        container.innerHTML =
            sorted.map(transaction => `

                <div class="bank-transaction-row">

                    <div class="
                        bank-transaction-icon
                        ${
                            transaction.type ===
                            "credit"
                            ? "credit"
                            : "debit"
                        }
                    ">
                        ${
                            transaction.type ===
                            "credit"
                            ? "↓"
                            : "↑"
                        }
                    </div>

                    <div class="transaction-main">

                        <strong>
                            ${escapeHtml(
                                transaction.description
                            )}
                        </strong>

                        <small>
                            ${escapeHtml(
                                transaction.date
                            )}
                        </small>

                    </div>

                    <strong class="
                        transaction-amount
                        ${
                            transaction.type ===
                            "credit"
                            ? "positive"
                            : "negative"
                        }
                    ">
                        ${
                            transaction.type ===
                            "credit"
                            ? "+"
                            : "-"
                        }
                        ₹${money(transaction.amount)}
                    </strong>

                </div>

            `).join("");
    }

    function editAccount(id) {

        const account =
            accounts.find(
                item =>
                    String(item.id) ===
                    String(id)
            );

        if (!account) return;

        accountId.value =
            account.id;

        document.getElementById(
            "bankName"
        ).value =
            account.bankName || "";

        document.getElementById(
            "accountHolder"
        ).value =
            account.accountHolder || "";

        document.getElementById(
            "accountType"
        ).value =
            account.accountType || "Savings";

        document.getElementById(
            "accountNumberLast4"
        ).value =
            account.accountNumberLast4 || "";

        document.getElementById(
            "ifsc"
        ).value =
            account.ifsc || "";

        document.getElementById(
            "branch"
        ).value =
            account.branch || "";

        document.getElementById(
            "upiId"
        ).value =
            account.upiId || "";

        document.getElementById(
            "nickname"
        ).value =
            account.nickname || "";

        document.getElementById(
            "bankBalanceInput"
        ).value =
            account.balance || 0;

        document.getElementById(
            "isPrimary"
        ).checked =
            Boolean(account.isPrimary);

        document.getElementById(
            "accountFormTitle"
        ).textContent =
            "Edit Bank Account";

        saveButton.textContent =
            "Save Changes";

        cancelButton.classList.remove(
            "hidden"
        );

        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });
    }

    async function setPrimary(id) {

        const result =
            await window.expenseAPI
                .setPrimaryBankAccount({
                    id,
                    userId
                });

        show(
            message,
            result?.message ||
            "Primary account updated.",
            result?.success
                ? "success"
                : "error"
        );

        await load();
    }

    async function deleteAccount(id) {

        if (
            !confirm(
                "Delete this bank account?"
            )
        ) {
            return;
        }

        const result =
            await window.expenseAPI
                .deleteBankAccount(id);

        show(
            message,
            result?.message ||
            "Bank account deleted.",
            result?.success
                ? "success"
                : "error"
        );

        await load();
    }

    function clearForm() {

        form.reset();

        accountId.value = "";

        document.getElementById(
            "accountType"
        ).value = "Savings";

        document.getElementById(
            "bankBalanceInput"
        ).value = "0";

        document.getElementById(
            "accountFormTitle"
        ).textContent =
            "Add Bank Account";

        saveButton.textContent =
            "+ Add Account";

        cancelButton.classList.add(
            "hidden"
        );
    }

    async function importCSV() {

        const selected =
            importAccount.value;

        const file =
            csvFile.files[0];

        if (!selected) {

            show(
                importMessage,
                "Select a bank account first.",
                "error"
            );

            return;
        }

        if (!file) {

            show(
                importMessage,
                "Select a CSV statement.",
                "error"
            );

            return;
        }

        try {

            importButton.disabled = true;
            importButton.textContent =
                "Importing...";

            const text =
                await file.text();

            const result =
                await window.expenseAPI
                    .importBankTransactions({
                        userId,
                        bankAccountId: selected,
                        csvText: text
                    });

            show(
                importMessage,
                result?.message ||
                "Import completed.",
                result?.success
                    ? "success"
                    : "error"
            );

            if (result?.success) {
                csvFile.value = "";
                await load();
            }

        } catch (error) {

            console.error(error);

            show(
                importMessage,
                "Unable to import CSV.",
                "error"
            );

        } finally {

            importButton.disabled = false;
            importButton.textContent =
                "Import Statement";
        }
    }

    function downloadTemplate() {

        const csv =
            [
                "Date,Description,Amount,Type",
                "2026-09-30,Salary,50000,Credit",
                "2026-09-30,Restaurant,850,Debit",
                "2026-09-29,Shopping,1200,Debit"
            ].join("\n");

        const blob =
            new Blob(
                [csv],
                {
                    type: "text/csv;charset=utf-8;"
                }
            );

        const url =
            URL.createObjectURL(blob);

        const link =
            document.createElement("a");

        link.href = url;
        link.download =
            "moneyflow-bank-statement-template.csv";

        link.click();

        URL.revokeObjectURL(url);
    }

    function money(value) {
        return Number(
            value || 0
        ).toLocaleString(
            "en-IN",
            {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            }
        );
    }

    function show(
        element,
        text,
        type
    ) {

        element.textContent =
            text;

        element.className =
            "form-message " +
            type;
    }

    function escapeHtml(value) {

        return String(value || "")
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }

    load();
});
'@

Write-ProjectFile "src\js\dashboard.js" @'
document.addEventListener("DOMContentLoaded", () => {

    const userId =
        localStorage.getItem("moneyflowUserId");

    if (!userId) {
        window.location.href = "login.html";
        return;
    }

    let user = null;
    let expenses = [];
    let income = [];
    let autopay = [];
    let budgets = [];
    let goals = [];
    let bankAccounts = [];
    let transactions = [];

    const sections = [
        "dashboard",
        "income",
        "expenses",
        "autopay",
        "budget",
        "goals",
        "history",
        "analysis",
        "profile"
    ];

    setupNavigation();
    setupDates();
    setupForms();
    loadDashboard();

    async function loadDashboard() {

        try {

            await window.expenseAPI
                .processAutoPay(userId);

            const result =
                await window.expenseAPI
                    .getUserData(userId);

            if (!result || !result.success) {
                alert(
                    result?.message ||
                    "Unable to load your data."
                );

                return;
            }

            user = result.user;
            expenses =
                result.expenses || [];
            income =
                result.income || [];
            autopay =
                result.autopay || [];
            budgets =
                result.budgets || [];
            goals =
                result.goals || [];
            bankAccounts =
                result.bankAccounts || [];
            transactions =
                result.bankTransactions || [];

            renderUser();
            renderDashboard();
            renderIncome();
            renderExpenses();
            renderAutopay();
            renderBudgets();
            renderGoals();
            renderHistory();
            renderAnalysis();
            renderProfile();
            populateBankSelects();
            checkInactivity();

        } catch (error) {

            console.error(
                "DASHBOARD ERROR:",
                error
            );

            alert(
                "Unable to load financial data."
            );
        }
    }

    function setupNavigation() {

        document
            .querySelectorAll(".nav-item")
            .forEach(button => {

                button.addEventListener(
                    "click",
                    () => {

                        const section =
                            button.dataset.section;

                        if (!section) {
                            return;
                        }

                        openSection(section);
                    }
                );
            });

        document
            .querySelectorAll("[data-section]")
            .forEach(button => {

                if (
                    button.classList.contains(
                        "nav-item"
                    )
                ) {
                    return;
                }

                button.addEventListener(
                    "click",
                    () => {
                        openSection(
                            button.dataset.section
                        );
                    }
                );
            });

        document
            .getElementById("logoutBtn")
            .addEventListener(
                "click",
                logout
            );

        document
            .getElementById(
                "historySearch"
            )
            .addEventListener(
                "input",
                renderHistory
            );

        document
            .getElementById(
                "historyMonth"
            )
            .addEventListener(
                "change",
                renderHistory
            );

        document
            .getElementById(
                "clearHistoryFilter"
            )
            .addEventListener(
                "click",
                () => {

                    document.getElementById(
                        "historySearch"
                    ).value = "";

                    document.getElementById(
                        "historyMonth"
                    ).value = "";

                    renderHistory();
                }
            );
    }

    function openSection(section) {

        if (!sections.includes(section)) {
            return;
        }

        document
            .querySelectorAll(".page-section")
            .forEach(element => {
                element.classList.remove(
                    "active"
                );
            });

        const target =
            document.getElementById(
                "section-" + section
            );

        if (target) {
            target.classList.add("active");
        }

        document
            .querySelectorAll(".nav-item")
            .forEach(button => {
                button.classList.toggle(
                    "active",
                    button.dataset.section ===
                    section
                );
            });

        const titles = {
            dashboard: "Dashboard",
            income: "Income",
            expenses: "Expenses",
            autopay: "Auto-Pay",
            budget: "Budget",
            goals: "Savings Goals",
            history: "Monthly History",
            analysis: "Financial Analysis",
            profile: "Profile"
        };

        document.getElementById(
            "pageTitle"
        ).textContent =
            titles[section] || "Dashboard";
    }

    function setupDates() {

        const today =
            new Date();

        const isoDate =
            today.toISOString()
                .slice(0, 10);

        const isoMonth =
            today.toISOString()
                .slice(0, 7);

        [
            "incomeDate",
            "expenseDate",
            "autopayDate"
        ].forEach(id => {

            const element =
                document.getElementById(id);

            if (element) {
                element.value =
                    isoDate;
            }
        });

        const month =
            document.getElementById(
                "budgetMonth"
            );

        if (month) {
            month.value =
                isoMonth;
        }

        document.getElementById(
            "todayText"
        ).textContent =
            today.toLocaleDateString(
                "en-IN",
                {
                    weekday: "long",
                    day: "numeric",
                    month: "long",
                    year: "numeric"
                }
            );
    }

    function setupForms() {

        document
            .getElementById("incomeForm")
            .addEventListener(
                "submit",
                addIncome
            );

        document
            .getElementById("expenseForm")
            .addEventListener(
                "submit",
                addExpense
            );

        document
            .getElementById("autopayForm")
            .addEventListener(
                "submit",
                addAutoPay
            );

        document
            .getElementById("budgetForm")
            .addEventListener(
                "submit",
                addBudget
            );

        document
            .getElementById("goalForm")
            .addEventListener(
                "submit",
                addGoal
            );
    }

    async function addIncome(event) {

        event.preventDefault();

        const result =
            await window.expenseAPI
                .addIncome({

                    userId,

                    amount:
                        Number(
                            document.getElementById(
                                "incomeAmount"
                            ).value
                        ),

                    source:
                        document.getElementById(
                            "incomeSource"
                        ).value,

                    description:
                        document.getElementById(
                            "incomeDescription"
                        ).value,

                    date:
                        document.getElementById(
                            "incomeDate"
                        ).value,

                    bankAccountId:
                        document.getElementById(
                            "incomeBankAccount"
                        ).value || null
                });

        showMessage(
            "incomeMessage",
            result.message,
            result.success
        );

        if (result.success) {
            document.getElementById(
                "incomeForm"
            ).reset();

            setupDates();
            await loadDashboard();
        }
    }

    async function addExpense(event) {

        event.preventDefault();

        const result =
            await window.expenseAPI
                .addExpense({

                    userId,

                    amount:
                        Number(
                            document.getElementById(
                                "expenseAmount"
                            ).value
                        ),

                    category:
                        document.getElementById(
                            "expenseCategory"
                        ).value,

                    description:
                        document.getElementById(
                            "expenseDescription"
                        ).value,

                    date:
                        document.getElementById(
                            "expenseDate"
                        ).value,

                    paymentMethod:
                        document.getElementById(
                            "expensePayment"
                        ).value,

                    bankAccountId:
                        document.getElementById(
                            "expenseBankAccount"
                        ).value || null,

                    classification:
                        document.getElementById(
                            "expenseClassification"
                        ).value
                });

        showMessage(
            "expenseMessage",
            result.message,
            result.success
        );

        if (result.success) {
            document.getElementById(
                "expenseForm"
            ).reset();

            setupDates();
            await loadDashboard();
        }
    }

    async function addAutoPay(event) {

        event.preventDefault();

        const result =
            await window.expenseAPI
                .addAutoPay({

                    userId,

                    name:
                        document.getElementById(
                            "autopayName"
                        ).value,

                    amount:
                        Number(
                            document.getElementById(
                                "autopayAmount"
                            ).value
                        ),

                    category:
                        document.getElementById(
                            "autopayCategory"
                        ).value,

                    frequency:
                        document.getElementById(
                            "autopayFrequency"
                        ).value,

                    nextDate:
                        document.getElementById(
                            "autopayDate"
                        ).value,

                    bankAccountId:
                        document.getElementById(
                            "autopayBankAccount"
                        ).value || null
                });

        showMessage(
            "autopayMessage",
            result.message,
            result.success
        );

        if (result.success) {
            document.getElementById(
                "autopayForm"
            ).reset();

            setupDates();
            await loadDashboard();
        }
    }

    async function addBudget(event) {

        event.preventDefault();

        const result =
            await window.expenseAPI
                .addBudget({

                    userId,

                    category:
                        document.getElementById(
                            "budgetCategory"
                        ).value,

                    amount:
                        Number(
                            document.getElementById(
                                "budgetAmount"
                            ).value
                        ),

                    month:
                        document.getElementById(
                            "budgetMonth"
                        ).value
                });

        showMessage(
            "budgetMessage",
            result.message,
            result.success
        );

        if (result.success) {
            document.getElementById(
                "budgetForm"
            ).reset();

            setupDates();
            await loadDashboard();
        }
    }

    async function addGoal(event) {

        event.preventDefault();

        const result =
            await window.expenseAPI
                .addGoal({

                    userId,

                    name:
                        document.getElementById(
                            "goalName"
                        ).value,

                    target:
                        Number(
                            document.getElementById(
                                "goalTarget"
                            ).value
                        ),

                    saved:
                        Number(
                            document.getElementById(
                                "goalSaved"
                            ).value || 0
                        ),

                    deadline:
                        document.getElementById(
                            "goalDeadline"
                        ).value
                });

        showMessage(
            "goalMessage",
            result.message,
            result.success
        );

        if (result.success) {
            document.getElementById(
                "goalForm"
            ).reset();

            await loadDashboard();
        }
    }

    function renderUser() {

        const name =
            user?.name || "User";

        const email =
            user?.email || "";

        document.getElementById(
            "sidebarName"
        ).textContent = name;

        document.getElementById(
            "sidebarEmail"
        ).textContent = email;

        document.getElementById(
            "sidebarAvatar"
        ).textContent =
            name.charAt(0).toUpperCase();
    }

    function renderDashboard() {

        const totalIncome =
            income.reduce(
                (sum, item) =>
                    sum +
                    Number(item.amount || 0),
                0
            );

        const totalExpense =
            expenses.reduce(
                (sum, item) =>
                    sum +
                    Number(item.amount || 0),
                0
            );

        const balance =
            totalIncome -
            totalExpense;

        const bankBalance =
            bankAccounts.reduce(
                (sum, item) =>
                    sum +
                    Number(item.balance || 0),
                0
            );

        const saved =
            goals.reduce(
                (sum, goal) =>
                    sum +
                    Number(goal.saved || 0),
                0
            );

        setText(
            "totalIncome",
            money(totalIncome)
        );

        setText(
            "totalExpenses",
            money(totalExpense)
        );

        setText(
            "remainingBalance",
            money(balance)
        );

        setText(
            "bankBalance",
            money(bankBalance)
        );

        setText(
            "totalSavings",
            money(saved)
        );

        setText(
            "miniIncome",
            "₹" + money(totalIncome)
        );

        setText(
            "miniExpense",
            "₹" + money(totalExpense)
        );

        const rate =
            totalIncome > 0
                ? Math.round(
                    (totalExpense /
                        totalIncome) *
                    100
                )
                : 0;

        setText(
            "expensePercent",
            rate + "%"
        );

        const combined = [
            ...income.map(item => ({
                ...item,
                transactionType: "income"
            })),

            ...expenses.map(item => ({
                ...item,
                transactionType: "expense"
            }))
        ]
            .sort(
                (a, b) =>
                    new Date(b.date) -
                    new Date(a.date)
            )
            .slice(0, 8);

        const container =
            document.getElementById(
                "recentTransactions"
            );

        if (!combined.length) {

            container.innerHTML =
                empty("No transactions yet.");

            return;
        }

        container.innerHTML =
            combined.map(item => `

                <div class="transaction-row">

                    <div class="
                        transaction-icon
                        ${
                            item.transactionType ===
                            "income"
                            ? "income-icon"
                            : "expense-icon"
                        }
                    ">
                        ${
                            item.transactionType ===
                            "income"
                            ? "↓"
                            : "↑"
                        }
                    </div>

                    <div class="transaction-info">

                        <strong>
                            ${escapeHtml(
                                item.description ||
                                item.source ||
                                "Transaction"
                            )}
                        </strong>

                        <small>
                            ${escapeHtml(item.date)}
                        </small>

                    </div>

                    <strong class="
                        ${
                            item.transactionType ===
                            "income"
                            ? "positive"
                            : "negative"
                        }
                    ">
                        ${
                            item.transactionType ===
                            "income"
                            ? "+"
                            : "-"
                        }
                        ₹${money(item.amount)}
                    </strong>

                </div>

            `).join("");
    }

    function renderIncome() {

        const container =
            document.getElementById(
                "incomeList"
            );

        const sorted =
            [...income].sort(
                (a, b) =>
                    new Date(b.date) -
                    new Date(a.date)
            );

        if (!sorted.length) {
            container.innerHTML =
                empty("No income records yet.");
            return;
        }

        container.innerHTML =
            sorted.slice(0, 30).map(item => `

                <div class="transaction-row">

                    <div class="transaction-icon income-icon">
                        ↓
                    </div>

                    <div class="transaction-info">

                        <strong>
                            ${escapeHtml(
                                item.source
                            )}
                        </strong>

                        <small>
                            ${escapeHtml(
                                item.description ||
                                item.date
                            )}
                        </small>

                    </div>

                    <strong class="positive">
                        + ₹${money(item.amount)}
                    </strong>

                </div>

            `).join("");
    }

    function renderExpenses() {

        const container =
            document.getElementById(
                "expenseList"
            );

        const sorted =
            [...expenses].sort(
                (a, b) =>
                    new Date(b.date) -
                    new Date(a.date)
            );

        if (!sorted.length) {
            container.innerHTML =
                empty("No expense records yet.");
            return;
        }

        container.innerHTML =
            sorted.slice(0, 30).map(item => `

                <div class="transaction-row">

                    <div class="transaction-icon expense-icon">
                        ↑
                    </div>

                    <div class="transaction-info">

                        <strong>
                            ${escapeHtml(
                                item.description
                            )}
                        </strong>

                        <small>
                            ${escapeHtml(
                                item.category
                            )}
                            ·
                            ${escapeHtml(
                                item.date
                            )}
                        </small>

                    </div>

                    <strong class="negative">
                        - ₹${money(item.amount)}
                    </strong>

                </div>

            `).join("");
    }

    function renderAutopay() {

        const container =
            document.getElementById(
                "autopayList"
            );

        if (!autopay.length) {
            container.innerHTML =
                empty("No Auto-Pay records yet.");
            return;
        }

        container.innerHTML =
            autopay.map(item => `

                <div class="feature-list-card">

                    <div class="feature-card-icon purple-icon">
                        🔄
                    </div>

                    <div class="feature-card-content">

                        <strong>
                            ${escapeHtml(item.name)}
                        </strong>

                        <small>
                            ${escapeHtml(
                                item.frequency
                            )}
                            · Next:
                            ${escapeHtml(
                                item.nextDate
                            )}
                        </small>

                        <b>
                            ₹${money(item.amount)}
                        </b>

                    </div>

                    <button
                        class="delete-inline"
                        data-autopay="${item.id}"
                    >
                        Delete
                    </button>

                </div>

            `).join("");

        container
            .querySelectorAll(
                "[data-autopay]"
            )
            .forEach(button => {

                button.addEventListener(
                    "click",
                    async () => {

                        const result =
                            await window.expenseAPI
                                .deleteAutoPay(
                                    button.dataset.autopay
                                );

                        if (result.success) {
                            await loadDashboard();
                        }
                    }
                );
            });
    }

    function renderBudgets() {

        const container =
            document.getElementById(
                "budgetList"
            );

        if (!budgets.length) {
            container.innerHTML =
                empty("No budgets created yet.");
            return;
        }

        container.innerHTML =
            budgets.map(item => {

                const spent =
                    expenses
                        .filter(
                            expense =>
                                expense.category ===
                                    item.category &&
                                String(expense.date)
                                    .startsWith(
                                        item.month
                                    )
                        )
                        .reduce(
                            (sum, expense) =>
                                sum +
                                Number(
                                    expense.amount
                                ),
                            0
                        );

                const percent =
                    item.amount > 0
                        ? Math.min(
                            100,
                            Math.round(
                                (spent /
                                    item.amount) *
                                100
                            )
                        )
                        : 0;

                return `

                    <div class="budget-card">

                        <div class="budget-top">

                            <div>
                                <strong>
                                    ${escapeHtml(
                                        item.category
                                    )}
                                </strong>

                                <small>
                                    ${escapeHtml(
                                        item.month
                                    )}
                                </small>
                            </div>

                            <button
                                class="delete-inline"
                                data-budget="${item.id}"
                            >
                                Delete
                            </button>

                        </div>

                        <div class="budget-numbers">
                            <span>
                                Spent
                                ₹${money(spent)}
                            </span>

                            <b>
                                ₹${money(item.amount)}
                            </b>
                        </div>

                        <div class="progress-track">
                            <div
                                class="progress-fill"
                                style="width:${percent}%"
                            ></div>
                        </div>

                        <small>
                            ${percent}% used
                        </small>

                    </div>

                `;
            }).join("");

        container
            .querySelectorAll(
                "[data-budget]"
            )
            .forEach(button => {

                button.addEventListener(
                    "click",
                    async () => {

                        await window.expenseAPI
                            .deleteBudget(
                                button.dataset.budget
                            );

                        await loadDashboard();
                    }
                );
            });
    }

    function renderGoals() {

        const container =
            document.getElementById(
                "goalList"
            );

        if (!goals.length) {
            container.innerHTML =
                empty("No savings goals yet.");
            return;
        }

        container.innerHTML =
            goals.map(goal => {

                const target =
                    Number(goal.target || 0);

                const saved =
                    Number(goal.saved || 0);

                const percent =
                    target > 0
                        ? Math.min(
                            100,
                            Math.round(
                                (saved / target) *
                                100
                            )
                        )
                        : 0;

                return `

                    <div class="goal-card">

                        <div class="goal-top">

                            <div>
                                <strong>
                                    ${escapeHtml(
                                        goal.name
                                    )}
                                </strong>

                                <small>
                                    Target:
                                    ₹${money(target)}
                                </small>
                            </div>

                            <button
                                class="delete-inline"
                                data-goal-delete="${goal.id}"
                            >
                                Delete
                            </button>

                        </div>

                        <div class="goal-progress">

                            <div class="progress-track">
                                <div
                                    class="progress-fill pink-progress"
                                    style="width:${percent}%"
                                ></div>
                            </div>

                            <b>
                                ${percent}%
                            </b>

                        </div>

                        <div class="goal-bottom">

                            <span>
                                Saved:
                                ₹${money(saved)}
                            </span>

                            <button
                                class="small-btn"
                                data-goal-update="${goal.id}"
                            >
                                + Add Savings
                            </button>

                        </div>

                    </div>

                `;
            }).join("");

        container
            .querySelectorAll(
                "[data-goal-delete]"
            )
            .forEach(button => {

                button.addEventListener(
                    "click",
                    async () => {

                        await window.expenseAPI
                            .deleteGoal(
                                button.dataset.goalDelete
                            );

                        await loadDashboard();
                    }
                );
            });

        container
            .querySelectorAll(
                "[data-goal-update]"
            )
            .forEach(button => {

                button.addEventListener(
                    "click",
                    async () => {

                        const goal =
                            goals.find(
                                item =>
                                    String(item.id) ===
                                    String(
                                        button.dataset.goalUpdate
                                    )
                            );

                        if (!goal) return;

                        const amount =
                            prompt(
                                "Enter total amount saved:",
                                goal.saved
                            );

                        if (
                            amount === null
                        ) {
                            return;
                        }

                        await window.expenseAPI
                            .updateGoal({
                                id: goal.id,
                                saved:
                                    Number(amount)
                            });

                        await loadDashboard();
                    }
                );
            });
    }

    function renderHistory() {

        const container =
            document.getElementById(
                "historyList"
            );

        const search =
            document.getElementById(
                "historySearch"
            ).value
                .trim()
                .toLowerCase();

        const month =
            document.getElementById(
                "historyMonth"
            ).value;

        let list = [
            ...income.map(
                item => ({
                    ...item,
                    kind: "Income"
                })
            ),

            ...expenses.map(
                item => ({
                    ...item,
                    kind: "Expense"
                })
            )
        ];

        list = list.filter(item => {

            const text =
                (
                    item.description ||
                    item.source ||
                    ""
                ).toLowerCase();

            const date =
                String(item.date || "");

            return (
                (!search ||
                    text.includes(search)) &&
                (!month ||
                    date.startsWith(month))
            );
        });

        list.sort(
            (a, b) =>
                new Date(b.date) -
                new Date(a.date)
        );

        if (!list.length) {
            container.innerHTML =
                empty(
                    "No transactions match your filter."
                );
            return;
        }

        container.innerHTML =
            list.map(item => `

                <div class="transaction-row">

                    <div class="
                        transaction-icon
                        ${
                            item.kind === "Income"
                            ? "income-icon"
                            : "expense-icon"
                        }
                    ">
                        ${
                            item.kind === "Income"
                            ? "↓"
                            : "↑"
                        }
                    </div>

                    <div class="transaction-info">

                        <strong>
                            ${escapeHtml(
                                item.description ||
                                item.source ||
                                item.category
                            )}
                        </strong>

                        <small>
                            ${escapeHtml(
                                item.date
                            )}
                            ·
                            ${escapeHtml(
                                item.category ||
                                item.source ||
                                "Income"
                            )}
                        </small>

                    </div>

                    <strong class="
                        ${
                            item.kind === "Income"
                            ? "positive"
                            : "negative"
                        }
                    ">
                        ${
                            item.kind === "Income"
                            ? "+"
                            : "-"
                        }
                        ₹${money(item.amount)}
                    </strong>

                </div>

            `).join("");
    }

    function renderAnalysis() {

        const totalIncome =
            income.reduce(
                (sum, item) =>
                    sum +
                    Number(item.amount || 0),
                0
            );

        const totalExpense =
            expenses.reduce(
                (sum, item) =>
                    sum +
                    Number(item.amount || 0),
                0
            );

        const remaining =
            totalIncome -
            totalExpense;

        const rate =
            totalIncome
                ? Math.round(
                    (totalExpense /
                        totalIncome) *
                    100
                )
                : 0;

        setText(
            "analysisIncome",
            "₹" + money(totalIncome)
        );

        setText(
            "analysisExpense",
            "₹" + money(totalExpense)
        );

        setText(
            "analysisRemaining",
            "₹" + money(remaining)
        );

        setText(
            "analysisRate",
            rate + "%"
        );

        const categories = {};

        expenses.forEach(item => {

            const category =
                item.category || "Other";

            categories[category] =
                (categories[category] || 0) +
                Number(item.amount || 0);
        });

        const values =
            Object.entries(categories)
                .sort(
                    (a, b) => b[1] - a[1]
                );

        const maximum =
            values.length
                ? values[0][1]
                : 1;

        const container =
            document.getElementById(
                "categoryAnalysis"
            );

        if (!values.length) {
            container.innerHTML =
                empty(
                    "Add expenses to see category analysis."
                );

            return;
        }

        container.innerHTML =
            values.map(
                ([category, amount]) => {

                    const percent =
                        Math.round(
                            (amount / maximum) *
                            100
                        );

                    return `

                        <div class="category-bar">

                            <div class="category-bar-label">
                                <span>
                                    ${escapeHtml(
                                        category
                                    )}
                                </span>

                                <b>
                                    ₹${money(amount)}
                                </b>
                            </div>

                            <div class="progress-track">
                                <div
                                    class="progress-fill"
                                    style="width:${percent}%"
                                ></div>
                            </div>

                        </div>

                    `;
                }
            ).join("");
    }

    function renderProfile() {

        const name =
            user?.name || "User";

        const email =
            user?.email || "";

        setText(
            "profileName",
            name
        );

        setText(
            "profileEmail",
            email
        );

        setText(
            "profileName2",
            name
        );

        setText(
            "profileEmail2",
            email
        );

        setText(
            "profileBankCount",
            bankAccounts.length
        );

        setText(
            "profileTransactions",
            income.length +
            expenses.length
        );

        document.getElementById(
            "profileAvatar"
        ).textContent =
            name.charAt(0).toUpperCase();
    }

    function populateBankSelects() {

        const selects = [
            "incomeBankAccount",
            "expenseBankAccount",
            "autopayBankAccount"
        ];

        selects.forEach(id => {

            const select =
                document.getElementById(id);

            if (!select) return;

            const current =
                select.value;

            select.innerHTML =
                `<option value="">
                    Cash / Other
                </option>` +
                bankAccounts.map(
                    account =>
                        `<option value="${account.id}">
                            ${escapeHtml(
                                account.nickname ||
                                account.bankName
                            )}
                            -
                            ${escapeHtml(
                                account.accountNumberMasked
                            )}
                        </option>`
                ).join("");

            select.value = current;
        });
    }

    function checkInactivity() {

        if (!user?.lastUsedAt) {
            return;
        }

        const last =
            new Date(user.lastUsedAt)
                .getTime();

        const now =
            Date.now();

        const days =
            (
                now - last
            ) /
            (
                1000 *
                60 *
                60 *
                24
            );

        if (days >= 2) {

            const notice =
                document.getElementById(
                    "inactivityNotice"
                );

            notice.classList.remove(
                "hidden"
            );

            window.expenseAPI
                .showNotification({
                    title:
                        "MoneyFlow",
                    body:
                        "Welcome back! Check your financial dashboard."
                });
        }
    }

    function logout() {

        localStorage.removeItem(
            "moneyflowUserId"
        );

        localStorage.removeItem(
            "moneyflowUserName"
        );

        localStorage.removeItem(
            "moneyflowUserEmail"
        );

        window.location.href =
            "login.html";
    }

    function setText(id, value) {

        const element =
            document.getElementById(id);

        if (element) {
            element.textContent =
                value;
        }
    }

    function money(value) {

        return Number(
            value || 0
        ).toLocaleString(
            "en-IN",
            {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            }
        );
    }

    function showMessage(
        id,
        text,
        success
    ) {

        const element =
            document.getElementById(id);

        if (!element) return;

        element.textContent =
            text || "";

        element.className =
            "form-message " +
            (
                success
                    ? "success"
                    : "error"
            );
    }

    function empty(text) {

        return `
            <div class="empty-state">
                <div>📭</div>
                <p>
                    ${escapeHtml(text)}
                </p>
            </div>
        `;
    }

    function escapeHtml(value) {

        return String(value || "")
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }
});
'@

Write-ProjectFile "src\css\style.css" @'
:root {

    --green-dark: #064e3b;
    --green: #16a34a;
    --green-light: #22c55e;

    --teal: #0f766e;
    --teal-light: #14b8a6;

    --blue: #2563eb;
    --blue-light: #38bdf8;

    --purple: #7c3aed;
    --purple-light: #a855f7;

    --orange: #f97316;
    --orange-light: #fb923c;

    --red: #dc2626;
    --red-light: #f87171;

    --amber: #f59e0b;
    --yellow: #facc15;

    --pink: #db2777;
    --pink-light: #ec4899;

    --navy: #0f172a;

    --white: #ffffff;
    --text: #172033;
    --muted: #64748b;
    --border: #e2e8f0;
    --background: #f8fafc;

    --shadow:
        0 15px 45px rgba(15, 23, 42, .08);
}

/* RESET */

* {
    box-sizing: border-box;
}

html,
body {
    margin: 0;
    padding: 0;
    min-height: 100%;
    font-family:
        Inter,
        Segoe UI,
        Arial,
        sans-serif;
    color: var(--text);
}

body {
    background: var(--background);
}

button,
input,
select {
    font-family: inherit;
}

button {
    cursor: pointer;
}

a {
    text-decoration: none;
}

/* AUTH */

.login-page {
    background:
        linear-gradient(
            135deg,
            #581c87 0%,
            #7c3aed 45%,
            #f97316 100%
        );
    min-height: 100vh;
}

.signup-page {
    background:
        linear-gradient(
            135deg,
            #064e3b 0%,
            #0f766e 45%,
            #06b6d4 100%
        );
    min-height: 100vh;
}

.auth-shell {
    min-height: 100vh;
    display: grid;
    grid-template-columns: 1.1fr .9fr;
}

.auth-showcase {
    padding: 70px;
    color: white;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}

.brand {
    display: flex;
    align-items: center;
    gap: 14px;
}

.brand-symbol {
    width: 52px;
    height: 52px;
    border-radius: 17px;
    background: rgba(255,255,255,.18);
    display: grid;
    place-items: center;
    font-size: 27px;
    box-shadow:
        0 10px 30px rgba(0,0,0,.15);
}

.brand h1 {
    margin: 0;
    font-size: 27px;
}

.brand p {
    margin: 3px 0 0;
    opacity: .8;
    font-size: 13px;
}

.showcase-content {
    max-width: 650px;
}

.eyebrow {
    font-size: 11px;
    letter-spacing: 1.7px;
    font-weight: 800;
    color: #64748b;
}

.auth-showcase .eyebrow {
    color: rgba(255,255,255,.75);
}

.showcase-content h2 {
    font-size: 58px;
    line-height: 1.04;
    margin: 22px 0;
}

.showcase-content h2 span {
    display: block;
    color: #fef08a;
}

.showcase-content p {
    max-width: 590px;
    line-height: 1.8;
    font-size: 17px;
    color: rgba(255,255,255,.82);
}

.showcase-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 14px;
    margin-top: 35px;
}

.showcase-grid div {
    padding: 17px;
    border-radius: 18px;
    background: rgba(255,255,255,.13);
    backdrop-filter: blur(10px);
}

.auth-form-area {
    display: grid;
    place-items: center;
    padding: 35px;
}

.auth-card {
    width: min(470px, 100%);
    background: rgba(255,255,255,.97);
    border-radius: 30px;
    padding: 42px;
    box-shadow:
        0 30px 80px rgba(0,0,0,.25);
}

.auth-circle {
    width: 62px;
    height: 62px;
    border-radius: 20px;
    display: grid;
    place-items: center;
    background:
        linear-gradient(
            135deg,
            var(--purple),
            var(--orange)
        );
    font-size: 29px;
    margin-bottom: 20px;
}

.auth-card h2 {
    margin: 0;
    font-size: 31px;
}

.muted {
    color: var(--muted);
    margin-top: 8px;
    margin-bottom: 30px;
}

.auth-card label {
    display: block;
    font-size: 13px;
    font-weight: 700;
    margin: 17px 0 7px;
}

.input-wrap {
    display: flex;
    align-items: center;
    border: 1px solid var(--border);
    background: #f8fafc;
    border-radius: 14px;
    padding: 0 13px;
    transition: .2s;
}

.input-wrap:focus-within {
    border-color: var(--purple);
    box-shadow:
        0 0 0 4px rgba(124,58,237,.10);
}

.input-wrap input {
    border: 0;
    outline: 0;
    background: transparent;
    padding: 15px 10px;
    flex: 1;
    font-size: 14px;
}

.eye-btn {
    border: 0;
    background: transparent;
    font-size: 17px;
}

.primary-auth-btn {
    width: 100%;
    border: 0;
    border-radius: 14px;
    padding: 16px;
    margin-top: 25px;
    color: white;
    font-weight: 800;
    background:
        linear-gradient(
            135deg,
            var(--purple),
            var(--orange)
        );
    box-shadow:
        0 12px 25px rgba(124,58,237,.25);
}

.signup-btn {
    background:
        linear-gradient(
            135deg,
            var(--green-dark),
            var(--teal-light)
        );
}

.form-message {
    min-height: 22px;
    margin-top: 14px;
    font-size: 13px;
    font-weight: 700;
}

.form-message.success {
    color: var(--green);
}

.form-message.error {
    color: var(--red);
}

.auth-separator {
    display: flex;
    align-items: center;
    gap: 10px;
    margin: 24px 0;
    color: #94a3b8;
    font-size: 11px;
}

.auth-separator::before,
.auth-separator::after {
    content: "";
    height: 1px;
    background: var(--border);
    flex: 1;
}

.switch-text {
    text-align: center;
    color: var(--muted);
    font-size: 14px;
}

.switch-text a {
    color: var(--purple);
    font-weight: 800;
}

.admin-hint {
    text-align: center;
    margin-top: 20px;
    padding: 13px;
    border-radius: 12px;
    background: #f1f5f9;
    font-size: 11px;
    color: var(--muted);
}

/* APP */

.app-layout {
    display: flex;
    min-height: 100vh;
}

.sidebar {
    width: 255px;
    min-width: 255px;
    background:
        linear-gradient(
            180deg,
            #064e3b 0%,
            #14532d 45%,
            #0f766e 100%
        );
    color: white;
    padding: 22px 15px;
    display: flex;
    flex-direction: column;
    box-shadow:
        10px 0 35px rgba(6,78,59,.18);
}

.sidebar-brand {
    display: flex;
    align-items: center;
    gap: 11px;
    padding: 4px 9px 24px;
}

.sidebar-brand strong {
    display: block;
    font-size: 18px;
}

.sidebar-brand small {
    display: block;
    color: rgba(255,255,255,.65);
    font-size: 10px;
}

.sidebar-brand .brand-symbol {
    width: 42px;
    height: 42px;
    border-radius: 14px;
}

.profile-mini {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 13px;
    border-radius: 18px;
    background: rgba(255,255,255,.09);
    margin-bottom: 17px;
}

.profile-avatar {
    width: 40px;
    height: 40px;
    border-radius: 13px;
    display: grid;
    place-items: center;
    background:
        linear-gradient(
            135deg,
            #22c55e,
            #14b8a6
        );
    font-weight: 900;
}

.profile-mini strong,
.profile-mini small {
    display: block;
}

.profile-mini strong {
    font-size: 13px;
}

.profile-mini small {
    color: rgba(255,255,255,.62);
    font-size: 10px;
    margin-top: 2px;
}

.sidebar-nav {
    display: flex;
    flex-direction: column;
    gap: 5px;
    flex: 1;
}

.nav-item {
    border: 0;
    color: rgba(255,255,255,.82);
    background: transparent;
    padding: 12px 14px;
    border-radius: 13px;
    text-align: left;
    font-weight: 700;
    display: flex;
    align-items: center;
    gap: 12px;
    transition: .2s;
}

.nav-item:hover {
    background: rgba(255,255,255,.12);
    color: white;
    transform: translateX(2px);
}

.nav-item.active {
    color: var(--green-dark);
    background: white;
    box-shadow:
        0 8px 20px rgba(0,0,0,.12);
}

.nav-item span {
    width: 24px;
    text-align: center;
    font-size: 16px;
}

.logout-btn {
    border: 1px solid rgba(255,255,255,.15);
    background: rgba(0,0,0,.12);
    color: white;
    padding: 12px;
    border-radius: 13px;
    font-weight: 800;
}

.logout-btn:hover {
    background: rgba(220,38,38,.85);
}

.main-area {
    flex: 1;
    min-width: 0;
    background: #f8fafc;
    padding: 25px 32px 50px;
}

.topbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 25px;
}

.topbar h1 {
    margin: 6px 0 0;
    font-size: 31px;
}

.topbar-right {
    display: flex;
    align-items: center;
    gap: 14px;
}

.today-box,
.notification-dot {
    background: white;
    border: 1px solid var(--border);
    padding: 11px 14px;
    border-radius: 12px;
    font-size: 12px;
}

.notification-dot {
    width: 42px;
    height: 42px;
    display: grid;
    place-items: center;
    padding: 0;
}

.notice-card {
    display: flex;
    gap: 15px;
    align-items: center;
    padding: 16px 20px;
    border-radius: 16px;
    background:
        linear-gradient(
            135deg,
            #dcfce7,
            #ccfbf1
        );
    color: var(--green-dark);
    margin-bottom: 22px;
}

.hidden {
    display: none !important;
}

/* SECTIONS */

.page-section {
    display: none;
}

.page-section.active {
    display: block;
}

.hero-card {
    min-height: 220px;
    padding: 38px;
    border-radius: 28px;
    color: white;
    display: flex;
    justify-content: space-between;
    align-items: center;
    background:
        linear-gradient(
            135deg,
            #064e3b,
            #0f766e,
            #14b8a6
        );
    box-shadow:
        0 18px 45px rgba(15,118,110,.22);
}

.hero-label {
    font-size: 11px;
    letter-spacing: 1.5px;
    font-weight: 900;
    color: rgba(255,255,255,.7);
}

.hero-card h2 {
    font-size: 48px;
    margin: 12px 0 5px;
}

.hero-card p {
    color: rgba(255,255,255,.72);
}

.hero-icon {
    width: 120px;
    height: 120px;
    border-radius: 35px;
    display: grid;
    place-items: center;
    font-size: 54px;
    background: rgba(255,255,255,.13);
}

.stat-grid {
    display: grid;
    grid-template-columns:
        repeat(4, 1fr);
    gap: 17px;
    margin: 20px 0;
}

.stat-card {
    padding: 21px;
    border-radius: 20px;
    background: white;
    border: 1px solid var(--border);
    display: flex;
    align-items: center;
    gap: 15px;
    box-shadow: var(--shadow);
}

.stat-icon {
    width: 50px;
    height: 50px;
    display: grid;
    place-items: center;
    border-radius: 16px;
    font-size: 22px;
}

.income-theme .stat-icon {
    background: #dcfce7;
}

.expense-theme .stat-icon {
    background: #fee2e2;
}

.bank-theme .stat-icon {
    background: #dbeafe;
}

.goal-theme .stat-icon {
    background: #fce7f3;
}

.stat-card small,
.stat-card strong {
    display: block;
}

.stat-card small {
    color: var(--muted);
    font-size: 11px;
}

.stat-card strong {
    margin-top: 5px;
    font-size: 21px;
}

.dashboard-grid,
.content-grid {
    display: grid;
    grid-template-columns:
        minmax(0, 1.5fr)
        minmax(300px, 1fr);
    gap: 20px;
}

.panel {
    background: white;
    border: 1px solid var(--border);
    border-radius: 22px;
    padding: 23px;
    box-shadow: var(--shadow);
}

.panel-heading {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 18px;
}

.panel-heading h3,
.panel-heading h2 {
    margin: 5px 0 0;
}

.small-btn,
.gray-btn,
.dark-btn,
.blue-btn,
.green-btn,
.red-btn,
.purple-btn,
.orange-btn,
.pink-btn {
    border: 0;
    border-radius: 11px;
    padding: 10px 15px;
    font-weight: 800;
}

.small-btn {
    color: var(--blue);
    background: #eff6ff;
}

.blue-btn {
    color: white;
    background: var(--blue);
}

.green-btn {
    color: white;
    background: var(--green);
}

.red-btn {
    color: white;
    background: var(--red);
}

.purple-btn {
    color: white;
    background: var(--purple);
}

.orange-btn {
    color: white;
    background: var(--orange);
}

.pink-btn {
    color: white;
    background: var(--pink);
}

.gray-btn {
    background: #e2e8f0;
    color: var(--navy);
}

.dark-btn {
    background: var(--navy);
    color: white;
}

/* FORMS */

form label {
    display: block;
    font-size: 12px;
    font-weight: 800;
    margin: 14px 0 6px;
}

form input,
form select,
.filter-row input,
.filter-row select,
.statement-controls input,
.statement-controls select {
    width: 100%;
    border: 1px solid var(--border);
    background: #f8fafc;
    border-radius: 11px;
    padding: 12px 13px;
    outline: none;
    color: var(--text);
}

form input:focus,
form select:focus {
    border-color: var(--teal);
    box-shadow:
        0 0 0 3px rgba(20,184,166,.09);
}

form button {
    margin-top: 17px;
}

/* BANNERS */

.section-banner {
    display: flex;
    align-items: center;
    gap: 18px;
    padding: 25px;
    border-radius: 23px;
    color: white;
    margin-bottom: 20px;
}

.section-banner > span {
    width: 62px;
    height: 62px;
    border-radius: 18px;
    background: rgba(255,255,255,.15);
    display: grid;
    place-items: center;
    font-size: 28px;
}

.section-banner h2 {
    margin: 3px 0;
}

.section-banner p {
    margin: 4px 0 0;
    opacity: .78;
}

.income-banner {
    background:
        linear-gradient(
            135deg,
            #047857,
            #14b8a6
        );
}

.expense-banner {
    background:
        linear-gradient(
            135deg,
            #991b1b,
            #f97316
        );
}

.autopay-banner {
    background:
        linear-gradient(
            135deg,
            #581c87,
            #a855f7
        );
}

.budget-banner {
    background:
        linear-gradient(
            135deg,
            #b45309,
            #f59e0b
        );
}

.goals-banner {
    background:
        linear-gradient(
            135deg,
            #9d174d,
            #ec4899
        );
}

.history-banner {
    background:
        linear-gradient(
            135deg,
            #3730a3,
            #2563eb
        );
}

.analysis-banner {
    background:
        linear-gradient(
            135deg,
            #115e59,
            #14b8a6
        );
}

/* TRANSACTIONS */

.transaction-list {
    display: flex;
    flex-direction: column;
}

.transaction-row {
    display: flex;
    align-items: center;
    gap: 13px;
    padding: 13px 0;
    border-bottom: 1px solid #f1f5f9;
}

.transaction-row:last-child {
    border-bottom: 0;
}

.transaction-icon {
    width: 42px;
    height: 42px;
    border-radius: 13px;
    display: grid;
    place-items: center;
    font-weight: 900;
    font-size: 19px;
}

.income-icon {
    background: #dcfce7;
    color: var(--green);
}

.expense-icon {
    background: #fee2e2;
    color: var(--red);
}

.transaction-info {
    flex: 1;
}

.transaction-info strong,
.transaction-info small {
    display: block;
}

.transaction-info strong {
    font-size: 13px;
}

.transaction-info small {
    color: var(--muted);
    font-size: 10px;
    margin-top: 3px;
}

.positive {
    color: var(--green);
}

.negative {
    color: var(--red);
}

.analysis-box {
    text-align: center;
    padding: 10px;
}

.analysis-ring {
    width: 150px;
    height: 150px;
    border-radius: 50%;
    margin: auto;
    display: grid;
    place-items: center;
    background:
        conic-gradient(
            var(--teal) 0deg,
            var(--teal) 220deg,
            #e2e8f0 220deg
        );
}

.analysis-ring::before {
    content: "";
    position: absolute;
    width: 105px;
    height: 105px;
    border-radius: 50%;
    background: white;
}

.analysis-ring span {
    position: relative;
    font-size: 25px;
    font-weight: 900;
}

.mini-analysis {
    display: flex;
    justify-content: space-between;
    border-top: 1px solid var(--border);
    padding: 13px 0;
    margin-top: 8px;
}

/* FEATURE CARDS */

.feature-list-card,
.budget-card,
.goal-card {
    border: 1px solid var(--border);
    border-radius: 16px;
    padding: 15px;
    margin-bottom: 12px;
}

.feature-list-card {
    display: flex;
    align-items: center;
    gap: 13px;
}

.feature-card-icon {
    width: 46px;
    height: 46px;
    border-radius: 14px;
    display: grid;
    place-items: center;
}

.purple-icon {
    background: #ede9fe;
}

.feature-card-content {
    flex: 1;
}

.feature-card-content strong,
.feature-card-content small,
.feature-card-content b {
    display: block;
}

.feature-card-content small {
    color: var(--muted);
    margin: 3px 0;
    font-size: 11px;
}

.delete-inline {
    border: 0;
    background: #fee2e2;
    color: var(--red);
    border-radius: 9px;
    padding: 7px 9px;
    font-size: 10px;
    font-weight: 800;
}

.budget-top,
.goal-top,
.budget-numbers,
.goal-bottom {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.budget-top strong,
.budget-top small,
.goal-top strong,
.goal-top small {
    display: block;
}

.budget-top small,
.goal-top small {
    color: var(--muted);
    margin-top: 3px;
    font-size: 10px;
}

.budget-numbers {
    margin: 14px 0 7px;
    font-size: 12px;
}

.progress-track {
    height: 8px;
    border-radius: 50px;
    background: #e2e8f0;
    overflow: hidden;
}

.progress-fill {
    height: 100%;
    border-radius: inherit;
    background:
        linear-gradient(
            90deg,
            var(--orange),
            var(--red-light)
        );
}

.pink-progress {
    background:
        linear-gradient(
            90deg,
            var(--pink),
            var(--purple-light)
        );
}

.goal-progress {
    display: flex;
    align-items: center;
    gap: 10px;
    margin: 15px 0;
}

.goal-progress .progress-track {
    flex: 1;
}

.goal-bottom {
    color: var(--muted);
    font-size: 11px;
}

/* HISTORY */

.filter-row {
    display: grid;
    grid-template-columns: 1fr 180px auto;
    gap: 10px;
    margin-bottom: 20px;
}

/* ANALYSIS */

.analysis-grid {
    display: grid;
    grid-template-columns:
        repeat(4, 1fr);
    gap: 17px;
    margin-bottom: 20px;
}

.analysis-card {
    padding: 23px;
    background: white;
    border-radius: 20px;
    border: 1px solid var(--border);
    box-shadow: var(--shadow);
}

.analysis-card span,
.analysis-card small,
.analysis-card strong {
    display: block;
}

.analysis-card span {
    font-size: 24px;
}

.analysis-card small {
    color: var(--muted);
    margin-top: 14px;
}

.analysis-card strong {
    margin-top: 5px;
    font-size: 23px;
}

.category-bar {
    margin-bottom: 17px;
}

.category-bar-label {
    display: flex;
    justify-content: space-between;
    margin-bottom: 6px;
    font-size: 12px;
}

/* PROFILE */

.profile-cover {
    padding: 30px;
    border-radius: 24px;
    color: white;
    display: flex;
    align-items: center;
    gap: 20px;
    background:
        linear-gradient(
            135deg,
            #064e3b,
            #84cc16
        );
}

.profile-cover h2 {
    margin: 0;
}

.profile-cover p {
    opacity: .75;
}

.big-avatar {
    width: 80px;
    height: 80px;
    border-radius: 24px;
    display: grid;
    place-items: center;
    font-size: 31px;
    font-weight: 900;
    background: rgba(255,255,255,.18);
}

.profile-grid {
    display: grid;
    grid-template-columns:
        repeat(4, 1fr);
    gap: 15px;
    margin: 20px 0;
}

.profile-info-card {
    padding: 22px;
    border-radius: 18px;
    background: white;
    border: 1px solid var(--border);
}

.profile-info-card span,
.profile-info-card small,
.profile-info-card strong {
    display: block;
}

.profile-info-card span {
    font-size: 22px;
}

.profile-info-card small {
    color: var(--muted);
    margin-top: 12px;
}

.profile-info-card strong {
    margin-top: 4px;
}

.profile-action-card {
    background: white;
    border: 1px solid var(--border);
    border-radius: 20px;
    padding: 25px;
}

.profile-action-card h3 {
    margin-top: 0;
}

/* BANK PAGE */

.accounts-page {
    min-height: 100vh;
    background:
        linear-gradient(
            180deg,
            #eff6ff,
            #f8fafc 50%
        );
}

.bank-page {
    max-width: 1400px;
    margin: auto;
    padding: 30px;
}

.bank-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 22px;
}

.bank-header h1 {
    margin: 7px 0;
    font-size: 35px;
}

.bank-header p {
    color: var(--muted);
}

.header-actions {
    display: flex;
    gap: 10px;
}

.logout-small {
    border: 0;
    background: #fee2e2;
    color: var(--red);
    border-radius: 11px;
    padding: 11px 15px;
    font-weight: 800;
}

.security-warning {
    display: flex;
    gap: 14px;
    padding: 17px;
    border-radius: 16px;
    background: #fff7ed;
    border: 1px solid #fed7aa;
    color: #9a3412;
    margin-bottom: 25px;
}

.security-warning span {
    color: #c2410c;
}

.bank-grid {
    display: grid;
    grid-template-columns:
        400px 1fr;
    gap: 22px;
}

.bank-form-card,
.statement-card {
    background: white;
    border: 1px solid var(--border);
    border-radius: 24px;
    padding: 25px;
    box-shadow: var(--shadow);
}

.card-heading,
.statement-heading {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.card-heading span:first-child,
.statement-heading span:first-child,
.bank-section-title > div > span {
    font-size: 10px;
    font-weight: 900;
    letter-spacing: 1.4px;
    color: var(--blue);
}

.card-heading h2,
.statement-heading h2,
.bank-section-title h2 {
    margin: 6px 0 20px;
}

.bank-card-icon,
.statement-icon {
    width: 58px;
    height: 58px;
    border-radius: 18px;
    display: grid;
    place-items: center;
    background:
        linear-gradient(
            135deg,
            #dbeafe,
            #cffafe
        );
    font-size: 27px;
}

.checkbox-line {
    display: flex !important;
    align-items: center;
    gap: 9px;
    margin-top: 15px !important;
}

.checkbox-line input {
    width: auto;
}

.form-buttons {
    display: flex;
    gap: 8px;
}

.bank-section-title {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.bank-section-title h2 {
    margin-bottom: 0;
}

.total-bank-box {
    padding: 12px 15px;
    border-radius: 13px;
    background: #dbeafe;
    color: var(--blue);
    font-weight: 900;
}

.bank-accounts-list {
    margin-top: 18px;
    display: grid;
    grid-template-columns:
        repeat(2, 1fr);
    gap: 17px;
}

.bank-account-card {
    color: white;
    padding: 22px;
    border-radius: 23px;
    background:
        linear-gradient(
            135deg,
            #0f172a,
            #1d4ed8,
            #06b6d4
        );
    box-shadow:
        0 16px 35px rgba(37,99,235,.2);
}

.bank-card-top {
    display: flex;
    align-items: center;
    gap: 12px;
}

.bank-logo {
    width: 47px;
    height: 47px;
    border-radius: 14px;
    background: rgba(255,255,255,.14);
    display: grid;
    place-items: center;
    font-size: 22px;
}

.bank-label {
    display: block;
    font-size: 9px;
    letter-spacing: 1px;
    opacity: .65;
    text-transform: uppercase;
}

.bank-card-top h3 {
    margin: 3px 0 0;
}

.primary-badge {
    margin-left: auto;
    background: #facc15;
    color: #713f12;
    border-radius: 50px;
    padding: 5px 8px;
    font-size: 8px;
    font-weight: 900;
}

.bank-balance {
    margin: 25px 0;
}

.bank-balance small {
    display: block;
    opacity: .65;
}

.bank-balance strong {
    font-size: 29px;
}

.bank-details {
    display: grid;
    grid-template-columns:
        repeat(2, 1fr);
    gap: 13px;
}

.bank-details span,
.bank-details b {
    display: block;
}

.bank-details span {
    opacity: .55;
    font-size: 9px;
}

.bank-details b {
    margin-top: 3px;
    font-size: 11px;
}

.bank-actions {
    display: flex;
    gap: 7px;
    margin-top: 20px;
}

.bank-actions button {
    border: 0;
    padding: 8px 10px;
    border-radius: 9px;
    font-size: 10px;
    font-weight: 800;
}

.edit-bank {
    background: white;
    color: var(--blue);
}

.primary-bank {
    background: #fef3c7;
    color: #92400e;
}

.danger-btn {
    background: #fee2e2;
    color: var(--red);
}

.statement-card {
    margin-top: 23px;
}

.statement-heading p {
    color: var(--muted);
    max-width: 750px;
    line-height: 1.6;
}

.statement-controls {
    display: grid;
    grid-template-columns:
        1fr 1.3fr auto auto;
    gap: 10px;
    align-items: center;
    margin-top: 20px;
}

.bank-transactions {
    margin-top: 17px;
}

.bank-transaction-row {
    display: flex;
    align-items: center;
    gap: 13px;
    padding: 14px 0;
    border-bottom: 1px solid var(--border);
}

.bank-transaction-icon {
    width: 42px;
    height: 42px;
    display: grid;
    place-items: center;
    border-radius: 13px;
    font-size: 20px;
    font-weight: 900;
}

.bank-transaction-icon.credit {
    background: #dcfce7;
    color: var(--green);
}

.bank-transaction-icon.debit {
    background: #fee2e2;
    color: var(--red);
}

.transaction-main {
    flex: 1;
}

.transaction-main strong,
.transaction-main small {
    display: block;
}

.transaction-main small {
    color: var(--muted);
    margin-top: 3px;
}

.empty-state {
    text-align: center;
    padding: 35px;
    color: var(--muted);
}

.empty-state > div {
    font-size: 35px;
    margin-bottom: 8px;
}

/* ADMIN */

.admin-page {
    min-height: 100vh;
    background:
        linear-gradient(
            135deg,
            #020617,
            #0f172a,
            #172554
        );
    color: white;
}

.admin-wrapper {
    max-width: 1300px;
    margin: auto;
    padding: 40px;
}

.admin-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 28px;
}

.admin-header .eyebrow {
    color: #93c5fd;
}

.admin-header h1 {
    margin: 7px 0;
}

.admin-header p {
    color: #94a3b8;
}

.admin-stats {
    display: grid;
    grid-template-columns:
        repeat(4, 1fr);
    gap: 16px;
    margin-bottom: 22px;
}

.admin-stat {
    padding: 23px;
    border-radius: 20px;
    background: rgba(255,255,255,.06);
    border: 1px solid rgba(255,255,255,.09);
}

.admin-stat span,
.admin-stat small,
.admin-stat strong {
    display: block;
}

.admin-stat span {
    font-size: 25px;
}

.admin-stat small {
    color: #94a3b8;
    margin-top: 12px;
}

.admin-stat strong {
    font-size: 30px;
    margin-top: 4px;
}

.admin-panel {
    background: white;
    color: var(--text);
    border-radius: 23px;
    padding: 25px;
}

.admin-user-row {
    display: flex;
    align-items: center;
    gap: 14px;
    padding: 14px 0;
    border-bottom: 1px solid var(--border);
}

.admin-user-avatar {
    width: 44px;
    height: 44px;
    border-radius: 13px;
    background:
        linear-gradient(
            135deg,
            var(--blue),
            var(--purple)
        );
    color: white;
    display: grid;
    place-items: center;
    font-weight: 900;
}

.admin-user-row strong,
.admin-user-row small {
    display: block;
}

.admin-user-row small {
    color: var(--muted);
    margin-top: 3px;
}

.admin-date {
    margin-left: auto;
    color: var(--muted);
    font-size: 11px;
}

/* RESPONSIVE */

@media(max-width:1100px) {

    .sidebar {
        width: 220px;
        min-width: 220px;
    }

    .stat-grid {
        grid-template-columns:
            repeat(2, 1fr);
    }

    .analysis-grid {
        grid-template-columns:
            repeat(2, 1fr);
    }

    .profile-grid {
        grid-template-columns:
            repeat(2, 1fr);
    }

    .bank-grid {
        grid-template-columns: 1fr;
    }

    .statement-controls {
        grid-template-columns:
            1fr 1fr;
    }
}

@media(max-width:800px) {

    .auth-shell {
        grid-template-columns: 1fr;
    }

    .auth-showcase {
        padding: 40px 25px;
        min-height: 420px;
    }

    .showcase-content h2 {
        font-size: 40px;
    }

    .auth-form-area {
        padding: 25px;
    }

    .app-layout {
        display: block;
    }

    .sidebar {
        width: 100%;
        min-width: 0;
    }

    .sidebar-nav {
        display: grid;
        grid-template-columns:
            repeat(2, 1fr);
    }

    .main-area {
        padding: 20px;
    }

    .dashboard-grid,
    .content-grid {
        grid-template-columns: 1fr;
    }

    .hero-card {
        min-height: 180px;
    }

    .hero-icon {
        width: 80px;
        height: 80px;
        font-size: 35px;
    }

    .hero-card h2 {
        font-size: 35px;
    }

    .bank-accounts-list {
        grid-template-columns: 1fr;
    }

    .admin-stats {
        grid-template-columns:
            repeat(2, 1fr);
    }
}

@media(max-width:550px) {

    .auth-card {
        padding: 28px;
    }

    .showcase-grid {
        grid-template-columns: 1fr;
    }

    .stat-grid,
    .analysis-grid,
    .profile-grid {
        grid-template-columns: 1fr;
    }

    .topbar {
        display: block;
    }

    .topbar-right {
        margin-top: 15px;
    }

    .filter-row {
        grid-template-columns: 1fr;
    }

    .statement-controls {
        grid-template-columns: 1fr;
    }

    .bank-header {
        display: block;
    }

    .header-actions {
        margin-top: 15px;
    }

    .bank-page {
        padding: 18px;
    }

    .bank-details {
        grid-template-columns: 1fr;
    }

    .admin-wrapper {
        padding: 20px;
    }

    .admin-stats {
        grid-template-columns: 1fr;
    }
}
'@

Write-Host ""
Write-Host "==========================================" -ForegroundColor Green
Write-Host " MONEYFLOW PROJECT CREATED SUCCESSFULLY" -ForegroundColor Green
Write-Host "==========================================" -ForegroundColor Green
Write-Host ""
Write-Host "Project location:"
Write-Host $root
Write-Host ""
Write-Host "Next commands:"
Write-Host ""
Write-Host "cd `"$root`""
Write-Host "npm install"
Write-Host "npm run check"
Write-Host "npm start"
Write-Host ""
Write-Host "Your existing expense-database.json was created only if it did not exist." -ForegroundColor Yellow
Write-Host "Never enter ATM PIN, CVV, OTP or UPI PIN into MoneyFlow." -ForegroundColor Yellow
Write-Host ""