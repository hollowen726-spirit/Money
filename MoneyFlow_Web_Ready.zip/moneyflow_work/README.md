# MoneyFlow – Personal Finance Management (Web)

MoneyFlow has been adapted from its Electron desktop interface into a responsive web application. It retains the existing HTML/CSS/JavaScript screens and its password-hashing and finance-management logic, with an Express API replacing Electron IPC, with signed secure session cookies.

## Features
- Account registration and login
- Income and expense tracking
- Expense categories and transaction history
- Bank account details entered manually
- AutoPay records
- Savings goals and contributions
- UPI ID profile setting
- Dashboard summaries

## Run locally
1. Install Node.js 18 or newer.
2. In this folder run `npm install`.
3. Set a strong session secret (recommended):
   - macOS/Linux: `export SESSION_SECRET="a-long-random-secret"`
   - PowerShell: `$env:SESSION_SECRET="a-long-random-secret"`
4. Run `npm start`.
5. Open http://localhost:3000.

## Deploy on Render
- Push this folder to a GitHub repository.
- In Render, create a new Blueprint and select the repository (Render reads `render.yaml`), or create a Node Web Service with build command `npm install` and start command `npm start`.
- Keep the persistent disk mounted at `/var/data` and set `MONEYFLOW_DB_FILE=/var/data/expense-database.json`.
- Set `SESSION_SECRET` to a long random secret. The Blueprint generates one automatically.

## Notes
- Bank/UPI details are user-entered records; this project does not perform live bank transfers or connect to a bank API.
- The original JSON database is retained for compatibility. On Render it must be stored on the persistent disk so data survives redeploys.
- The original desktop-only admin page and Electron bank-sync integration are not part of the web conversion. Do not publish any API credentials or personal financial data.
